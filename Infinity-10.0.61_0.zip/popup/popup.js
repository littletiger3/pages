!function(t){function e(e){for(var n,o,i=e[0],a=e[1],s=0,u=[];s<i.length;s++)o=i[s],Object.prototype.hasOwnProperty.call(r,o)&&r[o]&&u.push(r[o][0]),r[o]=0;for(n in a)Object.prototype.hasOwnProperty.call(a,n)&&(t[n]=a[n]);for(c&&c(e);u.length;)u.shift()()}var n={},r={20:0,0:0,1:0,2:0,3:0,4:0,5:0,7:0,9:0,13:0,29:0,37:0,39:0,40:0};function o(e){if(n[e])return n[e].exports;var r=n[e]={i:e,l:!1,exports:{}};return t[e].call(r.exports,r,r.exports,o),r.l=!0,r.exports}o.e=function(t){var e=[],n=r[t];if(0!==n)if(n)e.push(n[2]);else{var i=new Promise((function(e,o){n=r[t]=[e,o]}));e.push(n[2]=i);var a,s=document.createElement("script");s.charset="utf-8",s.timeout=120,o.nc&&s.setAttribute("nonce",o.nc),s.src=function(t){return o.p+""+t+".js"}(t);var c=new Error;a=function(e){s.onerror=s.onload=null,clearTimeout(u);var n=r[t];if(0!==n){if(n){var o=e&&("load"===e.type?"missing":e.type),i=e&&e.target&&e.target.src;c.message="Loading chunk "+t+" failed.\n("+o+": "+i+")",c.name="ChunkLoadError",c.type=o,c.request=i,n[1](c)}r[t]=void 0}};var u=setTimeout((function(){a({type:"timeout",target:s})}),12e4);s.onerror=s.onload=a,document.head.appendChild(s)}return Promise.all(e)},o.m=t,o.c=n,o.d=function(t,e,n){o.o(t,e)||Object.defineProperty(t,e,{enumerable:!0,get:n})},o.r=function(t){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(t,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(t,"__esModule",{value:!0})},o.t=function(t,e){if(1&e&&(t=o(t)),8&e)return t;if(4&e&&"object"==typeof t&&t&&t.__esModule)return t;var n=Object.create(null);if(o.r(n),Object.defineProperty(n,"default",{enumerable:!0,value:t}),2&e&&"string"!=typeof t)for(var r in t)o.d(n,r,function(e){return t[e]}.bind(null,r));return n},o.n=function(t){var e=t&&t.__esModule?function(){return t.default}:function(){return t};return o.d(e,"a",e),e},o.o=function(t,e){return Object.prototype.hasOwnProperty.call(t,e)},o.p="/",o.oe=function(t){throw console.error(t),t};var i=window.webpackJsonp=window.webpackJsonp||[],a=i.push.bind(i);i.push=e,i=i.slice();for(var s=0;s<i.length;s++)e(i[s]);var c=a;o(o.s=573)}([function(t,e,n){"use strict";n.d(e,"s",(function(){return a})),n.d(e,"j",(function(){return s})),n.d(e,"q",(function(){return c})),n.d(e,"r",(function(){return u})),n.d(e,"h",(function(){return l})),n.d(e,"i",(function(){return p})),n.d(e,"n",(function(){return h})),n.d(e,"k",(function(){return d})),n.d(e,"e",(function(){return f})),n.d(e,"c",(function(){return g})),n.d(e,"y",(function(){return v})),n.d(e,"d",(function(){return m})),n.d(e,"l",(function(){return y})),n.d(e,"m",(function(){return b})),n.d(e,"o",(function(){return w})),n.d(e,"p",(function(){return x})),n.d(e,"v",(function(){return _})),n.d(e,"a",(function(){return O})),n.d(e,"u",(function(){return S})),n.d(e,"x",(function(){return j})),n.d(e,"t",(function(){return k})),n.d(e,"w",(function(){return A})),n.d(e,"A",(function(){return T})),n.d(e,"z",(function(){return E})),n.d(e,"f",(function(){return C})),n.d(e,"b",(function(){return R})),n.d(e,"g",(function(){return I})),n.d(e,"E",(function(){return M})),n.d(e,"B",(function(){return L})),n.d(e,"D",(function(){return N})),n.d(e,"C",(function(){return B}));n(18),n(44);var r,o=n(67),i=n.n(o);const a="object"!=typeof window,s=!1,c=!0,u=!1,l=!1,p=!0,h=!1,d=!1,f="basic",g="chrome",v="10.0.61",m="1638783860890",y=p||h||d||l,b=(p||h||d)&&!l,w=navigator.platform.indexOf("Mac")>=0,x=!1,_=c?"jiaocheng.inftab.com":"qzeuoq1yf.hn-bkt.clouddn.com",O="https://infinityicon.infinitynewtab.com/assets",S=c?"https://ws.infinitynewtab.com":"https://test-ws.infinitynewtab.com",j=c?"https://api.infinitynewtab.com/v2":"https://test-api.infinitynewtab.com/v2",k=c?"https://api.infinitynewtab.com/privacy":"https://test-api.infinitynewtab.com/privacy",A="https://infinity-api.infinitynewtab.com",T=location.origin,E="https://weather-api.extfans.com",C="https://mail.google.com",R="https://suggestion.baidu.com",I="https://google.com",P=["cs","da","de","el","en","en-GB","en-US","es","es-419","fi","fr","hi","hu","id","it","ja","ko","ms","nl","no","pl","pt-BR","pt-PT","ro","ru","sk","sv","th","tr","uk","vi","zh-CN","zh-TW"],M=!!(null===(r=i.a.chrome)||void 0===r?void 0:r.abp),L=function(){if(u)return{baiduLabel:"Infinity新标签页web版",trackingId:"UA-202382853-4"};if(l)return{baiduLabel:"Infinity新标签页app版",trackingId:"UA-202382853-3"};if(y){if("pro"===f)return{baiduLabel:"Infinity新标签页pro版",trackingId:"UA-202382853-1"};if("basic"===f)return{baiduLabel:"Infinity新标签页basic版",trackingId:"UA-202382853-2"}}throw new Error("no ga info")}();function N(t="",e="_"){const n=t.split(e);return 2===n.length?(n[0]=n[0].toLowerCase(),n[1]=n[1].toUpperCase(),n.join(e)):t}const B={get lang(){return u?function(){if(!a){const t=localStorage.getItem("langCode");if(null!==localStorage.getItem("setLangCode")&&null!==t)return t}const t=navigator.language||"en-us",e=N(t.replace("_","-"),"-");return P.includes(e)?e:"zh"===t||0===e.indexOf("zh-")?"zh-CN":"en-US"}():chrome.i18n.getUILanguage()},get extVersion(){return u?"web":chrome.runtime.getManifest().version},get extId(){return u?"web":chrome.runtime.id},get platform(){return u?"web":"chrome"},get runtimePlatform(){return M?"360":D().broswer},get platformVersion(){return D().version},get isZh(){return"zh-CN"===B.lang},get isEn(){return/^(en|en-GB|en-US)$/.test(B.lang)},get isWindows(){return/windows|win32/i.test(navigator.userAgent)},get isMac(){return-1!==navigator.platform.toLowerCase().indexOf("mac")},get vendor(){let t=g;return"web"===g&&(t=D().broswer),t.charAt(0).toUpperCase()+t.slice(1)}};function D(){const t={},e=navigator.userAgent.toLowerCase();let n;return(n=e.match(/edg\/([\d.]+)/i))?t.edge=n[1]:(n=e.match(/rv:([\d.]+)\) like gecko/))||(n=e.match(/msie ([\d.]+)/))?t.ie=n[1]:(n=e.match(/firefox\/([\d.]+)/))?t.firefox=n[1]:(n=e.match(/chrome\/([\d.]+)/))?t.chrome=n[1]:(n=e.match(/opera.([\d.]+)/))?t.opera=n[1]:(n=e.match(/version\/([\d.]+).*safari/))&&(t.safari=n[1]),t.edge?{broswer:"edge",version:t.edge}:t.ie?{broswer:"ie",version:t.ie}:t.firefox?{broswer:"firefox",version:t.firefox}:t.chrome?{broswer:"chrome",version:t.chrome}:t.opera?{broswer:"opera",version:t.opera}:t.safari?{broswer:"safari",version:t.safari}:{broswer:"none",version:"0"}}},function(t,e,n){"use strict";n.d(e,"c",(function(){return T})),n.d(e,"g",(function(){return C})),n.d(e,"f",(function(){return R})),n.d(e,"h",(function(){return I})),n.d(e,"j",(function(){return P})),n.d(e,"i",(function(){return M})),n.d(e,"d",(function(){return B})),n.d(e,"e",(function(){return g.f})),n.d(e,"b",(function(){return V})),n.d(e,"a",(function(){return F}));n(13),n(17),n(52);var r=n(420),o=n.n(r),i=n(105),a=n.n(i),s=n(174),c=n(80);function u(t,e){const{element:{content:n},parts:r}=t,o=document.createTreeWalker(n,133,null,!1);let i=p(r),a=r[i],s=-1,c=0;const u=[];let l=null;for(;o.nextNode();){s++;const t=o.currentNode;for(t.previousSibling===l&&(l=null),e.has(t)&&(u.push(t),null===l&&(l=t)),null!==l&&c++;void 0!==a&&a.index===s;)a.index=null!==l?-1:a.index-c,i=p(r,i),a=r[i]}u.forEach(t=>t.parentNode.removeChild(t))}const l=t=>{let e=11===t.nodeType?0:1;const n=document.createTreeWalker(t,133,null,!1);for(;n.nextNode();)e++;return e},p=(t,e=-1)=>{for(let n=e+1;n<t.length;n++){const e=t[n];if(Object(c.d)(e))return n}return-1};var h=n(199),d=n(198),f=n(244),g=n(127);
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const v=(t,e)=>`${t}--${e}`;let m=!0;void 0===window.ShadyCSS?m=!1:void 0===window.ShadyCSS.prepareTemplateDom&&(console.warn("Incompatible ShadyCSS version detected. Please update to at least @webcomponents/webcomponentsjs@2.0.2 and @webcomponents/shadycss@1.3.1."),m=!1);const y=t=>e=>{const n=v(e.type,t);let r=d.a.get(n);void 0===r&&(r={stringsArray:new WeakMap,keyString:new Map},d.a.set(n,r));let o=r.stringsArray.get(e.strings);if(void 0!==o)return o;const i=e.strings.join(c.f);if(o=r.keyString.get(i),void 0===o){const n=e.getTemplateElement();m&&window.ShadyCSS.prepareTemplateDom(n,t),o=new c.a(e,n),r.keyString.set(i,o)}return r.stringsArray.set(e.strings,o),o},b=["html","svg"],w=new Set,x=(t,e,n)=>{w.add(t);const r=n?n.element:document.createElement("template"),o=e.querySelectorAll("style"),{length:i}=o;if(0===i)return void window.ShadyCSS.prepareTemplateStyles(r,t);const a=document.createElement("style");for(let t=0;t<i;t++){const e=o[t];e.parentNode.removeChild(e),a.textContent+=e.textContent}(t=>{b.forEach(e=>{const n=d.a.get(v(e,t));void 0!==n&&n.keyString.forEach(t=>{const{element:{content:e}}=t,n=new Set;Array.from(e.querySelectorAll("style")).forEach(t=>{n.add(t)}),u(t,n)})})})(t);const s=r.content;n?function(t,e,n=null){const{element:{content:r},parts:o}=t;if(null==n)return void r.appendChild(e);const i=document.createTreeWalker(r,133,null,!1);let a=p(o),s=0,c=-1;for(;i.nextNode();){c++;for(i.currentNode===n&&(s=l(e),n.parentNode.insertBefore(e,n));-1!==a&&o[a].index===c;){if(s>0){for(;-1!==a;)o[a].index+=s,a=p(o,a);return}a=p(o,a)}}}(n,a,s.firstChild):s.insertBefore(a,s.firstChild),window.ShadyCSS.prepareTemplateStyles(r,t);const c=s.querySelector("style");if(window.ShadyCSS.nativeShadow&&null!==c)e.insertBefore(c.cloneNode(!0),e.firstChild);else if(n){s.insertBefore(a,s.firstChild);const t=new Set;t.add(a),u(n,t)}};var _=n(7),O=n.n(_);n(249),n(10);window.JSCompiler_renameProperty=(t,e)=>t;const S={toAttribute(t,e){switch(e){case Boolean:return t?"":null;case Object:case Array:return null==t?t:JSON.stringify(t)}return t},fromAttribute(t,e){switch(e){case Boolean:return null!==t;case Number:return null===t?null:Number(t);case Object:case Array:return JSON.parse(t)}return t}},j=(t,e)=>e!==t&&(e==e||t==t),k={attribute:!0,type:String,converter:S,reflect:!1,hasChanged:j};class A extends HTMLElement{constructor(){super(),this.initialize()}static get observedAttributes(){this.finalize();const t=[];return this._classProperties.forEach((e,n)=>{const r=this._attributeNameForProperty(n,e);void 0!==r&&(this._attributeToPropertyMap.set(r,n),t.push(r))}),t}static _ensureClassProperties(){if(!this.hasOwnProperty(JSCompiler_renameProperty("_classProperties",this))){this._classProperties=new Map;const t=Object.getPrototypeOf(this)._classProperties;void 0!==t&&t.forEach((t,e)=>this._classProperties.set(e,t))}}static createProperty(t,e=k){if(this._ensureClassProperties(),this._classProperties.set(t,e),e.noAccessor||this.prototype.hasOwnProperty(t))return;const n="symbol"==typeof t?Symbol():"__"+t,r=this.getPropertyDescriptor(t,n,e);void 0!==r&&Object.defineProperty(this.prototype,t,r)}static getPropertyDescriptor(t,e,n){return{get(){return this[e]},set(r){const o=this[t];this[e]=r,this.requestUpdateInternal(t,o,n)},configurable:!0,enumerable:!0}}static getPropertyOptions(t){return this._classProperties&&this._classProperties.get(t)||k}static finalize(){const t=Object.getPrototypeOf(this);if(t.hasOwnProperty("finalized")||t.finalize(),this.finalized=!0,this._ensureClassProperties(),this._attributeToPropertyMap=new Map,this.hasOwnProperty(JSCompiler_renameProperty("properties",this))){const t=this.properties,e=[...Object.getOwnPropertyNames(t),..."function"==typeof Object.getOwnPropertySymbols?Object.getOwnPropertySymbols(t):[]];for(const n of e)this.createProperty(n,t[n])}}static _attributeNameForProperty(t,e){const n=e.attribute;return!1===n?void 0:"string"==typeof n?n:"string"==typeof t?t.toLowerCase():void 0}static _valueHasChanged(t,e,n=j){return n(t,e)}static _propertyValueFromAttribute(t,e){const n=e.type,r=e.converter||S,o="function"==typeof r?r:r.fromAttribute;return o?o(t,n):t}static _propertyValueToAttribute(t,e){if(void 0===e.reflect)return;const n=e.type,r=e.converter;return(r&&r.toAttribute||S.toAttribute)(t,n)}initialize(){this._updateState=0,this._updatePromise=new O.a(t=>this._enableUpdatingResolver=t),this._changedProperties=new Map,this._saveInstanceProperties(),this.requestUpdateInternal()}_saveInstanceProperties(){this.constructor._classProperties.forEach((t,e)=>{if(this.hasOwnProperty(e)){const t=this[e];delete this[e],this._instanceProperties||(this._instanceProperties=new Map),this._instanceProperties.set(e,t)}})}_applyInstanceProperties(){this._instanceProperties.forEach((t,e)=>this[e]=t),this._instanceProperties=void 0}connectedCallback(){this.enableUpdating()}enableUpdating(){void 0!==this._enableUpdatingResolver&&(this._enableUpdatingResolver(),this._enableUpdatingResolver=void 0)}disconnectedCallback(){}attributeChangedCallback(t,e,n){e!==n&&this._attributeToProperty(t,n)}_propertyToAttribute(t,e,n=k){const r=this.constructor,o=r._attributeNameForProperty(t,n);if(void 0!==o){const t=r._propertyValueToAttribute(e,n);if(void 0===t)return;this._updateState=8|this._updateState,null==t?this.removeAttribute(o):this.setAttribute(o,t),this._updateState=-9&this._updateState}}_attributeToProperty(t,e){if(8&this._updateState)return;const n=this.constructor,r=n._attributeToPropertyMap.get(t);if(void 0!==r){const t=n.getPropertyOptions(r);this._updateState=16|this._updateState,this[r]=n._propertyValueFromAttribute(e,t),this._updateState=-17&this._updateState}}requestUpdateInternal(t,e,n){let r=!0;if(void 0!==t){const o=this.constructor;n=n||o.getPropertyOptions(t),o._valueHasChanged(this[t],e,n.hasChanged)?(this._changedProperties.has(t)||this._changedProperties.set(t,e),!0!==n.reflect||16&this._updateState||(void 0===this._reflectingProperties&&(this._reflectingProperties=new Map),this._reflectingProperties.set(t,n))):r=!1}!this._hasRequestedUpdate&&r&&(this._updatePromise=this._enqueueUpdate())}requestUpdate(t,e){return this.requestUpdateInternal(t,e),this.updateComplete}async _enqueueUpdate(){this._updateState=4|this._updateState;try{await this._updatePromise}catch(t){}const t=this.performUpdate();return null!=t&&await t,!this._hasRequestedUpdate}get _hasRequestedUpdate(){return 4&this._updateState}get hasUpdated(){return 1&this._updateState}performUpdate(){if(!this._hasRequestedUpdate)return;this._instanceProperties&&this._applyInstanceProperties();let t=!1;const e=this._changedProperties;try{t=this.shouldUpdate(e),t?this.update(e):this._markUpdated()}catch(e){throw t=!1,this._markUpdated(),e}t&&(1&this._updateState||(this._updateState=1|this._updateState,this.firstUpdated(e)),this.updated(e))}_markUpdated(){this._changedProperties=new Map,this._updateState=-5&this._updateState}get updateComplete(){return this._getUpdateComplete()}_getUpdateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._updatePromise}shouldUpdate(t){return!0}update(t){void 0!==this._reflectingProperties&&this._reflectingProperties.size>0&&(this._reflectingProperties.forEach((t,e)=>this._propertyToAttribute(e,this[e],t)),this._reflectingProperties=void 0),this._markUpdated()}updated(t){}firstUpdated(t){}}A.finalized=!0;
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const T=t=>e=>"function"==typeof e?((t,e)=>(window.customElements.define(t,e),e))(t,e):((t,e)=>{const{kind:n,elements:r}=e;return{kind:n,elements:r,finisher(e){window.customElements.define(t,e)}}})(t,e),E=(t,e)=>"method"===e.kind&&e.descriptor&&!("value"in e.descriptor)?Object.assign(Object.assign({},e),{finisher(n){n.createProperty(e.key,t)}}):{kind:"field",key:Symbol(),placement:"own",descriptor:{},initializer(){"function"==typeof e.initializer&&(this[e.key]=e.initializer.call(this))},finisher(n){n.createProperty(e.key,t)}};function C(t){return(e,n)=>void 0!==n?((t,e,n)=>{e.constructor.createProperty(n,t)})(t,e,n):E(t,e)}function R(t){return C({attribute:!1,hasChanged:null==t?void 0:t.hasChanged})}function I(t,e){return(n,r)=>{const o={get(){return this.renderRoot.querySelector(t)},enumerable:!0,configurable:!0};if(e){const e=void 0!==r?r:n.key,i="symbol"==typeof e?Symbol():"__"+e;o.get=function(){return void 0===this[i]&&(this[i]=this.renderRoot.querySelector(t)),this[i]}}return void 0!==r?L(o,n,r):N(o,n)}}function P(t){return(e,n)=>{const r={async get(){return await this.updateComplete,this.renderRoot.querySelector(t)},enumerable:!0,configurable:!0};return void 0!==n?L(r,e,n):N(r,e)}}function M(t){return(e,n)=>{const r={get(){return this.renderRoot.querySelectorAll(t)},enumerable:!0,configurable:!0};return void 0!==n?L(r,e,n):N(r,e)}}const L=(t,e,n)=>{Object.defineProperty(e,n,t)},N=(t,e)=>({kind:"method",placement:"prototype",key:e.key,descriptor:t});function B(t){return(e,n)=>void 0!==n?((t,e,n)=>{Object.assign(e[n],t)})(t,e,n):((t,e)=>Object.assign(Object.assign({},e),{finisher(n){Object.assign(n.prototype[e.key],t)}}))(t,e)}const D=Element.prototype;D.msMatchesSelector||D.webkitMatchesSelector;n(18);
/**
@license
Copyright (c) 2019 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const U=window.ShadowRoot&&(void 0===window.ShadyCSS||window.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,$=Symbol();class z{constructor(t,e){if(e!==$)throw new Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=t}get styleSheet(){return void 0===this._styleSheet&&(U?(this._styleSheet=new CSSStyleSheet,this._styleSheet.replaceSync(this.cssText)):this._styleSheet=null),this._styleSheet}toString(){return this.cssText}}const V=(t,...e)=>{const n=a()(e).call(e,(e,n,r)=>e+(t=>{if(t instanceof z)return t.cssText;if("number"==typeof t)return t;throw new Error(`Value passed to 'css' function must be a 'css' function result: ${t}. Use 'unsafeCSS' to pass non-literal values, but\n            take care to ensure page security.`)})(n)+t[r+1],t[0]);return new z(n,$)};
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
(window.litElementVersions||(window.litElementVersions=[])).push("2.5.1");const q={};class F extends A{static getStyles(){return this.styles}static _getUniqueStyles(){if(this.hasOwnProperty(JSCompiler_renameProperty("_styles",this)))return;const t=this.getStyles();if(Array.isArray(t)){const e=(t,n)=>o()(t).call(t,(t,n)=>Array.isArray(n)?e(n,t):(t.add(n),t),n),n=e(t,new Set),r=[];n.forEach(t=>r.unshift(t)),this._styles=r}else this._styles=void 0===t?[]:[t];this._styles=this._styles.map(t=>{if(t instanceof CSSStyleSheet&&!U){var e;const n=a()(e=Array.prototype.slice.call(t.cssRules)).call(e,(t,e)=>t+e.cssText,"");return new z(String(n),$)}return t})}initialize(){super.initialize(),this.constructor._getUniqueStyles(),this.renderRoot=this.createRenderRoot(),window.ShadowRoot&&this.renderRoot instanceof window.ShadowRoot&&this.adoptStyles()}createRenderRoot(){return this.attachShadow(this.constructor.shadowRootOptions)}adoptStyles(){const t=this.constructor._styles;0!==t.length&&(void 0===window.ShadyCSS||window.ShadyCSS.nativeShadow?U?this.renderRoot.adoptedStyleSheets=t.map(t=>t instanceof CSSStyleSheet?t:t.styleSheet):this._needsShimAdoptedStyleSheets=!0:window.ShadyCSS.ScopingShim.prepareAdoptedCssText(t.map(t=>t.cssText),this.localName))}connectedCallback(){super.connectedCallback(),this.hasUpdated&&void 0!==window.ShadyCSS&&window.ShadyCSS.styleElement(this)}update(t){const e=this.render();super.update(t),e!==q&&this.constructor.render(e,this.renderRoot,{scopeName:this.localName,eventContext:this}),this._needsShimAdoptedStyleSheets&&(this._needsShimAdoptedStyleSheets=!1,this.constructor._styles.forEach(t=>{const e=document.createElement("style");e.textContent=t.cssText,this.renderRoot.appendChild(e)}))}render(){return q}}F.finalized=!0,F.render=(t,e,n)=>{if(!n||"object"!=typeof n||!n.scopeName)throw new Error("The `scopeName` option is required.");const r=n.scopeName,o=h.a.has(e),i=m&&11===e.nodeType&&!!e.host,a=i&&!w.has(r),c=a?document.createDocumentFragment():e;if(Object(h.b)(t,c,Object.assign({templateFactory:y(r)},n)),a){const t=h.a.get(c);h.a.delete(c);const n=t.value instanceof f.a?t.value.template:void 0;x(r,c,n),Object(s.b)(e,e.firstChild),e.appendChild(c),h.a.set(e,t)}!o&&i&&window.ShadyCSS.styleElement(e.host)},F.shadowRootOptions={mode:"open"}},function(t,e,n){"use strict";n.r(e),n.d(e,"i18n",(function(){return p})),n.d(e,"IS_ZH",(function(){return h})),n.d(e,"initMasterI18n",(function(){return d})),n.d(e,"initI18n",(function(){return f})),n.d(e,"setLangToLocal",(function(){return g})),n.d(e,"getLangFromLocal",(function(){return v}));var r=n(67),o=n.n(r),i=(n(13),n(17),n(18),n(44),n(10),n(0)),a=n(106),s=n.n(a),c=n(26),u=n.n(c);let l={};const p=function(t,e){var n;if(i.l)return chrome.i18n.getMessage(t,e)||t;if(i.r){const r=null===(n=l[t])||void 0===n?void 0:n.message,o=[];"string"==typeof e?o.push(e):Array.isArray(e)&&o.push(...e);const i=/(\$.+?\$)/g;let a=i.exec(r),s=r;for(;a;){let[t]=o.splice(0,1);void 0===t&&(t=""),s=s.replace(a[1],t),a=i.exec(r)}return s||t}return t};i.s?o.a.i18n=p:window.i18n=p;const h="zh-CN"===i.C.lang;async function d(){const t=await v();l=t}async function f(){if(!i.r)return;const{slave:t}=await Promise.all([n.e(29),n.e(37)]).then(n.bind(null,178)),e=i.C.lang;try{const n=await v(),r=localStorage.getItem("setLangCode"),o=localStorage.getItem("langCode");(null!==r&&null!==n||o===e&&null!==n)&&(l=n),await async function(t){const e=t.replace("-","_"),n=(await s.a.get(`${i.A}/_locales/${Object(i.D)(e)}/messages.json?v=1636012211095`)).data;Object.keys(n).length>50&&(l=n,localStorage.setItem("langCode",t),g(n))}(r?o:e),t.postTask("slave:master-init-i18n",l)}catch(t){}}function g(t){return u.a.setItem("current-language",t)}function v(){return u.a.getItem("current-language")}},function(t,e,n){"use strict";(function(t,r){n.d(e,"a",(function(){return Ut})),n.d(e,"b",(function(){return Xt})),n.d(e,"c",(function(){return Jt})),n.d(e,"d",(function(){return j})),n.d(e,"e",(function(){return nt})),n.d(e,"f",(function(){return re})),n.d(e,"g",(function(){return K})),n.d(e,"h",(function(){return te})),n.d(e,"i",(function(){return Yt})),n.d(e,"j",(function(){return fe}));var o=[];Object.freeze(o);var i={};function a(){return++Rt.mobxGuid}function s(t){throw c(!1,t),"X"}function c(t,e){if(!t)throw new Error("[mobx] "+(e||"An invariant failed, however the error is obfuscated because this is a production build."))}Object.freeze(i);function u(t){var e=!1;return function(){if(!e)return e=!0,t.apply(this,arguments)}}var l=function(){};function p(t){return null!==t&&"object"==typeof t}function h(t){if(null===t||"object"!=typeof t)return!1;var e=Object.getPrototypeOf(t);return e===Object.prototype||null===e}function d(t,e,n){Object.defineProperty(t,e,{enumerable:!1,writable:!0,configurable:!0,value:n})}function f(t,e){var n="isMobX"+t;return e.prototype[n]=!0,function(t){return p(t)&&!0===t[n]}}function g(t){return t instanceof Map}function v(t){return t instanceof Set}function m(t){var e=new Set;for(var n in t)e.add(n);return Object.getOwnPropertySymbols(t).forEach((function(n){Object.getOwnPropertyDescriptor(t,n).enumerable&&e.add(n)})),Array.from(e)}function y(t){return t&&t.toString?t.toString():new String(t).toString()}function b(t){return null===t?null:"object"==typeof t?""+t:t}var w="undefined"!=typeof Reflect&&Reflect.ownKeys?Reflect.ownKeys:Object.getOwnPropertySymbols?function(t){return Object.getOwnPropertyNames(t).concat(Object.getOwnPropertySymbols(t))}:Object.getOwnPropertyNames,x=Symbol("mobx administration"),_=function(){function t(t){void 0===t&&(t="Atom@"+a()),this.name=t,this.isPendingUnobservation=!1,this.isBeingObserved=!1,this.observers=new Set,this.diffValue=0,this.lastAccessedBy=0,this.lowestObserverState=Q.NOT_TRACKING}return t.prototype.onBecomeObserved=function(){this.onBecomeObservedListeners&&this.onBecomeObservedListeners.forEach((function(t){return t()}))},t.prototype.onBecomeUnobserved=function(){this.onBecomeUnobservedListeners&&this.onBecomeUnobservedListeners.forEach((function(t){return t()}))},t.prototype.reportObserved=function(){return Bt(this)},t.prototype.reportChanged=function(){Lt(),function(t){if(t.lowestObserverState===Q.STALE)return;t.lowestObserverState=Q.STALE,t.observers.forEach((function(e){e.dependenciesState===Q.UP_TO_DATE&&(e.isTracing!==Z.NONE&&Dt(e,t),e.onBecomeStale()),e.dependenciesState=Q.STALE}))}(this),Nt()},t.prototype.toString=function(){return this.name},t}(),O=f("Atom",_);function S(t,e,n){void 0===e&&(e=l),void 0===n&&(n=l);var r,o=new _(t);return e!==l&&ne("onBecomeObserved",o,e,r),n!==l&&ee(o,n),o}var j={identity:function(t,e){return t===e},structural:function(t,e){return Je(t,e)},default:function(t,e){return Object.is(t,e)},shallow:function(t,e){return Je(t,e,1)}},k=function(t,e){return(k=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var n in e)e.hasOwnProperty(n)&&(t[n]=e[n])})(t,e)};
/*! *****************************************************************************
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */var A=function(){return(A=Object.assign||function(t){for(var e,n=1,r=arguments.length;n<r;n++)for(var o in e=arguments[n])Object.prototype.hasOwnProperty.call(e,o)&&(t[o]=e[o]);return t}).apply(this,arguments)};function T(t){var e="function"==typeof Symbol&&t[Symbol.iterator],n=0;return e?e.call(t):{next:function(){return t&&n>=t.length&&(t=void 0),{value:t&&t[n++],done:!t}}}}function E(t,e){var n="function"==typeof Symbol&&t[Symbol.iterator];if(!n)return t;var r,o,i=n.call(t),a=[];try{for(;(void 0===e||e-- >0)&&!(r=i.next()).done;)a.push(r.value)}catch(t){o={error:t}}finally{try{r&&!r.done&&(n=i.return)&&n.call(i)}finally{if(o)throw o.error}}return a}function C(){for(var t=[],e=0;e<arguments.length;e++)t=t.concat(E(arguments[e]));return t}var R=Symbol("mobx did run lazy initializers"),I=Symbol("mobx pending decorators"),P={},M={};function L(t,e){var n=e?P:M;return n[t]||(n[t]={configurable:!0,enumerable:e,get:function(){return N(this),this[t]},set:function(e){N(this),this[t]=e}})}function N(t){var e,n;if(!0!==t[R]){var r=t[I];if(r){d(t,R,!0);var o=C(Object.getOwnPropertySymbols(r),Object.keys(r));try{for(var i=T(o),a=i.next();!a.done;a=i.next()){var s=r[a.value];s.propertyCreator(t,s.prop,s.descriptor,s.decoratorTarget,s.decoratorArguments)}}catch(t){e={error:t}}finally{try{a&&!a.done&&(n=i.return)&&n.call(i)}finally{if(e)throw e.error}}}}}function B(t,e){return function(){var n,r=function(r,o,i,a){if(!0===a)return e(r,o,i,r,n),null;if(!Object.prototype.hasOwnProperty.call(r,I)){var s=r[I];d(r,I,A({},s))}return r[I][o]={prop:o,propertyCreator:e,descriptor:i,decoratorTarget:r,decoratorArguments:n},L(o,t)};return D(arguments)?(n=o,r.apply(null,arguments)):(n=Array.prototype.slice.call(arguments),r)}}function D(t){return(2===t.length||3===t.length)&&("string"==typeof t[1]||"symbol"==typeof t[1])||4===t.length&&!0===t[3]}function U(t,e,n){return le(t)?t:Array.isArray(t)?K.array(t,{name:n}):h(t)?K.object(t,void 0,{name:n}):g(t)?K.map(t,{name:n}):v(t)?K.set(t,{name:n}):t}function $(t){return t}function z(e){c(e);var n=B(!0,(function(t,n,r,o,i){var a=r?r.initializer?r.initializer.call(t):r.value:void 0;Ve(t).addObservableProp(n,a,e)})),r=(void 0!==t&&t.env,n);return r.enhancer=e,r}var V={deep:!0,name:void 0,defaultDecorator:void 0,proxy:!0};function q(t){return null==t?V:"string"==typeof t?{name:t,deep:!0,proxy:!0}:t}Object.freeze(V);var F=z(U),H=z((function(t,e,n){return null==t||Ge(t)||Pe(t)||Be(t)||$e(t)?t:Array.isArray(t)?K.array(t,{name:n,deep:!1}):h(t)?K.object(t,void 0,{name:n,deep:!1}):g(t)?K.map(t,{name:n,deep:!1}):v(t)?K.set(t,{name:n,deep:!1}):s(!1)})),W=z($),G=z((function(t,e,n){return Je(t,e)?e:t}));function X(t){return t.defaultDecorator?t.defaultDecorator.enhancer:!1===t.deep?$:U}var Y={box:function(t,e){arguments.length>2&&J("box");var n=q(e);return new _t(t,X(n),n.name,!0,n.equals)},array:function(t,e){arguments.length>2&&J("array");var n=q(e);return Te(t,X(n),n.name)},map:function(t,e){arguments.length>2&&J("map");var n=q(e);return new Ne(t,X(n),n.name)},set:function(t,e){arguments.length>2&&J("set");var n=q(e);return new Ue(t,X(n),n.name)},object:function(t,e,n){"string"==typeof arguments[1]&&J("object");var r=q(n);if(!1===r.proxy)return oe({},t,e,r);var o=ie(r),i=oe({},void 0,void 0,r),a=we(i);return ae(a,t,e,o),a},ref:W,shallow:H,deep:F,struct:G},K=function(t,e,n){if("string"==typeof arguments[1]||"symbol"==typeof arguments[1])return F.apply(null,arguments);if(le(t))return t;var r=h(t)?K.object(t,e,n):Array.isArray(t)?K.array(t,e):g(t)?K.map(t,e):v(t)?K.set(t,e):t;if(r!==t)return r;s(!1)};function J(t){s("Expected one or two arguments to observable."+t+". Did you accidentally try to use observable."+t+" as decorator?")}Object.keys(Y).forEach((function(t){return K[t]=Y[t]}));var Q,Z,tt=B(!1,(function(t,e,n,r,o){var i=n.get,a=n.set,s=o[0]||{};Ve(t).addComputedProp(t,e,A({get:i,set:a,context:t},s))})),et=tt({equals:j.structural}),nt=function(t,e,n){if("string"==typeof e)return tt.apply(null,arguments);if(null!==t&&"object"==typeof t&&1===arguments.length)return tt.apply(null,arguments);var r="object"==typeof e?e:{};return r.get=t,r.set="function"==typeof e?e:r.set,r.name=r.name||t.name||"",new St(r)};nt.struct=et,function(t){t[t.NOT_TRACKING=-1]="NOT_TRACKING",t[t.UP_TO_DATE=0]="UP_TO_DATE",t[t.POSSIBLY_STALE=1]="POSSIBLY_STALE",t[t.STALE=2]="STALE"}(Q||(Q={})),function(t){t[t.NONE=0]="NONE",t[t.LOG=1]="LOG",t[t.BREAK=2]="BREAK"}(Z||(Z={}));var rt=function(t){this.cause=t};function ot(t){return t instanceof rt}function it(t){switch(t.dependenciesState){case Q.UP_TO_DATE:return!1;case Q.NOT_TRACKING:case Q.STALE:return!0;case Q.POSSIBLY_STALE:for(var e=ht(!0),n=lt(),r=t.observing,o=r.length,i=0;i<o;i++){var a=r[i];if(jt(a)){if(Rt.disableErrorBoundaries)a.get();else try{a.get()}catch(t){return pt(n),dt(e),!0}if(t.dependenciesState===Q.STALE)return pt(n),dt(e),!0}}return ft(t),pt(n),dt(e),!1}}function at(t){var e=t.observers.size>0;Rt.computationDepth>0&&e&&s(!1),Rt.allowStateChanges||!e&&"strict"!==Rt.enforceActions||s(!1)}function st(t,e,n){var r=ht(!0);ft(t),t.newObserving=new Array(t.observing.length+100),t.unboundDepsCount=0,t.runId=++Rt.runId;var o,i=Rt.trackingDerivation;if(Rt.trackingDerivation=t,!0===Rt.disableErrorBoundaries)o=e.call(n);else try{o=e.call(n)}catch(t){o=new rt(t)}return Rt.trackingDerivation=i,function(t){for(var e=t.observing,n=t.observing=t.newObserving,r=Q.UP_TO_DATE,o=0,i=t.unboundDepsCount,a=0;a<i;a++){0===(s=n[a]).diffValue&&(s.diffValue=1,o!==a&&(n[o]=s),o++),s.dependenciesState>r&&(r=s.dependenciesState)}n.length=o,t.newObserving=null,i=e.length;for(;i--;){0===(s=e[i]).diffValue&&Pt(s,t),s.diffValue=0}for(;o--;){var s;1===(s=n[o]).diffValue&&(s.diffValue=0,It(s,t))}r!==Q.UP_TO_DATE&&(t.dependenciesState=r,t.onBecomeStale())}(t),dt(r),o}function ct(t){var e=t.observing;t.observing=[];for(var n=e.length;n--;)Pt(e[n],t);t.dependenciesState=Q.NOT_TRACKING}function ut(t){var e=lt();try{return t()}finally{pt(e)}}function lt(){var t=Rt.trackingDerivation;return Rt.trackingDerivation=null,t}function pt(t){Rt.trackingDerivation=t}function ht(t){var e=Rt.allowStateReads;return Rt.allowStateReads=t,e}function dt(t){Rt.allowStateReads=t}function ft(t){if(t.dependenciesState!==Q.UP_TO_DATE){t.dependenciesState=Q.UP_TO_DATE;for(var e=t.observing,n=e.length;n--;)e[n].lowestObserverState=Q.UP_TO_DATE}}var gt=0,vt=1,mt=Object.getOwnPropertyDescriptor((function(){}),"name");mt&&mt.configurable;function yt(t,e,n){var r=function(){return bt(t,e,n||this,arguments)};return r.isMobxAction=!0,r}function bt(t,e,n,r){var o=function(t,e,n){var r=0;var o=lt();Lt();var i=wt(!0),a=ht(!0),s={prevDerivation:o,prevAllowStateChanges:i,prevAllowStateReads:a,notifySpy:!1,startTime:r,actionId:vt++,parentActionId:gt};return gt=s.actionId,s}();try{return e.apply(n,r)}catch(t){throw o.error=t,t}finally{!function(t){gt!==t.actionId&&s("invalid action stack. did you forget to finish an action?");gt=t.parentActionId,void 0!==t.error&&(Rt.suppressReactionErrors=!0);xt(t.prevAllowStateChanges),dt(t.prevAllowStateReads),Nt(),pt(t.prevDerivation),t.notifySpy&&!1;Rt.suppressReactionErrors=!1}(o)}}function wt(t){var e=Rt.allowStateChanges;return Rt.allowStateChanges=t,e}function xt(t){Rt.allowStateChanges=t}var _t=function(t){function e(e,n,r,o,i){void 0===r&&(r="ObservableValue@"+a()),void 0===o&&(o=!0),void 0===i&&(i=j.default);var s=t.call(this,r)||this;return s.enhancer=n,s.name=r,s.equals=i,s.hasUnreportedChange=!1,s.value=n(e,void 0,r),s}return function(t,e){function n(){this.constructor=t}k(t,e),t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)}(e,t),e.prototype.dehanceValue=function(t){return void 0!==this.dehancer?this.dehancer(t):t},e.prototype.set=function(t){this.value;if((t=this.prepareNewValue(t))!==Rt.UNCHANGED){0,this.setNewValue(t)}},e.prototype.prepareNewValue=function(t){if(at(this),xe(this)){var e=Oe(this,{object:this,type:"update",newValue:t});if(!e)return Rt.UNCHANGED;t=e.newValue}return t=this.enhancer(t,this.value,this.name),this.equals(this.value,t)?Rt.UNCHANGED:t},e.prototype.setNewValue=function(t){var e=this.value;this.value=t,this.reportChanged(),Se(this)&&ke(this,{type:"update",object:this,newValue:t,oldValue:e})},e.prototype.get=function(){return this.reportObserved(),this.dehanceValue(this.value)},e.prototype.intercept=function(t){return _e(this,t)},e.prototype.observe=function(t,e){return e&&t({object:this,type:"update",newValue:this.value,oldValue:void 0}),je(this,t)},e.prototype.toJSON=function(){return this.get()},e.prototype.toString=function(){return this.name+"["+this.value+"]"},e.prototype.valueOf=function(){return b(this.get())},e.prototype[Symbol.toPrimitive]=function(){return this.valueOf()},e}(_),Ot=f("ObservableValue",_t),St=function(){function t(t){this.dependenciesState=Q.NOT_TRACKING,this.observing=[],this.newObserving=null,this.isBeingObserved=!1,this.isPendingUnobservation=!1,this.observers=new Set,this.diffValue=0,this.runId=0,this.lastAccessedBy=0,this.lowestObserverState=Q.UP_TO_DATE,this.unboundDepsCount=0,this.__mapid="#"+a(),this.value=new rt(null),this.isComputing=!1,this.isRunningSetter=!1,this.isTracing=Z.NONE,c(t.get,"missing option for computed: get"),this.derivation=t.get,this.name=t.name||"ComputedValue@"+a(),t.set&&(this.setter=yt(this.name+"-setter",t.set)),this.equals=t.equals||(t.compareStructural||t.struct?j.structural:j.default),this.scope=t.context,this.requiresReaction=!!t.requiresReaction,this.keepAlive=!!t.keepAlive}return t.prototype.onBecomeStale=function(){!function(t){if(t.lowestObserverState!==Q.UP_TO_DATE)return;t.lowestObserverState=Q.POSSIBLY_STALE,t.observers.forEach((function(e){e.dependenciesState===Q.UP_TO_DATE&&(e.dependenciesState=Q.POSSIBLY_STALE,e.isTracing!==Z.NONE&&Dt(e,t),e.onBecomeStale())}))}(this)},t.prototype.onBecomeObserved=function(){this.onBecomeObservedListeners&&this.onBecomeObservedListeners.forEach((function(t){return t()}))},t.prototype.onBecomeUnobserved=function(){this.onBecomeUnobservedListeners&&this.onBecomeUnobservedListeners.forEach((function(t){return t()}))},t.prototype.get=function(){this.isComputing&&s("Cycle detected in computation "+this.name+": "+this.derivation),0!==Rt.inBatch||0!==this.observers.size||this.keepAlive?(Bt(this),it(this)&&this.trackAndCompute()&&function(t){if(t.lowestObserverState===Q.STALE)return;t.lowestObserverState=Q.STALE,t.observers.forEach((function(e){e.dependenciesState===Q.POSSIBLY_STALE?e.dependenciesState=Q.STALE:e.dependenciesState===Q.UP_TO_DATE&&(t.lowestObserverState=Q.UP_TO_DATE)}))}(this)):it(this)&&(this.warnAboutUntrackedRead(),Lt(),this.value=this.computeValue(!1),Nt());var t=this.value;if(ot(t))throw t.cause;return t},t.prototype.peek=function(){var t=this.computeValue(!1);if(ot(t))throw t.cause;return t},t.prototype.set=function(t){if(this.setter){c(!this.isRunningSetter,"The setter of computed value '"+this.name+"' is trying to update itself. Did you intend to update an _observable_ value, instead of the computed property?"),this.isRunningSetter=!0;try{this.setter.call(this.scope,t)}finally{this.isRunningSetter=!1}}else c(!1,!1)},t.prototype.trackAndCompute=function(){var t=this.value,e=this.dependenciesState===Q.NOT_TRACKING,n=this.computeValue(!0),r=e||ot(t)||ot(n)||!this.equals(t,n);return r&&(this.value=n),r},t.prototype.computeValue=function(t){var e;if(this.isComputing=!0,Rt.computationDepth++,t)e=st(this,this.derivation,this.scope);else if(!0===Rt.disableErrorBoundaries)e=this.derivation.call(this.scope);else try{e=this.derivation.call(this.scope)}catch(t){e=new rt(t)}return Rt.computationDepth--,this.isComputing=!1,e},t.prototype.suspend=function(){this.keepAlive||(ct(this),this.value=void 0)},t.prototype.observe=function(t,e){var n=this,r=!0,o=void 0;return Jt((function(){var i=n.get();if(!r||e){var a=lt();t({type:"update",object:n,newValue:i,oldValue:o}),pt(a)}r=!1,o=i}))},t.prototype.warnAboutUntrackedRead=function(){},t.prototype.toJSON=function(){return this.get()},t.prototype.toString=function(){return this.name+"["+this.derivation.toString()+"]"},t.prototype.valueOf=function(){return b(this.get())},t.prototype[Symbol.toPrimitive]=function(){return this.valueOf()},t}(),jt=f("ComputedValue",St),kt=function(){this.version=5,this.UNCHANGED={},this.trackingDerivation=null,this.computationDepth=0,this.runId=0,this.mobxGuid=0,this.inBatch=0,this.pendingUnobservations=[],this.pendingReactions=[],this.isRunningReactions=!1,this.allowStateChanges=!0,this.allowStateReads=!0,this.enforceActions=!1,this.spyListeners=[],this.globalReactionErrorHandlers=[],this.computedRequiresReaction=!1,this.reactionRequiresObservable=!1,this.observableRequiresReaction=!1,this.computedConfigurable=!1,this.disableErrorBoundaries=!1,this.suppressReactionErrors=!1},At={};function Tt(){return"undefined"!=typeof window?window:void 0!==r?r:"undefined"!=typeof self?self:At}var Et=!0,Ct=!1,Rt=function(){var t=Tt();return t.__mobxInstanceCount>0&&!t.__mobxGlobals&&(Et=!1),t.__mobxGlobals&&t.__mobxGlobals.version!==(new kt).version&&(Et=!1),Et?t.__mobxGlobals?(t.__mobxInstanceCount+=1,t.__mobxGlobals.UNCHANGED||(t.__mobxGlobals.UNCHANGED={}),t.__mobxGlobals):(t.__mobxInstanceCount=1,t.__mobxGlobals=new kt):(setTimeout((function(){Ct||s("There are multiple, different versions of MobX active. Make sure MobX is loaded only once or use `configure({ isolateGlobalState: true })`")}),1),new kt)}();function It(t,e){t.observers.add(e),t.lowestObserverState>e.dependenciesState&&(t.lowestObserverState=e.dependenciesState)}function Pt(t,e){t.observers.delete(e),0===t.observers.size&&Mt(t)}function Mt(t){!1===t.isPendingUnobservation&&(t.isPendingUnobservation=!0,Rt.pendingUnobservations.push(t))}function Lt(){Rt.inBatch++}function Nt(){if(0==--Rt.inBatch){zt();for(var t=Rt.pendingUnobservations,e=0;e<t.length;e++){var n=t[e];n.isPendingUnobservation=!1,0===n.observers.size&&(n.isBeingObserved&&(n.isBeingObserved=!1,n.onBecomeUnobserved()),n instanceof St&&n.suspend())}Rt.pendingUnobservations=[]}}function Bt(t){var e=Rt.trackingDerivation;return null!==e?(e.runId!==t.lastAccessedBy&&(t.lastAccessedBy=e.runId,e.newObserving[e.unboundDepsCount++]=t,t.isBeingObserved||(t.isBeingObserved=!0,t.onBecomeObserved())),!0):(0===t.observers.size&&Rt.inBatch>0&&Mt(t),!1)}function Dt(t,e){if(console.log("[mobx.trace] '"+t.name+"' is invalidated due to a change in: '"+e.name+"'"),t.isTracing===Z.BREAK){var n=[];!function t(e,n,r){if(n.length>=1e3)return void n.push("(and many more)");n.push(""+new Array(r).join("\t")+e.name),e.dependencies&&e.dependencies.forEach((function(e){return t(e,n,r+1)}))}((r=t,se(Xe(r,o))),n,1),new Function("debugger;\n/*\nTracing '"+t.name+"'\n\nYou are entering this break point because derivation '"+t.name+"' is being traced and '"+e.name+"' is now forcing it to update.\nJust follow the stacktrace you should now see in the devtools to see precisely what piece of your code is causing this update\nThe stackframe you are looking for is at least ~6-8 stack-frames up.\n\n"+(t instanceof St?t.derivation.toString().replace(/[*]\//g,"/"):"")+"\n\nThe dependencies for this derivation are:\n\n"+n.join("\n")+"\n*/\n    ")()}var r,o}var Ut=function(){function t(t,e,n,r){void 0===t&&(t="Reaction@"+a()),void 0===r&&(r=!1),this.name=t,this.onInvalidate=e,this.errorHandler=n,this.requiresObservable=r,this.observing=[],this.newObserving=[],this.dependenciesState=Q.NOT_TRACKING,this.diffValue=0,this.runId=0,this.unboundDepsCount=0,this.__mapid="#"+a(),this.isDisposed=!1,this._isScheduled=!1,this._isTrackPending=!1,this._isRunning=!1,this.isTracing=Z.NONE}return t.prototype.onBecomeStale=function(){this.schedule()},t.prototype.schedule=function(){this._isScheduled||(this._isScheduled=!0,Rt.pendingReactions.push(this),zt())},t.prototype.isScheduled=function(){return this._isScheduled},t.prototype.runReaction=function(){if(!this.isDisposed){if(Lt(),this._isScheduled=!1,it(this)){this._isTrackPending=!0;try{this.onInvalidate(),this._isTrackPending}catch(t){this.reportExceptionInDerivation(t)}}Nt()}},t.prototype.track=function(t){if(!this.isDisposed){Lt();0,this._isRunning=!0;var e=st(this,t,void 0);this._isRunning=!1,this._isTrackPending=!1,this.isDisposed&&ct(this),ot(e)&&this.reportExceptionInDerivation(e.cause),Nt()}},t.prototype.reportExceptionInDerivation=function(t){var e=this;if(this.errorHandler)this.errorHandler(t,this);else{if(Rt.disableErrorBoundaries)throw t;var n="[mobx] Encountered an uncaught exception that was thrown by a reaction or observer component, in: '"+this+"'";Rt.suppressReactionErrors?console.warn("[mobx] (error in reaction '"+this.name+"' suppressed, fix error of causing action below)"):console.error(n,t),Rt.globalReactionErrorHandlers.forEach((function(n){return n(t,e)}))}},t.prototype.dispose=function(){this.isDisposed||(this.isDisposed=!0,this._isRunning||(Lt(),ct(this),Nt()))},t.prototype.getDisposer=function(){var t=this.dispose.bind(this);return t[x]=this,t},t.prototype.toString=function(){return"Reaction["+this.name+"]"},t.prototype.trace=function(t){void 0===t&&(t=!1),function(){for(var t=[],e=0;e<arguments.length;e++)t[e]=arguments[e];var n=!1;"boolean"==typeof t[t.length-1]&&(n=t.pop());var r=ge(t);if(!r)return s(!1);r.isTracing===Z.NONE&&console.log("[mobx.trace] '"+r.name+"' tracing enabled");r.isTracing=n?Z.BREAK:Z.LOG}(this,t)},t}();var $t=function(t){return t()};function zt(){Rt.inBatch>0||Rt.isRunningReactions||$t(Vt)}function Vt(){Rt.isRunningReactions=!0;for(var t=Rt.pendingReactions,e=0;t.length>0;){100==++e&&(console.error("Reaction doesn't converge to a stable state after 100 iterations. Probably there is a cycle in the reactive function: "+t[0]),t.splice(0));for(var n=t.splice(0),r=0,o=n.length;r<o;r++)n[r].runReaction()}Rt.isRunningReactions=!1}var qt=f("Reaction",Ut);function Ft(t){var e=$t;$t=function(n){return t((function(){return e(n)}))}}function Ht(){s(!1)}function Wt(t){return function(e,n,r){if(r){if(r.value)return{value:yt(t,r.value),enumerable:!1,configurable:!0,writable:!0};var o=r.initializer;return{enumerable:!1,configurable:!0,writable:!0,initializer:function(){return yt(t,o.call(this))}}}return Gt(t).apply(this,arguments)}}function Gt(t){return function(e,n,r){Object.defineProperty(e,n,{configurable:!0,enumerable:!1,get:function(){},set:function(e){d(this,n,Xt(t,e))}})}}var Xt=function(t,e,n,r){return 1===arguments.length&&"function"==typeof t?yt(t.name||"<unnamed action>",t):2===arguments.length&&"function"==typeof e?yt(t,e):1===arguments.length&&"string"==typeof t?Wt(t):!0!==r?Wt(e).apply(null,arguments):void d(t,e,yt(t.name||e,n.value,this))};function Yt(t,e){"string"==typeof t||t.name;return bt(0,"function"==typeof t?t:e,this,void 0)}function Kt(t,e,n){d(t,e,yt(e,n.bind(t)))}function Jt(t,e){void 0===e&&(e=i);var n,r=e&&e.name||t.name||"Autorun@"+a();if(!e.scheduler&&!e.delay)n=new Ut(r,(function(){this.track(c)}),e.onError,e.requiresObservable);else{var o=Zt(e),s=!1;n=new Ut(r,(function(){s||(s=!0,o((function(){s=!1,n.isDisposed||n.track(c)})))}),e.onError,e.requiresObservable)}function c(){t(n)}return n.schedule(),n.getDisposer()}Xt.bound=function(t,e,n,r){return!0===r?(Kt(t,e,n.value),null):n?{configurable:!0,enumerable:!1,get:function(){return Kt(this,e,n.value||n.initializer.call(this)),this[e]},set:Ht}:{enumerable:!1,configurable:!0,set:function(t){Kt(this,e,t)},get:function(){}}};var Qt=function(t){return t()};function Zt(t){return t.scheduler?t.scheduler:t.delay?function(e){return setTimeout(e,t.delay)}:Qt}function te(t,e,n){void 0===n&&(n=i);var r,o,s,c=n.name||"Reaction@"+a(),u=Xt(c,n.onError?(r=n.onError,o=e,function(){try{return o.apply(this,arguments)}catch(t){r.call(this,t)}}):e),l=!n.scheduler&&!n.delay,p=Zt(n),h=!0,d=!1,f=n.compareStructural?j.structural:n.equals||j.default,g=new Ut(c,(function(){h||l?v():d||(d=!0,p(v))}),n.onError,n.requiresObservable);function v(){if(d=!1,!g.isDisposed){var e=!1;g.track((function(){var n=t(g);e=h||!f(s,n),s=n})),h&&n.fireImmediately&&u(s,g),h||!0!==e||u(s,g),h&&(h=!1)}}return g.schedule(),g.getDisposer()}function ee(t,e,n){return ne("onBecomeUnobserved",t,e,n)}function ne(t,e,n,r){var o="function"==typeof r?Xe(e,n):Xe(e),i="function"==typeof r?r:n,a=t+"Listeners";return o[a]?o[a].add(i):o[a]=new Set([i]),"function"!=typeof o[t]?s(!1):function(){var t=o[a];t&&(t.delete(i),0===t.size&&delete o[a])}}function re(t){var e=t.enforceActions,n=t.computedRequiresReaction,r=t.computedConfigurable,o=t.disableErrorBoundaries,i=t.reactionScheduler,a=t.reactionRequiresObservable,c=t.observableRequiresReaction;if(!0===t.isolateGlobalState&&((Rt.pendingReactions.length||Rt.inBatch||Rt.isRunningReactions)&&s("isolateGlobalState should be called before MobX is running any reactions"),Ct=!0,Et&&(0==--Tt().__mobxInstanceCount&&(Tt().__mobxGlobals=void 0),Rt=new kt)),void 0!==e){var u=void 0;switch(e){case!0:case"observed":u=!0;break;case!1:case"never":u=!1;break;case"strict":case"always":u="strict";break;default:s("Invalid value for 'enforceActions': '"+e+"', expected 'never', 'always' or 'observed'")}Rt.enforceActions=u,Rt.allowStateChanges=!0!==u&&"strict"!==u}void 0!==n&&(Rt.computedRequiresReaction=!!n),void 0!==a&&(Rt.reactionRequiresObservable=!!a),void 0!==c&&(Rt.observableRequiresReaction=!!c,Rt.allowStateReads=!Rt.observableRequiresReaction),void 0!==r&&(Rt.computedConfigurable=!!r),void 0!==o&&(!0===o&&console.warn("WARNING: Debug feature only. MobX will NOT recover from errors when `disableErrorBoundaries` is enabled."),Rt.disableErrorBoundaries=!!o),i&&Ft(i)}function oe(t,e,n,r){var o=ie(r=q(r));return N(t),Ve(t,r.name,o.enhancer),e&&ae(t,e,n,o),t}function ie(t){return t.defaultDecorator||(!1===t.deep?W:F)}function ae(t,e,n,r){var o,i;Lt();try{var a=w(e);try{for(var s=T(a),c=s.next();!c.done;c=s.next()){var u=c.value,l=Object.getOwnPropertyDescriptor(e,u);0;var p=(n&&u in n?n[u]:l.get?tt:r)(t,u,l,!0);p&&Object.defineProperty(t,u,p)}}catch(t){o={error:t}}finally{try{c&&!c.done&&(i=s.return)&&i.call(s)}finally{if(o)throw o.error}}}finally{Nt()}}function se(t){var e,n,r={name:t.name};return t.observing&&t.observing.length>0&&(r.dependencies=(e=t.observing,n=[],e.forEach((function(t){-1===n.indexOf(t)&&n.push(t)})),n).map(se)),r}function ce(){this.message="FLOW_CANCELLED"}function ue(t,e){return null!=t&&(void 0!==e?!!Ge(t)&&t[x].values.has(e):Ge(t)||!!t[x]||O(t)||qt(t)||jt(t))}function le(t){return 1!==arguments.length&&s(!1),ue(t)}function pe(t){return Ge(t)?t[x].getKeys():Be(t)||$e(t)?Array.from(t.keys()):Pe(t)?t.map((function(t,e){return e})):s(!1)}ce.prototype=Object.create(Error.prototype);var he={detectCycles:!0,exportMapsAsObjects:!0,recurseEverything:!1};function de(t,e,n,r){return r.detectCycles&&t.set(e,n),n}function fe(t,e){var n;return"boolean"==typeof e&&(e={detectCycles:e}),e||(e=he),e.detectCycles=void 0===e.detectCycles?!0===e.recurseEverything:!0===e.detectCycles,e.detectCycles&&(n=new Map),function t(e,n,r){if(!n.recurseEverything&&!le(e))return e;if("object"!=typeof e)return e;if(null===e)return null;if(e instanceof Date)return e;if(Ot(e))return t(e.get(),n,r);if(le(e)&&pe(e),!0===n.detectCycles&&null!==e&&r.has(e))return r.get(e);if(Pe(e)||Array.isArray(e)){var o=de(r,e,[],n),i=e.map((function(e){return t(e,n,r)}));o.length=i.length;for(var a=0,s=i.length;a<s;a++)o[a]=i[a];return o}if($e(e)||Object.getPrototypeOf(e)===Set.prototype){if(!1===n.exportMapsAsObjects){var c=de(r,e,new Set,n);return e.forEach((function(e){c.add(t(e,n,r))})),c}var u=de(r,e,[],n);return e.forEach((function(e){u.push(t(e,n,r))})),u}if(Be(e)||Object.getPrototypeOf(e)===Map.prototype){if(!1===n.exportMapsAsObjects){var l=de(r,e,new Map,n);return e.forEach((function(e,o){l.set(o,t(e,n,r))})),l}var p=de(r,e,{},n);return e.forEach((function(e,o){p[o]=t(e,n,r)})),p}var h=de(r,e,{},n);return m(e).forEach((function(o){h[o]=t(e[o],n,r)})),h}(t,e,n)}function ge(t){switch(t.length){case 0:return Rt.trackingDerivation;case 1:return Xe(t[0]);case 2:return Xe(t[0],t[1])}}function ve(t,e){void 0===e&&(e=void 0),Lt();try{return t.apply(e)}finally{Nt()}}function me(t){return t[x]}function ye(t){return"string"==typeof t||"number"==typeof t||"symbol"==typeof t}var be={has:function(t,e){if(e===x||"constructor"===e||e===R)return!0;var n=me(t);return ye(e)?n.has(e):e in t},get:function(t,e){if(e===x||"constructor"===e||e===R)return t[e];var n=me(t),r=n.values.get(e);if(r instanceof _){var o=r.get();return void 0===o&&n.has(e),o}return ye(e)&&n.has(e),t[e]},set:function(t,e,n){return!!ye(e)&&(function t(e,n,r){if(2!==arguments.length||$e(e))if(Ge(e)){var o=e[x],i=o.values.get(n);i?o.write(n,r):o.addObservableProp(n,r,o.defaultEnhancer)}else if(Be(e))e.set(n,r);else if($e(e))e.add(n);else{if(!Pe(e))return s(!1);"number"!=typeof n&&(n=parseInt(n,10)),c(n>=0,"Not a valid index: '"+n+"'"),Lt(),n>=e.length&&(e.length=n+1),e[n]=r,Nt()}else{Lt();var a=n;try{for(var u in a)t(e,u,a[u])}finally{Nt()}}}(t,e,n),!0)},deleteProperty:function(t,e){return!!ye(e)&&(me(t).remove(e),!0)},ownKeys:function(t){return me(t).keysAtom.reportObserved(),Reflect.ownKeys(t)},preventExtensions:function(t){return s("Dynamic observable objects cannot be frozen"),!1}};function we(t){var e=new Proxy(t,be);return t[x].proxy=e,e}function xe(t){return void 0!==t.interceptors&&t.interceptors.length>0}function _e(t,e){var n=t.interceptors||(t.interceptors=[]);return n.push(e),u((function(){var t=n.indexOf(e);-1!==t&&n.splice(t,1)}))}function Oe(t,e){var n=lt();try{for(var r=C(t.interceptors||[]),o=0,i=r.length;o<i&&(c(!(e=r[o](e))||e.type,"Intercept handlers should return nothing or a change object"),e);o++);return e}finally{pt(n)}}function Se(t){return void 0!==t.changeListeners&&t.changeListeners.length>0}function je(t,e){var n=t.changeListeners||(t.changeListeners=[]);return n.push(e),u((function(){var t=n.indexOf(e);-1!==t&&n.splice(t,1)}))}function ke(t,e){var n=lt(),r=t.changeListeners;if(r){for(var o=0,i=(r=r.slice()).length;o<i;o++)r[o](e);pt(n)}}var Ae={get:function(t,e){return e===x?t[x]:"length"===e?t[x].getArrayLength():"number"==typeof e?Ce.get.call(t,e):"string"!=typeof e||isNaN(e)?Ce.hasOwnProperty(e)?Ce[e]:t[e]:Ce.get.call(t,parseInt(e))},set:function(t,e,n){return"length"===e&&t[x].setArrayLength(n),"number"==typeof e&&Ce.set.call(t,e,n),"symbol"==typeof e||isNaN(e)?t[e]=n:Ce.set.call(t,parseInt(e),n),!0},preventExtensions:function(t){return s("Observable arrays cannot be frozen"),!1}};function Te(t,e,n,r){void 0===n&&(n="ObservableArray@"+a()),void 0===r&&(r=!1);var o,i,s,c=new Ee(n,e,r);o=c.values,i=x,s=c,Object.defineProperty(o,i,{enumerable:!1,writable:!1,configurable:!0,value:s});var u=new Proxy(c.values,Ae);if(c.proxy=u,t&&t.length){var l=wt(!0);c.spliceWithArray(0,0,t),xt(l)}return u}var Ee=function(){function t(t,e,n){this.owned=n,this.values=[],this.proxy=void 0,this.lastKnownLength=0,this.atom=new _(t||"ObservableArray@"+a()),this.enhancer=function(n,r){return e(n,r,t+"[..]")}}return t.prototype.dehanceValue=function(t){return void 0!==this.dehancer?this.dehancer(t):t},t.prototype.dehanceValues=function(t){return void 0!==this.dehancer&&t.length>0?t.map(this.dehancer):t},t.prototype.intercept=function(t){return _e(this,t)},t.prototype.observe=function(t,e){return void 0===e&&(e=!1),e&&t({object:this.proxy,type:"splice",index:0,added:this.values.slice(),addedCount:this.values.length,removed:[],removedCount:0}),je(this,t)},t.prototype.getArrayLength=function(){return this.atom.reportObserved(),this.values.length},t.prototype.setArrayLength=function(t){if("number"!=typeof t||t<0)throw new Error("[mobx.array] Out of range: "+t);var e=this.values.length;if(t!==e)if(t>e){for(var n=new Array(t-e),r=0;r<t-e;r++)n[r]=void 0;this.spliceWithArray(e,0,n)}else this.spliceWithArray(t,e-t)},t.prototype.updateArrayLength=function(t,e){if(t!==this.lastKnownLength)throw new Error("[mobx] Modification exception: the internal structure of an observable array was changed.");this.lastKnownLength+=e},t.prototype.spliceWithArray=function(t,e,n){var r=this;at(this.atom);var i=this.values.length;if(void 0===t?t=0:t>i?t=i:t<0&&(t=Math.max(0,i+t)),e=1===arguments.length?i-t:null==e?0:Math.max(0,Math.min(e,i-t)),void 0===n&&(n=o),xe(this)){var a=Oe(this,{object:this.proxy,type:"splice",index:t,removedCount:e,added:n});if(!a)return o;e=a.removedCount,n=a.added}n=0===n.length?n:n.map((function(t){return r.enhancer(t,void 0)}));var s=this.spliceItemsIntoValues(t,e,n);return 0===e&&0===n.length||this.notifyArraySplice(t,n,s),this.dehanceValues(s)},t.prototype.spliceItemsIntoValues=function(t,e,n){var r;if(n.length<1e4)return(r=this.values).splice.apply(r,C([t,e],n));var o=this.values.slice(t,t+e);return this.values=this.values.slice(0,t).concat(n,this.values.slice(t+e)),o},t.prototype.notifyArrayChildUpdate=function(t,e,n){var r=!this.owned&&!1,o=Se(this),i=o||r?{object:this.proxy,type:"update",index:t,newValue:e,oldValue:n}:null;this.atom.reportChanged(),o&&ke(this,i)},t.prototype.notifyArraySplice=function(t,e,n){var r=!this.owned&&!1,o=Se(this),i=o||r?{object:this.proxy,type:"splice",index:t,removed:n,added:e,removedCount:n.length,addedCount:e.length}:null;this.atom.reportChanged(),o&&ke(this,i)},t}(),Ce={intercept:function(t){return this[x].intercept(t)},observe:function(t,e){return void 0===e&&(e=!1),this[x].observe(t,e)},clear:function(){return this.splice(0)},replace:function(t){var e=this[x];return e.spliceWithArray(0,e.values.length,t)},toJS:function(){return this.slice()},toJSON:function(){return this.toJS()},splice:function(t,e){for(var n=[],r=2;r<arguments.length;r++)n[r-2]=arguments[r];var o=this[x];switch(arguments.length){case 0:return[];case 1:return o.spliceWithArray(t);case 2:return o.spliceWithArray(t,e)}return o.spliceWithArray(t,e,n)},spliceWithArray:function(t,e,n){return this[x].spliceWithArray(t,e,n)},push:function(){for(var t=[],e=0;e<arguments.length;e++)t[e]=arguments[e];var n=this[x];return n.spliceWithArray(n.values.length,0,t),n.values.length},pop:function(){return this.splice(Math.max(this[x].values.length-1,0),1)[0]},shift:function(){return this.splice(0,1)[0]},unshift:function(){for(var t=[],e=0;e<arguments.length;e++)t[e]=arguments[e];var n=this[x];return n.spliceWithArray(0,0,t),n.values.length},reverse:function(){var t=this.slice();return t.reverse.apply(t,arguments)},sort:function(t){var e=this.slice();return e.sort.apply(e,arguments)},remove:function(t){var e=this[x],n=e.dehanceValues(e.values).indexOf(t);return n>-1&&(this.splice(n,1),!0)},get:function(t){var e=this[x];if(e){if(t<e.values.length)return e.atom.reportObserved(),e.dehanceValue(e.values[t]);console.warn("[mobx.array] Attempt to read an array index ("+t+") that is out of bounds ("+e.values.length+"). Please check length first. Out of bound indices will not be tracked by MobX")}},set:function(t,e){var n=this[x],r=n.values;if(t<r.length){at(n.atom);var o=r[t];if(xe(n)){var i=Oe(n,{type:"update",object:n.proxy,index:t,newValue:e});if(!i)return;e=i.newValue}(e=n.enhancer(e,o))!==o&&(r[t]=e,n.notifyArrayChildUpdate(t,e,o))}else{if(t!==r.length)throw new Error("[mobx.array] Index out of bounds, "+t+" is larger than "+r.length);n.spliceWithArray(t,0,[e])}}};["concat","flat","includes","indexOf","join","lastIndexOf","slice","toString","toLocaleString"].forEach((function(t){"function"==typeof Array.prototype[t]&&(Ce[t]=function(){var e=this[x];e.atom.reportObserved();var n=e.dehanceValues(e.values);return n[t].apply(n,arguments)})})),["every","filter","find","findIndex","flatMap","forEach","map","some"].forEach((function(t){"function"==typeof Array.prototype[t]&&(Ce[t]=function(e,n){var r=this,o=this[x];return o.atom.reportObserved(),o.dehanceValues(o.values)[t]((function(t,o){return e.call(n,t,o,r)}),n)})})),["reduce","reduceRight"].forEach((function(t){Ce[t]=function(){var e=this,n=this[x];n.atom.reportObserved();var r=arguments[0];return arguments[0]=function(t,o,i){return o=n.dehanceValue(o),r(t,o,i,e)},n.values[t].apply(n.values,arguments)}}));var Re,Ie=f("ObservableArrayAdministration",Ee);function Pe(t){return p(t)&&Ie(t[x])}var Me,Le={},Ne=function(){function t(t,e,n){if(void 0===e&&(e=U),void 0===n&&(n="ObservableMap@"+a()),this.enhancer=e,this.name=n,this[Re]=Le,this._keysAtom=S(this.name+".keys()"),this[Symbol.toStringTag]="Map","function"!=typeof Map)throw new Error("mobx.map requires Map polyfill for the current browser. Check babel-polyfill or core-js/es6/map.js");this._data=new Map,this._hasMap=new Map,this.merge(t)}return t.prototype._has=function(t){return this._data.has(t)},t.prototype.has=function(t){var e=this;if(!Rt.trackingDerivation)return this._has(t);var n=this._hasMap.get(t);if(!n){var r=n=new _t(this._has(t),$,this.name+"."+y(t)+"?",!1);this._hasMap.set(t,r),ee(r,(function(){return e._hasMap.delete(t)}))}return n.get()},t.prototype.set=function(t,e){var n=this._has(t);if(xe(this)){var r=Oe(this,{type:n?"update":"add",object:this,newValue:e,name:t});if(!r)return this;e=r.newValue}return n?this._updateValue(t,e):this._addValue(t,e),this},t.prototype.delete=function(t){var e=this;if((at(this._keysAtom),xe(this))&&!(r=Oe(this,{type:"delete",object:this,name:t})))return!1;if(this._has(t)){var n=Se(this),r=n?{type:"delete",object:this,oldValue:this._data.get(t).value,name:t}:null;return ve((function(){e._keysAtom.reportChanged(),e._updateHasMapEntry(t,!1),e._data.get(t).setNewValue(void 0),e._data.delete(t)})),n&&ke(this,r),!0}return!1},t.prototype._updateHasMapEntry=function(t,e){var n=this._hasMap.get(t);n&&n.setNewValue(e)},t.prototype._updateValue=function(t,e){var n=this._data.get(t);if((e=n.prepareNewValue(e))!==Rt.UNCHANGED){var r=Se(this),o=r?{type:"update",object:this,oldValue:n.value,name:t,newValue:e}:null;0,n.setNewValue(e),r&&ke(this,o)}},t.prototype._addValue=function(t,e){var n=this;at(this._keysAtom),ve((function(){var r=new _t(e,n.enhancer,n.name+"."+y(t),!1);n._data.set(t,r),e=r.value,n._updateHasMapEntry(t,!0),n._keysAtom.reportChanged()}));var r=Se(this),o=r?{type:"add",object:this,name:t,newValue:e}:null;r&&ke(this,o)},t.prototype.get=function(t){return this.has(t)?this.dehanceValue(this._data.get(t).get()):this.dehanceValue(void 0)},t.prototype.dehanceValue=function(t){return void 0!==this.dehancer?this.dehancer(t):t},t.prototype.keys=function(){return this._keysAtom.reportObserved(),this._data.keys()},t.prototype.values=function(){var t=this,e=this.keys();return tn({next:function(){var n=e.next(),r=n.done,o=n.value;return{done:r,value:r?void 0:t.get(o)}}})},t.prototype.entries=function(){var t=this,e=this.keys();return tn({next:function(){var n=e.next(),r=n.done,o=n.value;return{done:r,value:r?void 0:[o,t.get(o)]}}})},t.prototype[(Re=x,Symbol.iterator)]=function(){return this.entries()},t.prototype.forEach=function(t,e){var n,r;try{for(var o=T(this),i=o.next();!i.done;i=o.next()){var a=E(i.value,2),s=a[0],c=a[1];t.call(e,c,s,this)}}catch(t){n={error:t}}finally{try{i&&!i.done&&(r=o.return)&&r.call(o)}finally{if(n)throw n.error}}},t.prototype.merge=function(t){var e=this;return Be(t)&&(t=t.toJS()),ve((function(){var n=wt(!0);try{h(t)?m(t).forEach((function(n){return e.set(n,t[n])})):Array.isArray(t)?t.forEach((function(t){var n=E(t,2),r=n[0],o=n[1];return e.set(r,o)})):g(t)?(t.constructor!==Map&&s("Cannot initialize from classes that inherit from Map: "+t.constructor.name),t.forEach((function(t,n){return e.set(n,t)}))):null!=t&&s("Cannot initialize map from "+t)}finally{xt(n)}})),this},t.prototype.clear=function(){var t=this;ve((function(){ut((function(){var e,n;try{for(var r=T(t.keys()),o=r.next();!o.done;o=r.next()){var i=o.value;t.delete(i)}}catch(t){e={error:t}}finally{try{o&&!o.done&&(n=r.return)&&n.call(r)}finally{if(e)throw e.error}}}))}))},t.prototype.replace=function(t){var e=this;return ve((function(){var n,r,o,i,a=function(t){if(g(t)||Be(t))return t;if(Array.isArray(t))return new Map(t);if(h(t)){var e=new Map;for(var n in t)e.set(n,t[n]);return e}return s("Cannot convert to map from '"+t+"'")}(t),c=new Map,u=!1;try{for(var l=T(e._data.keys()),p=l.next();!p.done;p=l.next()){var d=p.value;if(!a.has(d))if(e.delete(d))u=!0;else{var f=e._data.get(d);c.set(d,f)}}}catch(t){n={error:t}}finally{try{p&&!p.done&&(r=l.return)&&r.call(l)}finally{if(n)throw n.error}}try{for(var v=T(a.entries()),m=v.next();!m.done;m=v.next()){var y=E(m.value,2),b=(d=y[0],f=y[1],e._data.has(d));if(e.set(d,f),e._data.has(d)){var w=e._data.get(d);c.set(d,w),b||(u=!0)}}}catch(t){o={error:t}}finally{try{m&&!m.done&&(i=v.return)&&i.call(v)}finally{if(o)throw o.error}}if(!u)if(e._data.size!==c.size)e._keysAtom.reportChanged();else for(var x=e._data.keys(),_=c.keys(),O=x.next(),S=_.next();!O.done;){if(O.value!==S.value){e._keysAtom.reportChanged();break}O=x.next(),S=_.next()}e._data=c})),this},Object.defineProperty(t.prototype,"size",{get:function(){return this._keysAtom.reportObserved(),this._data.size},enumerable:!0,configurable:!0}),t.prototype.toPOJO=function(){var t,e,n={};try{for(var r=T(this),o=r.next();!o.done;o=r.next()){var i=E(o.value,2),a=i[0],s=i[1];n["symbol"==typeof a?a:y(a)]=s}}catch(e){t={error:e}}finally{try{o&&!o.done&&(e=r.return)&&e.call(r)}finally{if(t)throw t.error}}return n},t.prototype.toJS=function(){return new Map(this)},t.prototype.toJSON=function(){return this.toPOJO()},t.prototype.toString=function(){var t=this;return this.name+"[{ "+Array.from(this.keys()).map((function(e){return y(e)+": "+t.get(e)})).join(", ")+" }]"},t.prototype.observe=function(t,e){return je(this,t)},t.prototype.intercept=function(t){return _e(this,t)},t}(),Be=f("ObservableMap",Ne),De={},Ue=function(){function t(t,e,n){if(void 0===e&&(e=U),void 0===n&&(n="ObservableSet@"+a()),this.name=n,this[Me]=De,this._data=new Set,this._atom=S(this.name),this[Symbol.toStringTag]="Set","function"!=typeof Set)throw new Error("mobx.set requires Set polyfill for the current browser. Check babel-polyfill or core-js/es6/set.js");this.enhancer=function(t,r){return e(t,r,n)},t&&this.replace(t)}return t.prototype.dehanceValue=function(t){return void 0!==this.dehancer?this.dehancer(t):t},t.prototype.clear=function(){var t=this;ve((function(){ut((function(){var e,n;try{for(var r=T(t._data.values()),o=r.next();!o.done;o=r.next()){var i=o.value;t.delete(i)}}catch(t){e={error:t}}finally{try{o&&!o.done&&(n=r.return)&&n.call(r)}finally{if(e)throw e.error}}}))}))},t.prototype.forEach=function(t,e){var n,r;try{for(var o=T(this),i=o.next();!i.done;i=o.next()){var a=i.value;t.call(e,a,a,this)}}catch(t){n={error:t}}finally{try{i&&!i.done&&(r=o.return)&&r.call(o)}finally{if(n)throw n.error}}},Object.defineProperty(t.prototype,"size",{get:function(){return this._atom.reportObserved(),this._data.size},enumerable:!0,configurable:!0}),t.prototype.add=function(t){var e=this;if((at(this._atom),xe(this))&&!(r=Oe(this,{type:"add",object:this,newValue:t})))return this;if(!this.has(t)){ve((function(){e._data.add(e.enhancer(t,void 0)),e._atom.reportChanged()}));var n=Se(this),r=n?{type:"add",object:this,newValue:t}:null;0,n&&ke(this,r)}return this},t.prototype.delete=function(t){var e=this;if(xe(this)&&!(r=Oe(this,{type:"delete",object:this,oldValue:t})))return!1;if(this.has(t)){var n=Se(this),r=n?{type:"delete",object:this,oldValue:t}:null;return ve((function(){e._atom.reportChanged(),e._data.delete(t)})),n&&ke(this,r),!0}return!1},t.prototype.has=function(t){return this._atom.reportObserved(),this._data.has(this.dehanceValue(t))},t.prototype.entries=function(){var t=0,e=Array.from(this.keys()),n=Array.from(this.values());return tn({next:function(){var r=t;return t+=1,r<n.length?{value:[e[r],n[r]],done:!1}:{done:!0}}})},t.prototype.keys=function(){return this.values()},t.prototype.values=function(){this._atom.reportObserved();var t=this,e=0,n=Array.from(this._data.values());return tn({next:function(){return e<n.length?{value:t.dehanceValue(n[e++]),done:!1}:{done:!0}}})},t.prototype.replace=function(t){var e=this;return $e(t)&&(t=t.toJS()),ve((function(){var n=wt(!0);try{Array.isArray(t)||v(t)?(e.clear(),t.forEach((function(t){return e.add(t)}))):null!=t&&s("Cannot initialize set from "+t)}finally{xt(n)}})),this},t.prototype.observe=function(t,e){return je(this,t)},t.prototype.intercept=function(t){return _e(this,t)},t.prototype.toJS=function(){return new Set(this)},t.prototype.toString=function(){return this.name+"[ "+Array.from(this).join(", ")+" ]"},t.prototype[(Me=x,Symbol.iterator)]=function(){return this.values()},t}(),$e=f("ObservableSet",Ue),ze=function(){function t(t,e,n,r){void 0===e&&(e=new Map),this.target=t,this.values=e,this.name=n,this.defaultEnhancer=r,this.keysAtom=new _(n+".keys")}return t.prototype.read=function(t){return this.values.get(t).get()},t.prototype.write=function(t,e){var n=this.target,r=this.values.get(t);if(r instanceof St)r.set(e);else{if(xe(this)){if(!(i=Oe(this,{type:"update",object:this.proxy||n,name:t,newValue:e})))return;e=i.newValue}if((e=r.prepareNewValue(e))!==Rt.UNCHANGED){var o=Se(this),i=o?{type:"update",object:this.proxy||n,oldValue:r.value,name:t,newValue:e}:null;0,r.setNewValue(e),o&&ke(this,i)}}},t.prototype.has=function(t){var e=this.pendingKeys||(this.pendingKeys=new Map),n=e.get(t);if(n)return n.get();var r=!!this.values.get(t);return n=new _t(r,$,this.name+"."+y(t)+"?",!1),e.set(t,n),n.get()},t.prototype.addObservableProp=function(t,e,n){void 0===n&&(n=this.defaultEnhancer);var r=this.target;if(xe(this)){var o=Oe(this,{object:this.proxy||r,name:t,type:"add",newValue:e});if(!o)return;e=o.newValue}var i=new _t(e,n,this.name+"."+y(t),!1);this.values.set(t,i),e=i.value,Object.defineProperty(r,t,function(t){return qe[t]||(qe[t]={configurable:!0,enumerable:!0,get:function(){return this[x].read(t)},set:function(e){this[x].write(t,e)}})}(t)),this.notifyPropertyAddition(t,e)},t.prototype.addComputedProp=function(t,e,n){var r,o,i,a=this.target;n.name=n.name||this.name+"."+y(e),this.values.set(e,new St(n)),(t===a||(r=t,o=e,!(i=Object.getOwnPropertyDescriptor(r,o))||!1!==i.configurable&&!1!==i.writable))&&Object.defineProperty(t,e,function(t){return Fe[t]||(Fe[t]={configurable:Rt.computedConfigurable,enumerable:!1,get:function(){return He(this).read(t)},set:function(e){He(this).write(t,e)}})}(e))},t.prototype.remove=function(t){if(this.values.has(t)){var e=this.target;if(xe(this))if(!(a=Oe(this,{object:this.proxy||e,name:t,type:"remove"})))return;try{Lt();var n=Se(this),r=this.values.get(t),o=r&&r.get();if(r&&r.set(void 0),this.keysAtom.reportChanged(),this.values.delete(t),this.pendingKeys){var i=this.pendingKeys.get(t);i&&i.set(!1)}delete this.target[t];var a=n?{type:"remove",object:this.proxy||e,oldValue:o,name:t}:null;0,n&&ke(this,a)}finally{Nt()}}},t.prototype.illegalAccess=function(t,e){console.warn("Property '"+e+"' of '"+t+"' was accessed through the prototype chain. Use 'decorate' instead to declare the prop or access it statically through it's owner")},t.prototype.observe=function(t,e){return je(this,t)},t.prototype.intercept=function(t){return _e(this,t)},t.prototype.notifyPropertyAddition=function(t,e){var n=Se(this),r=n?{type:"add",object:this.proxy||this.target,name:t,newValue:e}:null;if(n&&ke(this,r),this.pendingKeys){var o=this.pendingKeys.get(t);o&&o.set(!0)}this.keysAtom.reportChanged()},t.prototype.getKeys=function(){var t,e;this.keysAtom.reportObserved();var n=[];try{for(var r=T(this.values),o=r.next();!o.done;o=r.next()){var i=E(o.value,2),a=i[0];i[1]instanceof _t&&n.push(a)}}catch(e){t={error:e}}finally{try{o&&!o.done&&(e=r.return)&&e.call(r)}finally{if(t)throw t.error}}return n},t}();function Ve(t,e,n){if(void 0===e&&(e=""),void 0===n&&(n=U),Object.prototype.hasOwnProperty.call(t,x))return t[x];h(t)||(e=(t.constructor.name||"ObservableObject")+"@"+a()),e||(e="ObservableObject@"+a());var r=new ze(t,new Map,y(e),n);return d(t,x,r),r}var qe=Object.create(null),Fe=Object.create(null);function He(t){var e=t[x];return e||(N(t),t[x])}var We=f("ObservableObjectAdministration",ze);function Ge(t){return!!p(t)&&(N(t),We(t[x]))}function Xe(t,e){if("object"==typeof t&&null!==t){if(Pe(t))return void 0!==e&&s(!1),t[x].atom;if($e(t))return t[x];if(Be(t)){var n=t;return void 0===e?n._keysAtom:((r=n._data.get(e)||n._hasMap.get(e))||s(!1),r)}var r;if(N(t),e&&!t[x]&&t[e],Ge(t))return e?((r=t[x].values.get(e))||s(!1),r):s(!1);if(O(t)||jt(t)||qt(t))return t}else if("function"==typeof t&&qt(t[x]))return t[x];return s(!1)}function Ye(t,e){return t||s("Expecting some object"),void 0!==e?Ye(Xe(t,e)):O(t)||jt(t)||qt(t)||Be(t)||$e(t)?t:(N(t),t[x]?t[x]:void s(!1))}var Ke=Object.prototype.toString;function Je(t,e,n){return void 0===n&&(n=-1),function t(e,n,r,o,i){if(e===n)return 0!==e||1/e==1/n;if(null==e||null==n)return!1;if(e!=e)return n!=n;var a=typeof e;if("function"!==a&&"object"!==a&&"object"!=typeof n)return!1;var s=Ke.call(e);if(s!==Ke.call(n))return!1;switch(s){case"[object RegExp]":case"[object String]":return""+e==""+n;case"[object Number]":return+e!=+e?+n!=+n:0==+e?1/+e==1/n:+e==+n;case"[object Date]":case"[object Boolean]":return+e==+n;case"[object Symbol]":return"undefined"!=typeof Symbol&&Symbol.valueOf.call(e)===Symbol.valueOf.call(n);case"[object Map]":case"[object Set]":r>=0&&r++}e=Qe(e),n=Qe(n);var c="[object Array]"===s;if(!c){if("object"!=typeof e||"object"!=typeof n)return!1;var u=e.constructor,l=n.constructor;if(u!==l&&!("function"==typeof u&&u instanceof u&&"function"==typeof l&&l instanceof l)&&"constructor"in e&&"constructor"in n)return!1}if(0===r)return!1;r<0&&(r=-1);i=i||[];var p=(o=o||[]).length;for(;p--;)if(o[p]===e)return i[p]===n;if(o.push(e),i.push(n),c){if((p=e.length)!==n.length)return!1;for(;p--;)if(!t(e[p],n[p],r-1,o,i))return!1}else{var h=Object.keys(e),d=void 0;if(p=h.length,Object.keys(n).length!==p)return!1;for(;p--;)if(d=h[p],!Ze(n,d)||!t(e[d],n[d],r-1,o,i))return!1}return o.pop(),i.pop(),!0}(t,e,n)}function Qe(t){return Pe(t)?t.slice():g(t)||Be(t)||v(t)||$e(t)?Array.from(t.entries()):t}function Ze(t,e){return Object.prototype.hasOwnProperty.call(t,e)}function tn(t){return t[Symbol.iterator]=en,t}function en(){return this}if("undefined"==typeof Proxy||"undefined"==typeof Symbol)throw new Error("[mobx] MobX 5+ requires Proxy and Symbol objects. If your environment doesn't support Symbol or Proxy objects, please downgrade to MobX 4. For React Native Android, consider upgrading JSCore.");"object"==typeof __MOBX_DEVTOOLS_GLOBAL_HOOK__&&__MOBX_DEVTOOLS_GLOBAL_HOOK__.injectMobx({spy:function(t){return console.warn("[mobx.spy] Is a no-op in production builds"),function(){}},extras:{getDebugName:function(t,e){return(void 0!==e?Xe(t,e):Ge(t)||Be(t)||$e(t)?Ye(t):Xe(t)).name}},$mobx:x})}).call(this,n(192),n(51))},function(t,e,n){(function(e){var n=function(t){return t&&t.Math==Math&&t};t.exports=n("object"==typeof globalThis&&globalThis)||n("object"==typeof window&&window)||n("object"==typeof self&&self)||n("object"==typeof e&&e)||function(){return this}()||Function("return this")()}).call(this,n(51))},function(t,e,n){"use strict";n.d(e,"b",(function(){return b})),n.d(e,"a",(function(){return w}));n(18),n(10),n(13),n(17);var r=n(7),o=n.n(r),i=n(106),a=n.n(i),s=n(0),c=n(3);const u=a.a.create({timeout:3e4});let l=!1;const p=[],h=()=>new o.a(async(t,e)=>{if(p.push({resolve:t,reject:e}),!l){l=!0;try{const{userStore:t}=await Promise.all([n.e(0),n.e(1),n.e(6),n.e(8),n.e(30)]).then(n.bind(null,581)),{refreshToken:e}=t;if(!e)return t.setOutdated(),l=!1,void p.forEach(t=>{t.reject(new Error("no refreshtoken"))});const{status:r,data:o}=await u.post(s.x+"/refresh_token",{refresh_token:e},{headers:{"i-lang":s.C.lang}});if(200===r&&0===o.code){const{token:e,refreshToken:n}=o.data;Object(c.i)(()=>{t.token=e,t.refreshToken=n}),l=!1,p.forEach(t=>{t.resolve(e)})}else{if(200!==r||3010!==o.code&&3012!==o.code)throw new Error(null==o?void 0:o.message);t.setOutdated(),l=!1,p.forEach(t=>{t.reject(o.message)})}}catch(t){l=!1,p.forEach(e=>{e.reject(t)})}}});var d=n(14);n(52);const f=["params","data","_auth"],g=async t=>{const{slave:e}=await n.e(13).then(n.bind(null,178)),r=((t,e={})=>{const n=Object.keys(e).map(t=>`${t}=${encodeURIComponent(e[t])}`);return n.length?t.includes("?")?t+n.join("&"):t+"?"+n.join("&"):t})(t.url,t.params),{request:o,option:i}=(t=>{const e={},n={};return t.data&&!e.body&&(e.body=JSON.stringify(t.data)),Object.keys(t).forEach(r=>{f.includes(r)||(r.startsWith("_")?n[r]=t[r]:e[r]=t[r])}),{request:e,option:n}})(t);return e.postTask("slave:fetch",{url:r,request:o,option:i})},v=a.a.CancelToken,m=a.a.create({timeout:6e4});m.interceptors.response.use(null,t=>(t.message=i18n("network_error"),o.a.reject(t)));const y=Object.create(null),b=t=>{y[t]&&y[t]()},w=async t=>{if(t._single){const e=(t=>{let e;return e=!0===t._single?t.method+"-"+t.url.split("?")[0]:t._single,e})(t);y[e]&&y[e](),t.cancelToken=new v(t=>{y[e]=t})}var e;t._delay&&await(e=t._delay,new o.a(t=>{setTimeout(t,e)}));const r={};if(t._auth){const{userStore:e}=await Promise.all([n.e(0),n.e(1),n.e(7),n.e(39)]).then(n.bind(null,390));if(!e||!e.token)throw new Error("error token");{const n=d.a.parseJwt(e.token),o=await d.a.getTimestamp();if(t._Authorization)r.Authorization=t._Authorization,r["i-token"]=t._Authorization;else if(Math.floor(o/1e3)>n.exp-60){const t=await h();r.Authorization="Bearer "+t,r["i-token"]="Bearer "+t}else r.Authorization="Bearer "+e.token,r["i-token"]="Bearer "+e.token}}let i;if(t.url.includes(s.x)&&(r["i-lang"]=s.C.lang,r["i-edition"]=s.e,r["i-version"]=s.C.extVersion),t.headers=Object.assign(Object.assign({},r),t.headers),i=t._proxy?await g(t):await m(t),t._responseAll)return i;let{data:a}=i;if(!t._Authorization&&3010===(null==a?void 0:a.code)){const e=await h();t._Authorization="Bearer "+e,delete t.headers.Authorization,delete t.headers["i-token"],a=await w(t)}return a};["get","delete"].forEach(t=>{w[t]=(e,n,r={})=>w(Object.assign({url:e,params:n,method:t},r))}),["post","patch","put"].forEach(t=>{w[t]=(e,n,r={})=>w(Object.assign({url:e,data:n,method:t},r))}),w.jsonp=(t,e,n={})=>w(Object.assign({url:t,params:e},n))},function(t,e,n){var r=n(4),o=n(60),i=n(11),a=n(75),s=n(88),c=n(144),u=o("wks"),l=r.Symbol,p=c?l:l&&l.withoutSetter||a;t.exports=function(t){return i(u,t)&&(s||"string"==typeof u[t])||(s&&i(l,t)?u[t]=l[t]:u[t]=p("Symbol."+t)),u[t]}},function(t,e,n){t.exports=n(266)},function(t,e){t.exports=function(t){try{return!!t()}catch(t){return!0}}},function(t,e,n){var r=n(16);t.exports=function(t){if(!r(t))throw TypeError(String(t)+" is not an object");return t}},function(t,e,n){"use strict";var r,o,i,a,s=n(46),c=n(41),u=n(4),l=n(31),p=n(132),h=n(24),d=n(142),f=n(69),g=n(63),v=n(113),m=n(16),y=n(37),b=n(145),w=n(57),x=n(146),_=n(151),O=n(133),S=n(89).set,j=n(152),k=n(134),A=n(154),T=n(92),E=n(155),C=n(36),R=n(76),I=n(6),P=n(156),M=n(64),L=n(77),N=I("species"),B="Promise",D=C.get,U=C.set,$=C.getterFor(B),z=p&&p.prototype,V=p,q=z,F=u.TypeError,H=u.document,W=u.process,G=T.f,X=G,Y=!!(H&&H.createEvent&&u.dispatchEvent),K="function"==typeof PromiseRejectionEvent,J=!1,Q=R(B,(function(){var t=w(V),e=t!==String(V);if(!e&&66===L)return!0;if(c&&!q.finally)return!0;if(L>=51&&/native code/.test(t))return!1;var n=new V((function(t){t(1)})),r=function(t){t((function(){}),(function(){}))};return(n.constructor={})[N]=r,!(J=n.then((function(){}))instanceof r)||!e&&P&&!K})),Z=Q||!_((function(t){V.all(t).catch((function(){}))})),tt=function(t){var e;return!(!m(t)||"function"!=typeof(e=t.then))&&e},et=function(t,e){if(!t.notified){t.notified=!0;var n=t.reactions;j((function(){for(var r=t.value,o=1==t.state,i=0;n.length>i;){var a,s,c,u=n[i++],l=o?u.ok:u.fail,p=u.resolve,h=u.reject,d=u.domain;try{l?(o||(2===t.rejection&&it(t),t.rejection=1),!0===l?a=r:(d&&d.enter(),a=l(r),d&&(d.exit(),c=!0)),a===u.promise?h(F("Promise-chain cycle")):(s=tt(a))?s.call(a,p,h):p(a)):h(r)}catch(t){d&&!c&&d.exit(),h(t)}}t.reactions=[],t.notified=!1,e&&!t.rejection&&rt(t)}))}},nt=function(t,e,n){var r,o;Y?((r=H.createEvent("Event")).promise=e,r.reason=n,r.initEvent(t,!1,!0),u.dispatchEvent(r)):r={promise:e,reason:n},!K&&(o=u["on"+t])?o(r):"unhandledrejection"===t&&A("Unhandled promise rejection",n)},rt=function(t){S.call(u,(function(){var e,n=t.facade,r=t.value;if(ot(t)&&(e=E((function(){M?W.emit("unhandledRejection",r,n):nt("unhandledrejection",n,r)})),t.rejection=M||ot(t)?2:1,e.error))throw e.value}))},ot=function(t){return 1!==t.rejection&&!t.parent},it=function(t){S.call(u,(function(){var e=t.facade;M?W.emit("rejectionHandled",e):nt("rejectionhandled",e,t.value)}))},at=function(t,e,n){return function(r){t(e,r,n)}},st=function(t,e,n){t.done||(t.done=!0,n&&(t=n),t.value=e,t.state=2,et(t,!0))},ct=function(t,e,n){if(!t.done){t.done=!0,n&&(t=n);try{if(t.facade===e)throw F("Promise can't be resolved itself");var r=tt(e);r?j((function(){var n={done:!1};try{r.call(e,at(ct,n,t),at(st,n,t))}catch(e){st(n,e,t)}})):(t.value=e,t.state=1,et(t,!1))}catch(e){st({done:!1},e,t)}}};if(Q&&(q=(V=function(t){b(this,V,B),y(t),r.call(this);var e=D(this);try{t(at(ct,e),at(st,e))}catch(t){st(e,t)}}).prototype,(r=function(t){U(this,{type:B,done:!1,notified:!1,parent:!1,reactions:[],rejection:!1,state:0,value:void 0})}).prototype=d(q,{then:function(t,e){var n=$(this),r=G(O(this,V));return r.ok="function"!=typeof t||t,r.fail="function"==typeof e&&e,r.domain=M?W.domain:void 0,n.parent=!0,n.reactions.push(r),0!=n.state&&et(n,!1),r.promise},catch:function(t){return this.then(void 0,t)}}),o=function(){var t=new r,e=D(t);this.promise=t,this.resolve=at(ct,e),this.reject=at(st,e)},T.f=G=function(t){return t===V||t===i?new o(t):X(t)},!c&&"function"==typeof p&&z!==Object.prototype)){a=z.then,J||(h(z,"then",(function(t,e){var n=this;return new V((function(t,e){a.call(n,t,e)})).then(t,e)}),{unsafe:!0}),h(z,"catch",q.catch,{unsafe:!0}));try{delete z.constructor}catch(t){}f&&f(z,q)}s({global:!0,wrap:!0,forced:Q},{Promise:V}),g(V,B,!1,!0),v(B),i=l(B),s({target:B,stat:!0,forced:Q},{reject:function(t){var e=G(this);return e.reject.call(void 0,t),e.promise}}),s({target:B,stat:!0,forced:c||Q},{resolve:function(t){return k(c&&this===i?V:this,t)}}),s({target:B,stat:!0,forced:Z},{all:function(t){var e=this,n=G(e),r=n.resolve,o=n.reject,i=E((function(){var n=y(e.resolve),i=[],a=0,s=1;x(t,(function(t){var c=a++,u=!1;i.push(void 0),s++,n.call(e,t).then((function(t){u||(u=!0,i[c]=t,--s||r(i))}),o)})),--s||r(i)}));return i.error&&o(i.value),n.promise},race:function(t){var e=this,n=G(e),r=n.reject,o=E((function(){var o=y(e.resolve);x(t,(function(t){o.call(e,t).then(n.resolve,r)}))}));return o.error&&r(o.value),n.promise}})},function(t,e,n){var r=n(50),o={}.hasOwnProperty;t.exports=Object.hasOwn||function(t,e){return o.call(r(t),e)}},function(t,e,n){(function(e){var n=function(t){return t&&t.Math==Math&&t};t.exports=n("object"==typeof globalThis&&globalThis)||n("object"==typeof window&&window)||n("object"==typeof self&&self)||n("object"==typeof e&&e)||function(){return this}()||Function("return this")()}).call(this,n(51))},function(t,e,n){"use strict";var r=n(42),o=n(157),i=n(32),a=n(36),s=n(160),c=a.set,u=a.getterFor("Array Iterator");t.exports=s(Array,"Array",(function(t,e){c(this,{type:"Array Iterator",target:r(t),index:0,kind:e})}),(function(){var t=u(this),e=t.target,n=t.kind,r=t.index++;return!e||r>=e.length?(t.target=void 0,{value:void 0,done:!0}):"keys"==n?{value:r,done:!1}:"values"==n?{value:e[r],done:!1}:{value:[r,e[r]],done:!1}}),"values"),i.Arguments=i.Array,o("keys"),o("values"),o("entries")},function(t,e,n){"use strict";var r=n(7),o=n.n(r),i=n(48),a=n.n(i),s=(n(10),n(13),n(17),n(18),n(44),n(52),n(232),n(0)),c=n(2),u=n(97),l=n(235),p=n(131);const h=t=>{t&&(s.r?window.open(t,"_self"):window.chrome.tabs.getCurrent(e=>window.chrome.tabs.update(e.id,{url:t},()=>{chrome.runtime.lastError&&(t.startsWith("http")?window.open(t,"_self"):window.chrome.tabs.create({url:t}))})))},d={randomId:p.c,group:(t,e)=>{const n=[],r=Math.ceil(t.length/e);for(let o=0;o<r;o++)o===r-1?n.push(t.slice(o*e,t.length)):n.push(t.slice(o*e,(o+1)*e));return n},openUrl:(t,e=!0,n)=>{!n||1!==n.button&&!d.ctrlKeyStatus(n)?e?s.r?window.open(t,"_blank").focus():window.chrome.tabs.create({url:t,active:!0}):h(t):s.r?window.open(t,"_blank"):window.chrome.tabs.create({url:t,active:!1})},openChromeApp:async(t,e=!0,r)=>{if(!await u.a.has(["management"]))try{await u.a.request(["management"])}catch(t){const{message:e}=await Promise.all([n.e(0),n.e(1),n.e(2),n.e(7),n.e(9)]).then(n.bind(null,122));return void e.error(i18n("no_permission_to_open_app",s.C.vendor))}chrome.management.get(t,async({type:o,launchType:i,enabled:a,appLaunchUrl:c}={})=>{if(chrome.runtime.lastError){const{message:t}=await Promise.all([n.e(0),n.e(1),n.e(2),n.e(7),n.e(9)]).then(n.bind(null,122));t.error(i18n("target_chrome_app_not_installed",s.C.vendor))}else{const s=()=>{!r||1!==r.button&&!d.ctrlKeyStatus(r)?e||"hosted_app"!==o||"OPEN_AS_REGULAR_TAB"!==i?chrome.management.launchApp(t):h(c):chrome.management.launchApp(t)};if(a)s();else{const{IConfirm:e}=await Promise.all([n.e(0),n.e(38)]).then(n.bind(null,396));e.create().toShow({text:i18n("app_disabled_enable_first"),onConfirm:()=>{window.chrome.management.setEnabled(t,!0,()=>{s()})}})}}})},send:async function({key:t,data:e}){s.r||window.chrome.runtime.sendMessage({key:t,data:e})},downloadImg:function(t,e,n){if(!e)if(e="infinity-"+Math.ceil(Date.now()*Math.random()/(555555*Math.random())),t.startsWith("blob:"))e=`${e}.${n||"png"}`;else{const n=t.indexOf("?");let r=t;~n&&(r=t.slice(0,n));e=`${e}.${r.split("/").reverse()[0].split(".").reverse()[0]}`}const r=e,o=document.createElement("a");let i=t;t.startsWith("blob:")||(i=t.includes("?")?`${t}&attname=${r}`:`${t}?attname=${r}`),s.n&&o.setAttribute("target","_blank"),o.setAttribute("download",r),o.setAttribute("href",i),document.body.appendChild(o),o.click(),document.body.removeChild(o)},fmtTime:(t,e)=>new Date(t).toLocaleString(s.C.lang,e||{year:"numeric",month:"long",day:"2-digit",hour:"2-digit",minute:"2-digit"}),getTimestamp:async function(){return Date.now()},parseJwt:t=>{const e=t.split(".")[1].replace(/-/g,"+").replace(/_/g,"/"),n=decodeURIComponent(atob(e).split("").map(t=>"%"+("00"+t.charCodeAt(0).toString(16)).slice(-2)).join(""));return JSON.parse(n)},compress:(t,e=10,n)=>new o.a(r=>{const o=new Image,i=document.createElement("canvas"),a=i.getContext("2d");o.onload=()=>{n=n||o.height*e/o.width,i.width=e,i.height=n,a.fillRect(0,0,e,n),a.drawImage(o,0,0,e,n),i.toBlob(r,"image/jpeg")},o.src=t}),mergeArray:function(t=[],e=[],n="id",r="updatetime"){if(!t||0===t.length)return{result:e||[],isLocalEffective:!1};const o=e.filter(t=>!!t),i=Object.create(null);e.forEach((t,e)=>{if(t[n]){const r=t[n];i[r]=e}});let a=!1;return t.filter(t=>0!==t[r]).forEach(t=>{const e=t[n],s=i[e];if(void 0!==s){(o[s][r]||0)<(t[r]||0)&&(o[s]=t,a=!0)}else a=!0,o.push(t)}),{result:o.filter(t=>!!t),isLocalEffective:a}},throttle:function(t,e){let n;return function(...r){const o=this;n||(n=setTimeout(()=>{t.apply(o,r),n=null},e))}},debounce:function(t,e){let n=null;return function(){const r=this,o=arguments;n&&(clearTimeout(n),n=null),n=setTimeout(()=>{t.apply(r,o)},e)}},setStyle:function(t,e=document.body){Object.keys(t).forEach(n=>{e.style.setProperty(n,t[n])})},isInputType:t=>!!t&&(!("INPUT"!==t.tagName||t.getAttribute("type")&&"text"!==t.getAttribute("type")&&"search"!==t.getAttribute("type"))||("TEXTAREA"===t.tagName||(!!t.getAttribute("contenteditable")||void 0))),convertBase64ToBlob:t=>{const e=t.split(",");let n="",r="";e.length>1&&(r=e[1],n=e[0].substring(e[0].indexOf(":")+1,e[0].indexOf(";")));const o=atob(r),i=new ArrayBuffer(o.length),a=new Uint8Array(i);for(let t=0;t<o.length;t++)a[t]=o.charCodeAt(t);return new Blob([i],{type:n})},isTouchScreendevice:()=>!(!("ontouchstart"in window)&&!navigator.maxTouchPoints),stopBubble(t){t.stopPropagation()},hexColorDelta(t,e){let n,r,o,i,a,s;Array.isArray(t)?[n,r,o]=t:(n=parseInt(t.substring(0,2),16),r=parseInt(t.substring(2,4),16),o=parseInt(t.substring(4,6),16)),Array.isArray(e)?[i,a,s]=e:(i=parseInt(e.substring(0,2),16),a=parseInt(e.substring(2,4),16),s=parseInt(e.substring(4,6),16));let c=255-Math.abs(n-i),u=255-Math.abs(r-a),l=255-Math.abs(o-s);return c/=255,u/=255,l/=255,(c+u+l)/3},async getSimilarColor(t){const e=a.a.createObjectURL(t),n=await new o.a(t=>{const n=new Image;n.onload=()=>t(n),n.src=e}),r=(new ColorThief).getColor(n),i=window.__INFINITY__.color_list,s=i.map(t=>d.hexColorDelta(r,t)),c=Math.max.apply(null,s),u=i[s.indexOf(c)];return a.a.revokeObjectURL(e),u},getPrivacyUrl(){const t=c.IS_ZH?"zh":"en";return s.n?`/privacy/${t}/privacy.html`:`${s.t}/${s.e}/${s.c}/${t}/privacy.html`},sleep:(t=0)=>new o.a(e=>{setTimeout(()=>{e(null)},t)}),checkImage(){let t;return[e=>new o.a((n,r)=>{t=new Image,t.onload=n,t.onerror=r,t.src=e}),()=>{t&&(t.src="")}]},requestFirefoxThrottle(t,e,n=!1){if(s.n||n){const n="throttle-"+t;if("boolean"==typeof e&&localStorage.setItem(n,Date.now()+""),"number"==typeof e){const t=localStorage.getItem(n),r=Date.now();if(t&&Number(t)<r&&Number(t)+e>r)return!1}}return!0},chooseFile:(t,e)=>(t=t||"image/jpg,image/jpeg,image/png,image/gif,image/bmp,image/webp,image/svg",e=e||"readAsDataURL",new o.a(n=>{try{document.querySelectorAll(".choose-file").forEach(t=>{document.body.removeChild(t)})}catch(t){}const r=document.createElement("input");r.setAttribute("type","file"),r.setAttribute("class","choose-file"),r.setAttribute("accept",t),r.style.opacity="0",r.style.width="0",r.style.height="0",r.value="",r.addEventListener("change",t=>{const o=t.target.files[0],i=new FileReader;i[e](o),i.onload=function(t){const e=t.target.result;n(e);try{document.body.removeChild(r)}catch(t){}}},{once:!0}),document.body.appendChild(r),r.click()})),stopShowMenu(t){if(!d.isInputType(t.target))return t.stopPropagation(),t.preventDefault(),document.querySelector("i-menu").toHide(),!1},ctrlKeyStatus:t=>s.o?t.metaKey:t.ctrlKey,getFavIconSrc:t=>g(t)?t:function(t){try{return new l.a(t).host}catch(e){return t}}(function(t){if(function(t){return/^(.+?):\/\//.test(t)}(t)||g(t))return t;return"http://"+t}(t)).replace("^www.",""),getLastReqValue(t){const e=[],n=this;return async function(r,o,i){const a=n.randomId("req");e.push(a);const s=await t(r,o,i),c=e.findIndex(t=>t===a),u=e.length;return e.splice(0,c+1),c===u-1?s:null}},isFirstDate(t){const e=new Date("2013/11/30").toLocaleDateString(t);let n="";if(e.replace(/(\d{1,4})\D+(\d{1,2})\D+(\d{1,4})/,(t,e)=>(n=e,"")),"2013"===n)return!0;const r=String(new Date("2013/11/30").getDate());return n===r},internaDateToStan:p.a,getTargetLogDomain(t){if(!t)return"";try{if(t.startsWith("http://")||t.startsWith("https://")){const e=new a.a(t);if(e.host)return e.host}return t.split("?")[0]}catch(e){return t}}};const f=/^\w+:\w/;function g(t){return f.test(t)}e.a=d;const v=document.createElement("script");v.src="/vendor/color-thief.min.js",document.head.appendChild(v),v.onload=()=>{v.remove()}},function(t,e,n){var r=n(20),o=n(21),i=n(54);t.exports=r?function(t,e,n){return o.f(t,e,i(1,n))}:function(t,e,n){return t[e]=n,t}},function(t,e){t.exports=function(t){return"object"==typeof t?null!==t:"function"==typeof t}},function(t,e,n){var r=n(4),o=n(109),i=n(13),a=n(15),s=n(6),c=s("iterator"),u=s("toStringTag"),l=i.values;for(var p in o){var h=r[p],d=h&&h.prototype;if(d){if(d[c]!==l)try{a(d,c,l)}catch(t){d[c]=l}if(d[u]||a(d,u,p),o[p])for(var f in i)if(d[f]!==i[f])try{a(d,f,i[f])}catch(t){d[f]=i[f]}}}},function(t,e,n){"use strict";var r=n(46),o=n(66);r({target:"RegExp",proto:!0,forced:/./.exec!==o},{exec:o})},function(t,e){t.exports=function(t){try{return!!t()}catch(t){return!0}}},function(t,e,n){var r=n(8);t.exports=!r((function(){return 7!=Object.defineProperty({},1,{get:function(){return 7}})[1]}))},function(t,e,n){var r=n(20),o=n(86),i=n(9),a=n(85),s=Object.defineProperty;e.f=r?s:function(t,e,n){if(i(t),e=a(e,!0),i(n),o)try{return s(t,e,n)}catch(t){}if("get"in n||"set"in n)throw TypeError("Accessors not supported");return"value"in n&&(t[e]=n.value),t}},function(t,e,n){"use strict";n.d(e,"c",(function(){return c})),n.d(e,"d",(function(){return u})),n.d(e,"b",(function(){return l})),n.d(e,"e",(function(){return p})),n.d(e,"f",(function(){return h})),n.d(e,"g",(function(){return d})),n.d(e,"a",(function(){return f}));var r=n(7),o=n.n(r),i=(n(10),n(13),n(17),n(0)),a=n(26),s=n.n(a);function c(t,e){if(i.l){if(t=window.chrome.runtime.getURL(t),null==e?void 0:e.isNewTab)return window.chrome.tabs.create({url:t});window.chrome.tabs.getCurrent(e=>window.chrome.tabs.update(e.id,{url:t},()=>{chrome.runtime.lastError&&t&&(t.startsWith("http")?window.open(t,"_self"):window.chrome.tabs.create({url:t}))}))}else{if(null==e?void 0:e.isNewTab)return window.open(t);window.open(t,"_self")}}async function u(){if(i.l){const{slave:t}=await n.e(13).then(n.bind(null,178));window.chrome.tabs.getCurrent(e=>{t.sendMessage("tabs-reload"),setTimeout(()=>{window.chrome.tabs.remove(e.id)},16)})}else setTimeout(()=>{c("/")},16)}async function l(t,e){try{if(e){return await s.a.getItem(t)}{const e=localStorage.getItem(t);if(e)return"string"==typeof e?JSON.parse(e):e}}catch(t){throw new Error(t)}}async function p(t,e,n){n?await s.a.setItem(t,e):localStorage.setItem(t,JSON.stringify(e))}async function h(t,e,n=!1){const r=await l(t,n);if(r&&Object.keys(r).length){p(t,Object.assign({},r,e),n)}else p(t,e,n)}async function d(t,e){const{autoBackupPipe:n}=await l("store-sync",!0);n.data[t]=e,n.timestamp=Date.now(),n.websocketKeys.includes(t)||n.websocketKeys.push(t),await h("store-sync",{autoBackupPipe:n},!0)}async function f(){const t=await new o.a(t=>chrome.bookmarks.getTree(t));if(i.n){const e=t[0].children.findIndex(t=>"unfiled_____"===t.id),n=t[0].children.findIndex(t=>"toolbar_____"===t.id);if(-1!==e&&-1!==n)if(e>n){const[r]=t[0].children.splice(e,1),[o]=t[0].children.splice(n,1);t[0].children.unshift(o,r)}else{const[r]=t[0].children.splice(n,1),[o]=t[0].children.splice(e,1);t[0].children.unshift(r,o)}}return t}},function(t,e,n){"use strict";n.d(e,"c",(function(){return i})),n.d(e,"a",(function(){return a})),n.d(e,"b",(function(){return s})),n.d(e,"d",(function(){return c}));n(18);const r=/^http[s]?:\/\//;function o(t){return r.test(t)}const i=navigator.userAgent.toLowerCase().match(/version\/([\d.]+).*safari/),a=(t,e)=>{const n="https://infinityicon.infinitynewtab.com/assets/images/"+t;return!0===e?s(n):!1===e?n:/\.(png|jpg|jpeg)$/.test(t)?s(n):n};function s(t){return o(t)?t.includes("?")?t:i?t+"?imageView2/0/q/100":t+"?imageView2/0/format/webp/q/100":t}function c(t){return o(t)?t.includes("?")?t:i?t+"?imageMogr2/thumbnail/240x/blur/1x0/quality/100|imageslim":t+"?imageMogr2/thumbnail/240x/format/webp/blur/1x0/quality/100|imageslim":t}},function(t,e,n){var r=n(4),o=n(15),i=n(11),a=n(56),s=n(57),c=n(36),u=c.get,l=c.enforce,p=String(String).split("String");(t.exports=function(t,e,n,s){var c,u=!!s&&!!s.unsafe,h=!!s&&!!s.enumerable,d=!!s&&!!s.noTargetGet;"function"==typeof n&&("string"!=typeof e||i(n,"name")||o(n,"name",e),(c=l(n)).source||(c.source=p.join("string"==typeof e?e:""))),t!==r?(u?!d&&t[e]&&(h=!0):delete t[e],h?t[e]=n:o(t,e,n)):h?t[e]=n:a(e,n)})(Function.prototype,"toString",(function(){return"function"==typeof this&&u(this).source||s(this)}))},function(t,e,n){var r=n(19);t.exports=!r((function(){return 7!=Object.defineProperty({},1,{get:function(){return 7}})[1]}))},function(t,e,n){(function(e){t.exports=function t(e,n,r){function o(a,s){if(!n[a]){if(!e[a]){if(i)return i(a,!0);var c=new Error("Cannot find module '"+a+"'");throw c.code="MODULE_NOT_FOUND",c}var u=n[a]={exports:{}};e[a][0].call(u.exports,(function(t){var n=e[a][1][t];return o(n||t)}),u,u.exports,t,e,n,r)}return n[a].exports}for(var i=!1,a=0;a<r.length;a++)o(r[a]);return o}({1:[function(t,n,r){(function(t){"use strict";var e,r,o=t.MutationObserver||t.WebKitMutationObserver;if(o){var i=0,a=new o(l),s=t.document.createTextNode("");a.observe(s,{characterData:!0}),e=function(){s.data=i=++i%2}}else if(t.setImmediate||void 0===t.MessageChannel)e="document"in t&&"onreadystatechange"in t.document.createElement("script")?function(){var e=t.document.createElement("script");e.onreadystatechange=function(){l(),e.onreadystatechange=null,e.parentNode.removeChild(e),e=null},t.document.documentElement.appendChild(e)}:function(){setTimeout(l,0)};else{var c=new t.MessageChannel;c.port1.onmessage=l,e=function(){c.port2.postMessage(0)}}var u=[];function l(){var t,e;r=!0;for(var n=u.length;n;){for(e=u,u=[],t=-1;++t<n;)e[t]();n=u.length}r=!1}n.exports=function(t){1!==u.push(t)||r||e()}}).call(this,void 0!==e?e:"undefined"!=typeof self?self:"undefined"!=typeof window?window:{})},{}],2:[function(t,e,n){"use strict";var r=t(1);function o(){}var i={},a=["REJECTED"],s=["FULFILLED"],c=["PENDING"];function u(t){if("function"!=typeof t)throw new TypeError("resolver must be a function");this.state=c,this.queue=[],this.outcome=void 0,t!==o&&d(this,t)}function l(t,e,n){this.promise=t,"function"==typeof e&&(this.onFulfilled=e,this.callFulfilled=this.otherCallFulfilled),"function"==typeof n&&(this.onRejected=n,this.callRejected=this.otherCallRejected)}function p(t,e,n){r((function(){var r;try{r=e(n)}catch(e){return i.reject(t,e)}r===t?i.reject(t,new TypeError("Cannot resolve promise with itself")):i.resolve(t,r)}))}function h(t){var e=t&&t.then;if(t&&("object"==typeof t||"function"==typeof t)&&"function"==typeof e)return function(){e.apply(t,arguments)}}function d(t,e){var n=!1;function r(e){n||(n=!0,i.reject(t,e))}function o(e){n||(n=!0,i.resolve(t,e))}var a=f((function(){e(o,r)}));"error"===a.status&&r(a.value)}function f(t,e){var n={};try{n.value=t(e),n.status="success"}catch(t){n.status="error",n.value=t}return n}e.exports=u,u.prototype.catch=function(t){return this.then(null,t)},u.prototype.then=function(t,e){if("function"!=typeof t&&this.state===s||"function"!=typeof e&&this.state===a)return this;var n=new this.constructor(o);return this.state!==c?p(n,this.state===s?t:e,this.outcome):this.queue.push(new l(n,t,e)),n},l.prototype.callFulfilled=function(t){i.resolve(this.promise,t)},l.prototype.otherCallFulfilled=function(t){p(this.promise,this.onFulfilled,t)},l.prototype.callRejected=function(t){i.reject(this.promise,t)},l.prototype.otherCallRejected=function(t){p(this.promise,this.onRejected,t)},i.resolve=function(t,e){var n=f(h,e);if("error"===n.status)return i.reject(t,n.value);var r=n.value;if(r)d(t,r);else{t.state=s,t.outcome=e;for(var o=-1,a=t.queue.length;++o<a;)t.queue[o].callFulfilled(e)}return t},i.reject=function(t,e){t.state=a,t.outcome=e;for(var n=-1,r=t.queue.length;++n<r;)t.queue[n].callRejected(e);return t},u.resolve=function(t){return t instanceof this?t:i.resolve(new this(o),t)},u.reject=function(t){var e=new this(o);return i.reject(e,t)},u.all=function(t){var e=this;if("[object Array]"!==Object.prototype.toString.call(t))return this.reject(new TypeError("must be an array"));var n=t.length,r=!1;if(!n)return this.resolve([]);for(var a=new Array(n),s=0,c=-1,u=new this(o);++c<n;)l(t[c],c);return u;function l(t,o){e.resolve(t).then((function(t){a[o]=t,++s!==n||r||(r=!0,i.resolve(u,a))}),(function(t){r||(r=!0,i.reject(u,t))}))}},u.race=function(t){var e=this;if("[object Array]"!==Object.prototype.toString.call(t))return this.reject(new TypeError("must be an array"));var n=t.length,r=!1;if(!n)return this.resolve([]);for(var a,s=-1,c=new this(o);++s<n;)a=t[s],e.resolve(a).then((function(t){r||(r=!0,i.resolve(c,t))}),(function(t){r||(r=!0,i.reject(c,t))}));return c}},{1:1}],3:[function(t,n,r){(function(e){"use strict";"function"!=typeof e.Promise&&(e.Promise=t(2))}).call(this,void 0!==e?e:"undefined"!=typeof self?self:"undefined"!=typeof window?window:{})},{2:2}],4:[function(t,e,n){"use strict";var r="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(t){return typeof t}:function(t){return t&&"function"==typeof Symbol&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t},o=function(){try{if("undefined"!=typeof indexedDB)return indexedDB;if("undefined"!=typeof webkitIndexedDB)return webkitIndexedDB;if("undefined"!=typeof mozIndexedDB)return mozIndexedDB;if("undefined"!=typeof OIndexedDB)return OIndexedDB;if("undefined"!=typeof msIndexedDB)return msIndexedDB}catch(t){return}}();function i(t,e){t=t||[],e=e||{};try{return new Blob(t,e)}catch(o){if("TypeError"!==o.name)throw o;for(var n=new("undefined"!=typeof BlobBuilder?BlobBuilder:"undefined"!=typeof MSBlobBuilder?MSBlobBuilder:"undefined"!=typeof MozBlobBuilder?MozBlobBuilder:WebKitBlobBuilder),r=0;r<t.length;r+=1)n.append(t[r]);return n.getBlob(e.type)}}"undefined"==typeof Promise&&t(3);var a=Promise;function s(t,e){e&&t.then((function(t){e(null,t)}),(function(t){e(t)}))}function c(t,e,n){"function"==typeof e&&t.then(e),"function"==typeof n&&t.catch(n)}function u(t){return"string"!=typeof t&&(console.warn(t+" used as a key, but it is not a string."),t=String(t)),t}function l(){if(arguments.length&&"function"==typeof arguments[arguments.length-1])return arguments[arguments.length-1]}var p=void 0,h={},d=Object.prototype.toString;function f(t){return"boolean"==typeof p?a.resolve(p):function(t){return new a((function(e){var n=t.transaction("local-forage-detect-blob-support","readwrite"),r=i([""]);n.objectStore("local-forage-detect-blob-support").put(r,"key"),n.onabort=function(t){t.preventDefault(),t.stopPropagation(),e(!1)},n.oncomplete=function(){var t=navigator.userAgent.match(/Chrome\/(\d+)/),n=navigator.userAgent.match(/Edge\//);e(n||!t||parseInt(t[1],10)>=43)}})).catch((function(){return!1}))}(t).then((function(t){return p=t}))}function g(t){var e=h[t.name],n={};n.promise=new a((function(t,e){n.resolve=t,n.reject=e})),e.deferredOperations.push(n),e.dbReady?e.dbReady=e.dbReady.then((function(){return n.promise})):e.dbReady=n.promise}function v(t){var e=h[t.name].deferredOperations.pop();if(e)return e.resolve(),e.promise}function m(t,e){var n=h[t.name].deferredOperations.pop();if(n)return n.reject(e),n.promise}function y(t,e){return new a((function(n,r){if(h[t.name]=h[t.name]||{forages:[],db:null,dbReady:null,deferredOperations:[]},t.db){if(!e)return n(t.db);g(t),t.db.close()}var i=[t.name];e&&i.push(t.version);var a=o.open.apply(o,i);e&&(a.onupgradeneeded=function(e){var n=a.result;try{n.createObjectStore(t.storeName),e.oldVersion<=1&&n.createObjectStore("local-forage-detect-blob-support")}catch(n){if("ConstraintError"!==n.name)throw n;console.warn('The database "'+t.name+'" has been upgraded from version '+e.oldVersion+" to version "+e.newVersion+', but the storage "'+t.storeName+'" already exists.')}}),a.onerror=function(t){t.preventDefault(),r(a.error)},a.onsuccess=function(){n(a.result),v(t)}}))}function b(t){return y(t,!1)}function w(t){return y(t,!0)}function x(t,e){if(!t.db)return!0;var n=!t.db.objectStoreNames.contains(t.storeName),r=t.version<t.db.version,o=t.version>t.db.version;if(r&&(t.version!==e&&console.warn('The database "'+t.name+"\" can't be downgraded from version "+t.db.version+" to version "+t.version+"."),t.version=t.db.version),o||n){if(n){var i=t.db.version+1;i>t.version&&(t.version=i)}return!0}return!1}function _(t){return i([function(t){for(var e=t.length,n=new ArrayBuffer(e),r=new Uint8Array(n),o=0;o<e;o++)r[o]=t.charCodeAt(o);return n}(atob(t.data))],{type:t.type})}function O(t){return t&&t.__local_forage_encoded_blob}function S(t){var e=this,n=e._initReady().then((function(){var t=h[e._dbInfo.name];if(t&&t.dbReady)return t.dbReady}));return c(n,t,t),n}function j(t,e,n,r){void 0===r&&(r=1);try{var o=t.db.transaction(t.storeName,e);n(null,o)}catch(o){if(r>0&&(!t.db||"InvalidStateError"===o.name||"NotFoundError"===o.name))return a.resolve().then((function(){if(!t.db||"NotFoundError"===o.name&&!t.db.objectStoreNames.contains(t.storeName)&&t.version<=t.db.version)return t.db&&(t.version=t.db.version+1),w(t)})).then((function(){return function(t){g(t);for(var e=h[t.name],n=e.forages,r=0;r<n.length;r++){var o=n[r];o._dbInfo.db&&(o._dbInfo.db.close(),o._dbInfo.db=null)}return t.db=null,b(t).then((function(e){return t.db=e,x(t)?w(t):e})).then((function(r){t.db=e.db=r;for(var o=0;o<n.length;o++)n[o]._dbInfo.db=r})).catch((function(e){throw m(t,e),e}))}(t).then((function(){j(t,e,n,r-1)}))})).catch(n);n(o)}}var k={_driver:"asyncStorage",_initStorage:function(t){var e=this,n={db:null};if(t)for(var r in t)n[r]=t[r];var o=h[n.name];o||(o={forages:[],db:null,dbReady:null,deferredOperations:[]},h[n.name]=o),o.forages.push(e),e._initReady||(e._initReady=e.ready,e.ready=S);var i=[];function s(){return a.resolve()}for(var c=0;c<o.forages.length;c++){var u=o.forages[c];u!==e&&i.push(u._initReady().catch(s))}var l=o.forages.slice(0);return a.all(i).then((function(){return n.db=o.db,b(n)})).then((function(t){return n.db=t,x(n,e._defaultConfig.version)?w(n):t})).then((function(t){n.db=o.db=t,e._dbInfo=n;for(var r=0;r<l.length;r++){var i=l[r];i!==e&&(i._dbInfo.db=n.db,i._dbInfo.version=n.version)}}))},_support:function(){try{if(!o||!o.open)return!1;var t="undefined"!=typeof openDatabase&&/(Safari|iPhone|iPad|iPod)/.test(navigator.userAgent)&&!/Chrome/.test(navigator.userAgent)&&!/BlackBerry/.test(navigator.platform),e="function"==typeof fetch&&-1!==fetch.toString().indexOf("[native code");return(!t||e)&&"undefined"!=typeof indexedDB&&"undefined"!=typeof IDBKeyRange}catch(t){return!1}}(),iterate:function(t,e){var n=this,r=new a((function(e,r){n.ready().then((function(){j(n._dbInfo,"readonly",(function(o,i){if(o)return r(o);try{var a=i.objectStore(n._dbInfo.storeName).openCursor(),s=1;a.onsuccess=function(){var n=a.result;if(n){var r=n.value;O(r)&&(r=_(r));var o=t(r,n.key,s++);void 0!==o?e(o):n.continue()}else e()},a.onerror=function(){r(a.error)}}catch(t){r(t)}}))})).catch(r)}));return s(r,e),r},getItem:function(t,e){var n=this;t=u(t);var r=new a((function(e,r){n.ready().then((function(){j(n._dbInfo,"readonly",(function(o,i){if(o)return r(o);try{var a=i.objectStore(n._dbInfo.storeName).get(t);a.onsuccess=function(){var t=a.result;void 0===t&&(t=null),O(t)&&(t=_(t)),e(t)},a.onerror=function(){r(a.error)}}catch(t){r(t)}}))})).catch(r)}));return s(r,e),r},setItem:function(t,e,n){var r=this;t=u(t);var o=new a((function(n,o){var i;r.ready().then((function(){return i=r._dbInfo,"[object Blob]"===d.call(e)?f(i.db).then((function(t){return t?e:(n=e,new a((function(t,e){var r=new FileReader;r.onerror=e,r.onloadend=function(e){var r=btoa(e.target.result||"");t({__local_forage_encoded_blob:!0,data:r,type:n.type})},r.readAsBinaryString(n)})));var n})):e})).then((function(e){j(r._dbInfo,"readwrite",(function(i,a){if(i)return o(i);try{var s=a.objectStore(r._dbInfo.storeName);null===e&&(e=void 0);var c=s.put(e,t);a.oncomplete=function(){void 0===e&&(e=null),n(e)},a.onabort=a.onerror=function(){var t=c.error?c.error:c.transaction.error;o(t)}}catch(t){o(t)}}))})).catch(o)}));return s(o,n),o},removeItem:function(t,e){var n=this;t=u(t);var r=new a((function(e,r){n.ready().then((function(){j(n._dbInfo,"readwrite",(function(o,i){if(o)return r(o);try{var a=i.objectStore(n._dbInfo.storeName).delete(t);i.oncomplete=function(){e()},i.onerror=function(){r(a.error)},i.onabort=function(){var t=a.error?a.error:a.transaction.error;r(t)}}catch(t){r(t)}}))})).catch(r)}));return s(r,e),r},clear:function(t){var e=this,n=new a((function(t,n){e.ready().then((function(){j(e._dbInfo,"readwrite",(function(r,o){if(r)return n(r);try{var i=o.objectStore(e._dbInfo.storeName).clear();o.oncomplete=function(){t()},o.onabort=o.onerror=function(){var t=i.error?i.error:i.transaction.error;n(t)}}catch(t){n(t)}}))})).catch(n)}));return s(n,t),n},length:function(t){var e=this,n=new a((function(t,n){e.ready().then((function(){j(e._dbInfo,"readonly",(function(r,o){if(r)return n(r);try{var i=o.objectStore(e._dbInfo.storeName).count();i.onsuccess=function(){t(i.result)},i.onerror=function(){n(i.error)}}catch(t){n(t)}}))})).catch(n)}));return s(n,t),n},key:function(t,e){var n=this,r=new a((function(e,r){t<0?e(null):n.ready().then((function(){j(n._dbInfo,"readonly",(function(o,i){if(o)return r(o);try{var a=i.objectStore(n._dbInfo.storeName),s=!1,c=a.openKeyCursor();c.onsuccess=function(){var n=c.result;n?0===t||s?e(n.key):(s=!0,n.advance(t)):e(null)},c.onerror=function(){r(c.error)}}catch(t){r(t)}}))})).catch(r)}));return s(r,e),r},keys:function(t){var e=this,n=new a((function(t,n){e.ready().then((function(){j(e._dbInfo,"readonly",(function(r,o){if(r)return n(r);try{var i=o.objectStore(e._dbInfo.storeName).openKeyCursor(),a=[];i.onsuccess=function(){var e=i.result;e?(a.push(e.key),e.continue()):t(a)},i.onerror=function(){n(i.error)}}catch(t){n(t)}}))})).catch(n)}));return s(n,t),n},dropInstance:function(t,e){e=l.apply(this,arguments);var n=this.config();(t="function"!=typeof t&&t||{}).name||(t.name=t.name||n.name,t.storeName=t.storeName||n.storeName);var r,i=this;if(t.name){var c=t.name===n.name&&i._dbInfo.db,u=c?a.resolve(i._dbInfo.db):b(t).then((function(e){var n=h[t.name],r=n.forages;n.db=e;for(var o=0;o<r.length;o++)r[o]._dbInfo.db=e;return e}));r=t.storeName?u.then((function(e){if(e.objectStoreNames.contains(t.storeName)){var n=e.version+1;g(t);var r=h[t.name],i=r.forages;e.close();for(var s=0;s<i.length;s++){var c=i[s];c._dbInfo.db=null,c._dbInfo.version=n}return new a((function(e,r){var i=o.open(t.name,n);i.onerror=function(t){i.result.close(),r(t)},i.onupgradeneeded=function(){i.result.deleteObjectStore(t.storeName)},i.onsuccess=function(){var t=i.result;t.close(),e(t)}})).then((function(t){r.db=t;for(var e=0;e<i.length;e++){var n=i[e];n._dbInfo.db=t,v(n._dbInfo)}})).catch((function(e){throw(m(t,e)||a.resolve()).catch((function(){})),e}))}})):u.then((function(e){g(t);var n=h[t.name],r=n.forages;e.close();for(var i=0;i<r.length;i++)r[i]._dbInfo.db=null;return new a((function(e,n){var r=o.deleteDatabase(t.name);r.onerror=r.onblocked=function(t){var e=r.result;e&&e.close(),n(t)},r.onsuccess=function(){var t=r.result;t&&t.close(),e(t)}})).then((function(t){n.db=t;for(var e=0;e<r.length;e++)v(r[e]._dbInfo)})).catch((function(e){throw(m(t,e)||a.resolve()).catch((function(){})),e}))}))}else r=a.reject("Invalid arguments");return s(r,e),r}},A="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",T=/^~~local_forage_type~([^~]+)~/,E="__lfsc__:".length,C=E+"arbf".length,R=Object.prototype.toString;function I(t){var e,n,r,o,i,a=.75*t.length,s=t.length,c=0;"="===t[t.length-1]&&(a--,"="===t[t.length-2]&&a--);var u=new ArrayBuffer(a),l=new Uint8Array(u);for(e=0;e<s;e+=4)n=A.indexOf(t[e]),r=A.indexOf(t[e+1]),o=A.indexOf(t[e+2]),i=A.indexOf(t[e+3]),l[c++]=n<<2|r>>4,l[c++]=(15&r)<<4|o>>2,l[c++]=(3&o)<<6|63&i;return u}function P(t){var e,n=new Uint8Array(t),r="";for(e=0;e<n.length;e+=3)r+=A[n[e]>>2],r+=A[(3&n[e])<<4|n[e+1]>>4],r+=A[(15&n[e+1])<<2|n[e+2]>>6],r+=A[63&n[e+2]];return n.length%3==2?r=r.substring(0,r.length-1)+"=":n.length%3==1&&(r=r.substring(0,r.length-2)+"=="),r}var M={serialize:function(t,e){var n="";if(t&&(n=R.call(t)),t&&("[object ArrayBuffer]"===n||t.buffer&&"[object ArrayBuffer]"===R.call(t.buffer))){var r,o="__lfsc__:";t instanceof ArrayBuffer?(r=t,o+="arbf"):(r=t.buffer,"[object Int8Array]"===n?o+="si08":"[object Uint8Array]"===n?o+="ui08":"[object Uint8ClampedArray]"===n?o+="uic8":"[object Int16Array]"===n?o+="si16":"[object Uint16Array]"===n?o+="ur16":"[object Int32Array]"===n?o+="si32":"[object Uint32Array]"===n?o+="ui32":"[object Float32Array]"===n?o+="fl32":"[object Float64Array]"===n?o+="fl64":e(new Error("Failed to get type for BinaryArray"))),e(o+P(r))}else if("[object Blob]"===n){var i=new FileReader;i.onload=function(){var n="~~local_forage_type~"+t.type+"~"+P(this.result);e("__lfsc__:blob"+n)},i.readAsArrayBuffer(t)}else try{e(JSON.stringify(t))}catch(n){console.error("Couldn't convert value into a JSON string: ",t),e(null,n)}},deserialize:function(t){if("__lfsc__:"!==t.substring(0,E))return JSON.parse(t);var e,n=t.substring(C),r=t.substring(E,C);if("blob"===r&&T.test(n)){var o=n.match(T);e=o[1],n=n.substring(o[0].length)}var a=I(n);switch(r){case"arbf":return a;case"blob":return i([a],{type:e});case"si08":return new Int8Array(a);case"ui08":return new Uint8Array(a);case"uic8":return new Uint8ClampedArray(a);case"si16":return new Int16Array(a);case"ur16":return new Uint16Array(a);case"si32":return new Int32Array(a);case"ui32":return new Uint32Array(a);case"fl32":return new Float32Array(a);case"fl64":return new Float64Array(a);default:throw new Error("Unkown type: "+r)}},stringToBuffer:I,bufferToString:P};function L(t,e,n,r){t.executeSql("CREATE TABLE IF NOT EXISTS "+e.storeName+" (id INTEGER PRIMARY KEY, key unique, value)",[],n,r)}function N(t,e,n,r,o,i){t.executeSql(n,r,o,(function(t,a){a.code===a.SYNTAX_ERR?t.executeSql("SELECT name FROM sqlite_master WHERE type='table' AND name = ?",[e.storeName],(function(t,s){s.rows.length?i(t,a):L(t,e,(function(){t.executeSql(n,r,o,i)}),i)}),i):i(t,a)}),i)}function B(t,e,n,r){var o=this;t=u(t);var i=new a((function(i,a){o.ready().then((function(){void 0===e&&(e=null);var s=e,c=o._dbInfo;c.serializer.serialize(e,(function(e,u){u?a(u):c.db.transaction((function(n){N(n,c,"INSERT OR REPLACE INTO "+c.storeName+" (key, value) VALUES (?, ?)",[t,e],(function(){i(s)}),(function(t,e){a(e)}))}),(function(e){if(e.code===e.QUOTA_ERR){if(r>0)return void i(B.apply(o,[t,s,n,r-1]));a(e)}}))}))})).catch(a)}));return s(i,n),i}function D(t){return new a((function(e,n){t.transaction((function(r){r.executeSql("SELECT name FROM sqlite_master WHERE type='table' AND name <> '__WebKitDatabaseInfoTable__'",[],(function(n,r){for(var o=[],i=0;i<r.rows.length;i++)o.push(r.rows.item(i).name);e({db:t,storeNames:o})}),(function(t,e){n(e)}))}),(function(t){n(t)}))}))}var U={_driver:"webSQLStorage",_initStorage:function(t){var e=this,n={db:null};if(t)for(var r in t)n[r]="string"!=typeof t[r]?t[r].toString():t[r];var o=new a((function(t,r){try{n.db=openDatabase(n.name,String(n.version),n.description,n.size)}catch(t){return r(t)}n.db.transaction((function(o){L(o,n,(function(){e._dbInfo=n,t()}),(function(t,e){r(e)}))}),r)}));return n.serializer=M,o},_support:"function"==typeof openDatabase,iterate:function(t,e){var n=this,r=new a((function(e,r){n.ready().then((function(){var o=n._dbInfo;o.db.transaction((function(n){N(n,o,"SELECT * FROM "+o.storeName,[],(function(n,r){for(var i=r.rows,a=i.length,s=0;s<a;s++){var c=i.item(s),u=c.value;if(u&&(u=o.serializer.deserialize(u)),void 0!==(u=t(u,c.key,s+1)))return void e(u)}e()}),(function(t,e){r(e)}))}))})).catch(r)}));return s(r,e),r},getItem:function(t,e){var n=this;t=u(t);var r=new a((function(e,r){n.ready().then((function(){var o=n._dbInfo;o.db.transaction((function(n){N(n,o,"SELECT * FROM "+o.storeName+" WHERE key = ? LIMIT 1",[t],(function(t,n){var r=n.rows.length?n.rows.item(0).value:null;r&&(r=o.serializer.deserialize(r)),e(r)}),(function(t,e){r(e)}))}))})).catch(r)}));return s(r,e),r},setItem:function(t,e,n){return B.apply(this,[t,e,n,1])},removeItem:function(t,e){var n=this;t=u(t);var r=new a((function(e,r){n.ready().then((function(){var o=n._dbInfo;o.db.transaction((function(n){N(n,o,"DELETE FROM "+o.storeName+" WHERE key = ?",[t],(function(){e()}),(function(t,e){r(e)}))}))})).catch(r)}));return s(r,e),r},clear:function(t){var e=this,n=new a((function(t,n){e.ready().then((function(){var r=e._dbInfo;r.db.transaction((function(e){N(e,r,"DELETE FROM "+r.storeName,[],(function(){t()}),(function(t,e){n(e)}))}))})).catch(n)}));return s(n,t),n},length:function(t){var e=this,n=new a((function(t,n){e.ready().then((function(){var r=e._dbInfo;r.db.transaction((function(e){N(e,r,"SELECT COUNT(key) as c FROM "+r.storeName,[],(function(e,n){var r=n.rows.item(0).c;t(r)}),(function(t,e){n(e)}))}))})).catch(n)}));return s(n,t),n},key:function(t,e){var n=this,r=new a((function(e,r){n.ready().then((function(){var o=n._dbInfo;o.db.transaction((function(n){N(n,o,"SELECT key FROM "+o.storeName+" WHERE id = ? LIMIT 1",[t+1],(function(t,n){var r=n.rows.length?n.rows.item(0).key:null;e(r)}),(function(t,e){r(e)}))}))})).catch(r)}));return s(r,e),r},keys:function(t){var e=this,n=new a((function(t,n){e.ready().then((function(){var r=e._dbInfo;r.db.transaction((function(e){N(e,r,"SELECT key FROM "+r.storeName,[],(function(e,n){for(var r=[],o=0;o<n.rows.length;o++)r.push(n.rows.item(o).key);t(r)}),(function(t,e){n(e)}))}))})).catch(n)}));return s(n,t),n},dropInstance:function(t,e){e=l.apply(this,arguments);var n=this.config();(t="function"!=typeof t&&t||{}).name||(t.name=t.name||n.name,t.storeName=t.storeName||n.storeName);var r,o=this;return s(r=t.name?new a((function(e){var r;r=t.name===n.name?o._dbInfo.db:openDatabase(t.name,"","",0),t.storeName?e({db:r,storeNames:[t.storeName]}):e(D(r))})).then((function(t){return new a((function(e,n){t.db.transaction((function(r){function o(t){return new a((function(e,n){r.executeSql("DROP TABLE IF EXISTS "+t,[],(function(){e()}),(function(t,e){n(e)}))}))}for(var i=[],s=0,c=t.storeNames.length;s<c;s++)i.push(o(t.storeNames[s]));a.all(i).then((function(){e()})).catch((function(t){n(t)}))}),(function(t){n(t)}))}))})):a.reject("Invalid arguments"),e),r}};function $(t,e){var n=t.name+"/";return t.storeName!==e.storeName&&(n+=t.storeName+"/"),n}function z(){return!function(){try{return localStorage.setItem("_localforage_support_test",!0),localStorage.removeItem("_localforage_support_test"),!1}catch(t){return!0}}()||localStorage.length>0}var V={_driver:"localStorageWrapper",_initStorage:function(t){var e={};if(t)for(var n in t)e[n]=t[n];return e.keyPrefix=$(t,this._defaultConfig),z()?(this._dbInfo=e,e.serializer=M,a.resolve()):a.reject()},_support:function(){try{return"undefined"!=typeof localStorage&&"setItem"in localStorage&&!!localStorage.setItem}catch(t){return!1}}(),iterate:function(t,e){var n=this,r=n.ready().then((function(){for(var e=n._dbInfo,r=e.keyPrefix,o=r.length,i=localStorage.length,a=1,s=0;s<i;s++){var c=localStorage.key(s);if(0===c.indexOf(r)){var u=localStorage.getItem(c);if(u&&(u=e.serializer.deserialize(u)),void 0!==(u=t(u,c.substring(o),a++)))return u}}}));return s(r,e),r},getItem:function(t,e){var n=this;t=u(t);var r=n.ready().then((function(){var e=n._dbInfo,r=localStorage.getItem(e.keyPrefix+t);return r&&(r=e.serializer.deserialize(r)),r}));return s(r,e),r},setItem:function(t,e,n){var r=this;t=u(t);var o=r.ready().then((function(){void 0===e&&(e=null);var n=e;return new a((function(o,i){var a=r._dbInfo;a.serializer.serialize(e,(function(e,r){if(r)i(r);else try{localStorage.setItem(a.keyPrefix+t,e),o(n)}catch(t){"QuotaExceededError"!==t.name&&"NS_ERROR_DOM_QUOTA_REACHED"!==t.name||i(t),i(t)}}))}))}));return s(o,n),o},removeItem:function(t,e){var n=this;t=u(t);var r=n.ready().then((function(){var e=n._dbInfo;localStorage.removeItem(e.keyPrefix+t)}));return s(r,e),r},clear:function(t){var e=this,n=e.ready().then((function(){for(var t=e._dbInfo.keyPrefix,n=localStorage.length-1;n>=0;n--){var r=localStorage.key(n);0===r.indexOf(t)&&localStorage.removeItem(r)}}));return s(n,t),n},length:function(t){var e=this.keys().then((function(t){return t.length}));return s(e,t),e},key:function(t,e){var n=this,r=n.ready().then((function(){var e,r=n._dbInfo;try{e=localStorage.key(t)}catch(t){e=null}return e&&(e=e.substring(r.keyPrefix.length)),e}));return s(r,e),r},keys:function(t){var e=this,n=e.ready().then((function(){for(var t=e._dbInfo,n=localStorage.length,r=[],o=0;o<n;o++){var i=localStorage.key(o);0===i.indexOf(t.keyPrefix)&&r.push(i.substring(t.keyPrefix.length))}return r}));return s(n,t),n},dropInstance:function(t,e){if(e=l.apply(this,arguments),!(t="function"!=typeof t&&t||{}).name){var n=this.config();t.name=t.name||n.name,t.storeName=t.storeName||n.storeName}var r,o=this;return s(r=t.name?new a((function(e){t.storeName?e($(t,o._defaultConfig)):e(t.name+"/")})).then((function(t){for(var e=localStorage.length-1;e>=0;e--){var n=localStorage.key(e);0===n.indexOf(t)&&localStorage.removeItem(n)}})):a.reject("Invalid arguments"),e),r}},q=function(t,e){for(var n,r,o=t.length,i=0;i<o;){if((n=t[i])===(r=e)||"number"==typeof n&&"number"==typeof r&&isNaN(n)&&isNaN(r))return!0;i++}return!1},F=Array.isArray||function(t){return"[object Array]"===Object.prototype.toString.call(t)},H={},W={},G={INDEXEDDB:k,WEBSQL:U,LOCALSTORAGE:V},X=[G.INDEXEDDB._driver,G.WEBSQL._driver,G.LOCALSTORAGE._driver],Y=["dropInstance"],K=["clear","getItem","iterate","key","keys","length","removeItem","setItem"].concat(Y),J={description:"",driver:X.slice(),name:"localforage",size:4980736,storeName:"keyvaluepairs",version:1};function Q(t,e){t[e]=function(){var n=arguments;return t.ready().then((function(){return t[e].apply(t,n)}))}}function Z(){for(var t=1;t<arguments.length;t++){var e=arguments[t];if(e)for(var n in e)e.hasOwnProperty(n)&&(F(e[n])?arguments[0][n]=e[n].slice():arguments[0][n]=e[n])}return arguments[0]}var tt=new(function(){function t(e){for(var n in function(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}(this,t),G)if(G.hasOwnProperty(n)){var r=G[n],o=r._driver;this[n]=o,H[o]||this.defineDriver(r)}this._defaultConfig=Z({},J),this._config=Z({},this._defaultConfig,e),this._driverSet=null,this._initDriver=null,this._ready=!1,this._dbInfo=null,this._wrapLibraryMethodsWithReady(),this.setDriver(this._config.driver).catch((function(){}))}return t.prototype.config=function(t){if("object"===(void 0===t?"undefined":r(t))){if(this._ready)return new Error("Can't call config() after localforage has been used.");for(var e in t){if("storeName"===e&&(t[e]=t[e].replace(/\W/g,"_")),"version"===e&&"number"!=typeof t[e])return new Error("Database version must be a number.");this._config[e]=t[e]}return!("driver"in t)||!t.driver||this.setDriver(this._config.driver)}return"string"==typeof t?this._config[t]:this._config},t.prototype.defineDriver=function(t,e,n){var r=new a((function(e,n){try{var r=t._driver,o=new Error("Custom driver not compliant; see https://mozilla.github.io/localForage/#definedriver");if(!t._driver)return void n(o);for(var i=K.concat("_initStorage"),c=0,u=i.length;c<u;c++){var l=i[c];if((!q(Y,l)||t[l])&&"function"!=typeof t[l])return void n(o)}!function(){for(var e=function(t){return function(){var e=new Error("Method "+t+" is not implemented by the current driver"),n=a.reject(e);return s(n,arguments[arguments.length-1]),n}},n=0,r=Y.length;n<r;n++){var o=Y[n];t[o]||(t[o]=e(o))}}();var p=function(n){H[r]&&console.info("Redefining LocalForage driver: "+r),H[r]=t,W[r]=n,e()};"_support"in t?t._support&&"function"==typeof t._support?t._support().then(p,n):p(!!t._support):p(!0)}catch(t){n(t)}}));return c(r,e,n),r},t.prototype.driver=function(){return this._driver||null},t.prototype.getDriver=function(t,e,n){var r=H[t]?a.resolve(H[t]):a.reject(new Error("Driver not found."));return c(r,e,n),r},t.prototype.getSerializer=function(t){var e=a.resolve(M);return c(e,t),e},t.prototype.ready=function(t){var e=this,n=e._driverSet.then((function(){return null===e._ready&&(e._ready=e._initDriver()),e._ready}));return c(n,t,t),n},t.prototype.setDriver=function(t,e,n){var r=this;F(t)||(t=[t]);var o=this._getSupportedDrivers(t);function i(){r._config.driver=r.driver()}function s(t){return r._extend(t),i(),r._ready=r._initStorage(r._config),r._ready}var u=null!==this._driverSet?this._driverSet.catch((function(){return a.resolve()})):a.resolve();return this._driverSet=u.then((function(){var t=o[0];return r._dbInfo=null,r._ready=null,r.getDriver(t).then((function(t){r._driver=t._driver,i(),r._wrapLibraryMethodsWithReady(),r._initDriver=function(t){return function(){var e=0;return function n(){for(;e<t.length;){var o=t[e];return e++,r._dbInfo=null,r._ready=null,r.getDriver(o).then(s).catch(n)}i();var c=new Error("No available storage method found.");return r._driverSet=a.reject(c),r._driverSet}()}}(o)}))})).catch((function(){i();var t=new Error("No available storage method found.");return r._driverSet=a.reject(t),r._driverSet})),c(this._driverSet,e,n),this._driverSet},t.prototype.supports=function(t){return!!W[t]},t.prototype._extend=function(t){Z(this,t)},t.prototype._getSupportedDrivers=function(t){for(var e=[],n=0,r=t.length;n<r;n++){var o=t[n];this.supports(o)&&e.push(o)}return e},t.prototype._wrapLibraryMethodsWithReady=function(){for(var t=0,e=K.length;t<e;t++)Q(this,K[t])},t.prototype.createInstance=function(e){return new t(e)},t}());e.exports=tt},{3:3}]},{},[4])(4)}).call(this,n(51))},function(t,e,n){"use strict";var r=n(12),o=n(110).f,i=n(111),a=n(70),s=n(73),c=n(39),u=n(29),l=function(t){var e=function(e,n,r){if(this instanceof t){switch(arguments.length){case 0:return new t;case 1:return new t(e);case 2:return new t(e,n)}return new t(e,n,r)}return t.apply(this,arguments)};return e.prototype=t.prototype,e};t.exports=function(t,e){var n,p,h,d,f,g,v,m,y=t.target,b=t.global,w=t.stat,x=t.proto,_=b?r:w?r[y]:(r[y]||{}).prototype,O=b?a:a[y]||(a[y]={}),S=O.prototype;for(h in e)n=!i(b?h:y+(w?".":"#")+h,t.forced)&&_&&u(_,h),f=O[h],n&&(g=t.noTargetGet?(m=o(_,h))&&m.value:_[h]),d=n&&g?g:e[h],n&&typeof f==typeof d||(v=t.bind&&n?s(d,r):t.wrap&&n?l(d):x&&"function"==typeof d?s(Function.call,d):d,(t.sham||d&&d.sham||f&&f.sham)&&c(v,"sham",!0),O[h]=v,x&&(u(a,p=y+"Prototype")||c(a,p,{}),a[p][h]=d,t.real&&S&&!S[h]&&c(S,h,d)))}},function(t,e,n){var r=n(30);t.exports=function(t){if(!r(t))throw TypeError(String(t)+" is not an object");return t}},function(t,e,n){var r=n(72),o={}.hasOwnProperty;t.exports=Object.hasOwn||function(t,e){return o.call(r(t),e)}},function(t,e){t.exports=function(t){return"object"==typeof t?null!==t:"function"==typeof t}},function(t,e,n){var r=n(138),o=n(4),i=function(t){return"function"==typeof t?t:void 0};t.exports=function(t,e){return arguments.length<2?i(r[t])||i(o[t]):r[t]&&r[t][e]||o[t]&&o[t][e]}},function(t,e){t.exports={}},function(t,e,n){var r=n(12),o=n(202),i=n(29),a=n(203),s=n(206),c=n(274),u=o("wks"),l=r.Symbol,p=c?l:l&&l.withoutSetter||a;t.exports=function(t){return i(u,t)&&(s||"string"==typeof u[t])||(s&&i(l,t)?u[t]=l[t]:u[t]=p("Symbol."+t)),u[t]}},function(t,e){var n={}.toString;t.exports=function(t){return n.call(t).slice(8,-1)}},function(t,e){t.exports=function(t){if(null==t)throw TypeError("Can't call method on "+t);return t}},function(t,e,n){var r,o,i,a=n(136),s=n(4),c=n(16),u=n(15),l=n(11),p=n(58),h=n(59),d=n(61),f=s.WeakMap;if(a||p.state){var g=p.state||(p.state=new f),v=g.get,m=g.has,y=g.set;r=function(t,e){if(m.call(g,t))throw new TypeError("Object already initialized");return e.facade=t,y.call(g,t,e),e},o=function(t){return v.call(g,t)||{}},i=function(t){return m.call(g,t)}}else{var b=h("state");d[b]=!0,r=function(t,e){if(l(t,b))throw new TypeError("Object already initialized");return e.facade=t,u(t,b,e),e},o=function(t){return l(t,b)?t[b]:{}},i=function(t){return l(t,b)}}t.exports={set:r,get:o,has:i,enforce:function(t){return i(t)?o(t):r(t,{})},getterFor:function(t){return function(e){var n;if(!c(e)||(n=o(e)).type!==t)throw TypeError("Incompatible receiver, "+t+" required");return n}}}},function(t,e){t.exports=function(t){if("function"!=typeof t)throw TypeError(String(t)+" is not a function");return t}},function(t,e,n){"use strict";var r=n(216),o=Object.prototype.toString;function i(t){return"[object Array]"===o.call(t)}function a(t){return void 0===t}function s(t){return null!==t&&"object"==typeof t}function c(t){return"[object Function]"===o.call(t)}function u(t,e){if(null!=t)if("object"!=typeof t&&(t=[t]),i(t))for(var n=0,r=t.length;n<r;n++)e.call(null,t[n],n,t);else for(var o in t)Object.prototype.hasOwnProperty.call(t,o)&&e.call(null,t[o],o,t)}t.exports={isArray:i,isArrayBuffer:function(t){return"[object ArrayBuffer]"===o.call(t)},isBuffer:function(t){return null!==t&&!a(t)&&null!==t.constructor&&!a(t.constructor)&&"function"==typeof t.constructor.isBuffer&&t.constructor.isBuffer(t)},isFormData:function(t){return"undefined"!=typeof FormData&&t instanceof FormData},isArrayBufferView:function(t){return"undefined"!=typeof ArrayBuffer&&ArrayBuffer.isView?ArrayBuffer.isView(t):t&&t.buffer&&t.buffer instanceof ArrayBuffer},isString:function(t){return"string"==typeof t},isNumber:function(t){return"number"==typeof t},isObject:s,isUndefined:a,isDate:function(t){return"[object Date]"===o.call(t)},isFile:function(t){return"[object File]"===o.call(t)},isBlob:function(t){return"[object Blob]"===o.call(t)},isFunction:c,isStream:function(t){return s(t)&&c(t.pipe)},isURLSearchParams:function(t){return"undefined"!=typeof URLSearchParams&&t instanceof URLSearchParams},isStandardBrowserEnv:function(){return("undefined"==typeof navigator||"ReactNative"!==navigator.product&&"NativeScript"!==navigator.product&&"NS"!==navigator.product)&&("undefined"!=typeof window&&"undefined"!=typeof document)},forEach:u,merge:function t(){var e={};function n(n,r){"object"==typeof e[r]&&"object"==typeof n?e[r]=t(e[r],n):e[r]=n}for(var r=0,o=arguments.length;r<o;r++)u(arguments[r],n);return e},deepMerge:function t(){var e={};function n(n,r){"object"==typeof e[r]&&"object"==typeof n?e[r]=t(e[r],n):e[r]="object"==typeof n?t({},n):n}for(var r=0,o=arguments.length;r<o;r++)u(arguments[r],n);return e},extend:function(t,e,n){return u(e,(function(e,o){t[o]=n&&"function"==typeof e?r(e,n):e})),t},trim:function(t){return t.replace(/^\s*/,"").replace(/\s*$/,"")}}},function(t,e,n){var r=n(25),o=n(71),i=n(47);t.exports=r?function(t,e,n){return o.f(t,e,i(1,n))}:function(t,e,n){return t[e]=n,t}},function(t,e,n){var r=n(31);t.exports=r("navigator","userAgent")||""},function(t,e){t.exports=!1},function(t,e,n){var r=n(108),o=n(35);t.exports=function(t){return r(o(t))}},function(t,e){var n=Math.ceil,r=Math.floor;t.exports=function(t){return isNaN(t=+t)?0:(t>0?r:n)(t)}},function(t,e,n){"use strict";var r=n(163),o=n(8),i=n(9),a=n(45),s=n(43),c=n(35),u=n(164),l=n(166),p=n(167),h=n(6)("replace"),d=Math.max,f=Math.min,g="$0"==="a".replace(/./,"$0"),v=!!/./[h]&&""===/./[h]("a","$0");r("replace",(function(t,e,n){var r=v?"$":"$0";return[function(t,n){var r=c(this),o=null==t?void 0:t[h];return void 0!==o?o.call(t,r,n):e.call(String(r),t,n)},function(t,o){if("string"==typeof o&&-1===o.indexOf(r)&&-1===o.indexOf("$<")){var c=n(e,this,t,o);if(c.done)return c.value}var h=i(this),g=String(t),v="function"==typeof o;v||(o=String(o));var m=h.global;if(m){var y=h.unicode;h.lastIndex=0}for(var b=[];;){var w=p(h,g);if(null===w)break;if(b.push(w),!m)break;""===String(w[0])&&(h.lastIndex=u(g,a(h.lastIndex),y))}for(var x,_="",O=0,S=0;S<b.length;S++){w=b[S];for(var j=String(w[0]),k=d(f(s(w.index),g.length),0),A=[],T=1;T<w.length;T++)A.push(void 0===(x=w[T])?x:String(x));var E=w.groups;if(v){var C=[j].concat(A,k,g);void 0!==E&&C.push(E);var R=String(o.apply(void 0,C))}else R=l(j,g,k,A,E,o);k>=O&&(_+=g.slice(O,k)+R,O=k+j.length)}return _+g.slice(O)}]}),!!o((function(){var t=/./;return t.exec=function(){var t=[];return t.groups={a:"7"},t},"7"!=="".replace(t,"$<a>")}))||!g||v)},function(t,e,n){var r=n(43),o=Math.min;t.exports=function(t){return t>0?o(r(t),9007199254740991):0}},function(t,e,n){var r=n(4),o=n(53).f,i=n(15),a=n(24),s=n(56),c=n(124),u=n(76);t.exports=function(t,e){var n,l,p,h,d,f=t.target,g=t.global,v=t.stat;if(n=g?r:v?r[f]||s(f,{}):(r[f]||{}).prototype)for(l in e){if(h=e[l],p=t.noTargetGet?(d=o(n,l))&&d.value:n[l],!u(g?l:f+(v?".":"#")+l,t.forced)&&void 0!==p){if(typeof h==typeof p)continue;c(h,p)}(t.sham||p&&p.sham)&&i(h,"sham",!0),a(n,l,h,t)}}},function(t,e){t.exports=function(t,e){return{enumerable:!(1&t),configurable:!(2&t),writable:!(4&t),value:e}}},function(t,e,n){t.exports=n(308)},function(t,e){t.exports=function(t){if("function"!=typeof t)throw TypeError(String(t)+" is not a function");return t}},function(t,e,n){var r=n(35);t.exports=function(t){return Object(r(t))}},function(t,e){var n;n=function(){return this}();try{n=n||new Function("return this")()}catch(t){"object"==typeof window&&(n=window)}t.exports=n},function(t,e,n){var r=n(4),o=n(109),i=n(261),a=n(15);for(var s in o){var c=r[s],u=c&&c.prototype;if(u&&u.forEach!==i)try{a(u,"forEach",i)}catch(t){u.forEach=i}}},function(t,e,n){var r=n(20),o=n(135),i=n(54),a=n(42),s=n(85),c=n(11),u=n(86),l=Object.getOwnPropertyDescriptor;e.f=r?l:function(t,e){if(t=a(t),e=s(e,!0),u)try{return l(t,e)}catch(t){}if(c(t,e))return i(!o.f.call(t,e),t[e])}},function(t,e){t.exports=function(t,e){return{enumerable:!(1&t),configurable:!(2&t),writable:!(4&t),value:e}}},function(t,e,n){var r=n(4),o=n(16),i=r.document,a=o(i)&&o(i.createElement);t.exports=function(t){return a?i.createElement(t):{}}},function(t,e,n){var r=n(4),o=n(15);t.exports=function(t,e){try{o(r,t,e)}catch(n){r[t]=e}return e}},function(t,e,n){var r=n(58),o=Function.toString;"function"!=typeof r.inspectSource&&(r.inspectSource=function(t){return o.call(t)}),t.exports=r.inspectSource},function(t,e,n){var r=n(4),o=n(56),i=r["__core-js_shared__"]||o("__core-js_shared__",{});t.exports=i},function(t,e,n){var r=n(60),o=n(75),i=r("keys");t.exports=function(t){return i[t]||(i[t]=o(t))}},function(t,e,n){var r=n(41),o=n(58);(t.exports=function(t,e){return o[t]||(o[t]=void 0!==e?e:{})})("versions",[]).push({version:"3.15.2",mode:r?"pure":"global",copyright:"© 2021 Denis Pushkarev (zloirock.ru)"})},function(t,e){t.exports={}},function(t,e){t.exports=["constructor","hasOwnProperty","isPrototypeOf","propertyIsEnumerable","toLocaleString","toString","valueOf"]},function(t,e,n){var r=n(21).f,o=n(11),i=n(6)("toStringTag");t.exports=function(t,e,n){t&&!o(t=n?t:t.prototype,i)&&r(t,i,{configurable:!0,value:e})}},function(t,e,n){var r=n(34),o=n(4);t.exports="process"==r(o.process)},function(t,e,n){var r,o=n(9),i=n(158),a=n(62),s=n(61),c=n(90),u=n(55),l=n(59),p=l("IE_PROTO"),h=function(){},d=function(t){return"<script>"+t+"<\/script>"},f=function(){try{r=document.domain&&new ActiveXObject("htmlfile")}catch(t){}var t,e;f=r?function(t){t.write(d("")),t.close();var e=t.parentWindow.Object;return t=null,e}(r):((e=u("iframe")).style.display="none",c.appendChild(e),e.src=String("javascript:"),(t=e.contentWindow.document).open(),t.write(d("document.F=Object")),t.close(),t.F);for(var n=a.length;n--;)delete f.prototype[a[n]];return f()};s[p]=!0,t.exports=Object.create||function(t,e){var n;return null!==t?(h.prototype=o(t),n=new h,h.prototype=null,n[p]=t):n=f(),void 0===e?n:i(n,e)}},function(t,e,n){"use strict";var r,o,i=n(115),a=n(116),s=n(60),c=n(65),u=n(36).get,l=n(117),p=n(118),h=RegExp.prototype.exec,d=s("native-string-replace",String.prototype.replace),f=h,g=(r=/a/,o=/b*/g,h.call(r,"a"),h.call(o,"a"),0!==r.lastIndex||0!==o.lastIndex),v=a.UNSUPPORTED_Y||a.BROKEN_CARET,m=void 0!==/()??/.exec("")[1];(g||m||v||l||p)&&(f=function(t){var e,n,r,o,a,s,l,p=this,y=u(p),b=y.raw;if(b)return b.lastIndex=p.lastIndex,e=f.call(b,t),p.lastIndex=b.lastIndex,e;var w=y.groups,x=v&&p.sticky,_=i.call(p),O=p.source,S=0,j=t;if(x&&(-1===(_=_.replace("y","")).indexOf("g")&&(_+="g"),j=String(t).slice(p.lastIndex),p.lastIndex>0&&(!p.multiline||p.multiline&&"\n"!==t[p.lastIndex-1])&&(O="(?: "+O+")",j=" "+j,S++),n=new RegExp("^(?:"+O+")",_)),m&&(n=new RegExp("^"+O+"$(?!\\s)",_)),g&&(r=p.lastIndex),o=h.call(x?n:p,j),x?o?(o.input=o.input.slice(S),o[0]=o[0].slice(S),o.index=p.lastIndex,p.lastIndex+=o[0].length):p.lastIndex=0:g&&o&&(p.lastIndex=p.global?o.index+o[0].length:r),m&&o&&o.length>1&&d.call(o[0],n,(function(){for(a=1;a<arguments.length-2;a++)void 0===arguments[a]&&(o[a]=void 0)})),o&&w)for(o.groups=s=c(null),a=0;a<w.length;a++)s[(l=w[a])[0]]=o[l[1]];return o}),t.exports=f},function(t,e,n){t.exports=n(168)},function(t,e){t.exports=function(t){if(null==t)throw TypeError("Can't call method on "+t);return t}},function(t,e,n){var r=n(9),o=n(143);t.exports=Object.setPrototypeOf||("__proto__"in{}?function(){var t,e=!1,n={};try{(t=Object.getOwnPropertyDescriptor(Object.prototype,"__proto__").set).call(n,[]),e=n instanceof Array}catch(t){}return function(n,i){return r(n),o(i),e?t.call(n,i):n.__proto__=i,n}}():void 0)},function(t,e){t.exports={}},function(t,e,n){var r=n(25),o=n(95),i=n(28),a=n(79),s=Object.defineProperty;e.f=r?s:function(t,e,n){if(i(t),e=a(e,!0),i(n),o)try{return s(t,e,n)}catch(t){}if("get"in n||"set"in n)throw TypeError("Accessors not supported");return"value"in n&&(t[e]=n.value),t}},function(t,e,n){var r=n(68);t.exports=function(t){return Object(r(t))}},function(t,e,n){var r=n(49);t.exports=function(t,e,n){if(r(t),void 0===e)return t;switch(n){case 0:return function(){return t.call(e)};case 1:return function(n){return t.call(e,n)};case 2:return function(n,r){return t.call(e,n,r)};case 3:return function(n,r,o){return t.call(e,n,r,o)}}return function(){return t.apply(e,arguments)}}},function(t,e,n){var r=n(37);t.exports=function(t,e,n){if(r(t),void 0===e)return t;switch(n){case 0:return function(){return t.call(e)};case 1:return function(n){return t.call(e,n)};case 2:return function(n,r){return t.call(e,n,r)};case 3:return function(n,r,o){return t.call(e,n,r,o)}}return function(){return t.apply(e,arguments)}}},function(t,e){var n=0,r=Math.random();t.exports=function(t){return"Symbol("+String(void 0===t?"":t)+")_"+(++n+r).toString(36)}},function(t,e,n){var r=n(8),o=/#|\.prototype\./,i=function(t,e){var n=s[a(t)];return n==u||n!=c&&("function"==typeof e?r(e):!!e)},a=i.normalize=function(t){return String(t).replace(o,".").toLowerCase()},s=i.data={},c=i.NATIVE="N",u=i.POLYFILL="P";t.exports=i},function(t,e,n){var r,o,i=n(4),a=n(40),s=i.process,c=s&&s.versions,u=c&&c.v8;u?o=(r=u.split("."))[0]<4?1:r[0]+r[1]:a&&(!(r=a.match(/Edge\/(\d+)/))||r[1]>=74)&&(r=a.match(/Chrome\/(\d+)/))&&(o=r[1]),t.exports=o&&+o},function(t,e,n){var r=n(11),o=n(50),i=n(59),a=n(162),s=i("IE_PROTO"),c=Object.prototype;t.exports=a?Object.getPrototypeOf:function(t){return t=o(t),r(t,s)?t[s]:"function"==typeof t.constructor&&t instanceof t.constructor?t.constructor.prototype:t instanceof Object?c:null}},function(t,e,n){var r=n(30);t.exports=function(t,e){if(!r(t))return t;var n,o;if(e&&"function"==typeof(n=t.toString)&&!r(o=n.call(t)))return o;if("function"==typeof(n=t.valueOf)&&!r(o=n.call(t)))return o;if(!e&&"function"==typeof(n=t.toString)&&!r(o=n.call(t)))return o;throw TypeError("Can't convert object to primitive value")}},function(t,e,n){"use strict";n.d(e,"f",(function(){return r})),n.d(e,"g",(function(){return o})),n.d(e,"b",(function(){return a})),n.d(e,"a",(function(){return s})),n.d(e,"d",(function(){return u})),n.d(e,"c",(function(){return l})),n.d(e,"e",(function(){return p}));
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const r=`{{lit-${String(Math.random()).slice(2)}}}`,o=`\x3c!--${r}--\x3e`,i=new RegExp(`${r}|${o}`),a="$lit$";class s{constructor(t,e){this.parts=[],this.element=e;const n=[],o=[],s=document.createTreeWalker(e.content,133,null,!1);let u=0,h=-1,d=0;const{strings:f,values:{length:g}}=t;for(;d<g;){const t=s.nextNode();if(null!==t){if(h++,1===t.nodeType){if(t.hasAttributes()){const e=t.attributes,{length:n}=e;let r=0;for(let t=0;t<n;t++)c(e[t].name,a)&&r++;for(;r-- >0;){const e=f[d],n=p.exec(e)[2],r=n.toLowerCase()+a,o=t.getAttribute(r);t.removeAttribute(r);const s=o.split(i);this.parts.push({type:"attribute",index:h,name:n,strings:s}),d+=s.length-1}}"TEMPLATE"===t.tagName&&(o.push(t),s.currentNode=t.content)}else if(3===t.nodeType){const e=t.data;if(e.indexOf(r)>=0){const r=t.parentNode,o=e.split(i),s=o.length-1;for(let e=0;e<s;e++){let n,i=o[e];if(""===i)n=l();else{const t=p.exec(i);null!==t&&c(t[2],a)&&(i=i.slice(0,t.index)+t[1]+t[2].slice(0,-a.length)+t[3]),n=document.createTextNode(i)}r.insertBefore(n,t),this.parts.push({type:"node",index:++h})}""===o[s]?(r.insertBefore(l(),t),n.push(t)):t.data=o[s],d+=s}}else if(8===t.nodeType)if(t.data===r){const e=t.parentNode;null!==t.previousSibling&&h!==u||(h++,e.insertBefore(l(),t)),u=h,this.parts.push({type:"node",index:h}),null===t.nextSibling?t.data="":(n.push(t),h--),d++}else{let e=-1;for(;-1!==(e=t.data.indexOf(r,e+1));)this.parts.push({type:"node",index:-1}),d++}}else s.currentNode=o.pop()}for(const t of n)t.parentNode.removeChild(t)}}const c=(t,e)=>{const n=t.length-e.length;return n>=0&&t.slice(n)===e},u=t=>-1!==t.index,l=()=>document.createComment(""),p=/([ \x09\x0a\x0c\x0d])([^\0-\x1F\x7F-\x9F "'>=/]+)([ \x09\x0a\x0c\x0d]*=[ \x09\x0a\x0c\x0d]*(?:[^ \x09\x0a\x0c\x0d"'`<>=]*|"[^"]*|'[^']*))$/},function(t,e,n){"use strict";n.d(e,"i",(function(){return r})),n.d(e,"d",(function(){return o})),n.d(e,"h",(function(){return A})),n.d(e,"b",(function(){return i})),n.d(e,"a",(function(){return a})),n.d(e,"g",(function(){return s})),n.d(e,"e",(function(){return u})),n.d(e,"f",(function(){return jt})),n.d(e,"c",(function(){return c}));var r={};n.r(r),n.d(r,"getLocalCity",(function(){return h})),n.d(r,"getForecastWeather",(function(){return d})),n.d(r,"getCityList",(function(){return f}));var o={};n.r(o),n.d(o,"getSearchSuggest",(function(){return w})),n.d(o,"getEnginesList",(function(){return x}));var i={};n.r(i),n.d(i,"getIcon",(function(){return L})),n.d(i,"getUrlInfoWithPermission",(function(){return D})),n.d(i,"getUrlIcon",(function(){return V})),n.d(i,"getFetchiconUrls",(function(){return q})),n.d(i,"getRedirectTargets",(function(){return F}));var a={};n.r(a),n.d(a,"getUnreadEmails",(function(){return W}));var s={};n.r(s),n.d(s,"register",(function(){return K})),n.d(s,"login",(function(){return J})),n.d(s,"updateProfile",(function(){return Q})),n.d(s,"getUserProfile",(function(){return Z})),n.d(s,"uploadAvatar",(function(){return tt})),n.d(s,"modifyPassword",(function(){return et})),n.d(s,"forgetPassword",(function(){return nt})),n.d(s,"resetPassword",(function(){return rt})),n.d(s,"getCode",(function(){return ot})),n.d(s,"getRegisterCode",(function(){return it})),n.d(s,"inspceCode",(function(){return at})),n.d(s,"checkTokenIsExpired",(function(){return st})),n.d(s,"deleteAccount",(function(){return ct})),n.d(s,"loginWithUid",(function(){return ut})),n.d(s,"v1BasicLogin",(function(){return lt})),n.d(s,"getMobileUid",(function(){return pt})),n.d(s,"getMobileloginUrl",(function(){return ht})),n.d(s,"checkMobileloginUrl",(function(){return dt}));var c={};n.r(c),n.d(c,"getRepairConcat",(function(){return ft})),n.d(c,"postErrorCollect",(function(){return gt})),n.d(c,"sendLog",(function(){return vt}));var u={};n.r(u),n.d(u,"getSyncList",(function(){return wt})),n.d(u,"getSyncDetail",(function(){return xt})),n.d(u,"autoBackup",(function(){return _t})),n.d(u,"manualBackup",(function(){return Ot})),n.d(u,"getV2DataFromV1",(function(){return St}));n(10);var l=n(0),p=n(5);const h=async()=>{try{const t=await p.a.get(l.z+"/city/locate",{lang:l.C.lang},{timeout:1e4});if(t&&t.city)return{data:t.city}}catch(t){return{error:t}}},d=async t=>{try{return{data:(await p.a.get(l.z+"/weather/forecast",{lang:l.C.lang,cid:t},{timeout:1e4})).forecast}}catch(t){return{error:t}}},f=async t=>{try{return{data:await p.a.get(l.z+"/city/list",{lang:l.C.lang,searchkey:t},{timeout:1e4})}}catch(t){return{error:t}}};n(18);var g=n(14),v=n(100),m=n.n(v),y=n(241),b=n.n(y);const w=async t=>l.C.isZh?l.h||l.r?O(t):j(t):l.h||l.r?S(t):k(t),x=async t=>{let e=l.q?36e5:6e4;t||(e=0);try{if(!g.a.requestFirefoxThrottle("/search/list",e,!0))return{error:"request throttle error"};const n=await p.a.get(l.x+"/search/list",{lang:l.C.lang,platform:l.C.platform,platformVersion:l.C.platformVersion,edition:l.e,maybe360:l.E,version:t||""+Date.now()});if(0===n.code){const t=n.data.map(t=>{const e={};return e.name=t.name,e.uuid=t.seId,e.logo=t.logo,e.desc=t.desc,e.types=t.types,e.hide=t.hide,e});return g.a.requestFirefoxThrottle("/search/list",!0,!0),{data:{list:t,hash:m()(JSON.stringify(t)),meta:n.meta}}}if(2005===n.code)return g.a.requestFirefoxThrottle("/search/list",!0,!0),{error:n};throw n}catch(t){return{error:t}}},_=g.a.getLastReqValue(p.a.jsonp),O=async t=>{var e;try{const n=await _(l.b+"/su?ie=utf-8&p=3",{wd:t},{adapter:b.a,callbackParamName:"cb"});return{data:(null===(e=null==n?void 0:n.s)||void 0===e?void 0:e.map(t=>({text:t})))||[]}}catch(t){return{error:t}}},S=async t=>{var e;try{const n=await _(l.g+"/complete/search?client=chrome",{q:t},{adapter:b.a,callbackParamName:"jsonp"});return{data:(null==n?void 0:n.length)&&(null===(e=n[1])||void 0===e?void 0:e.length)?n[1].map(t=>({text:t})):[]}}catch(t){return{error:t}}},j=async t=>{try{const e=await p.a.get(l.b+"/su?p=3&ie=UTF-8&cb=",{wd:t},{_single:!0,_delay:0}),n=/s:(\[[\w\W]*\])/.exec(e),r=JSON.parse(n[1]);return{data:r.map(t=>({text:t}))}}catch(t){return{error:t}}},k=async t=>{try{const e=await p.a.get(l.g+"/complete/search?client=chrome",{q:t},{_single:!0,_delay:200});return{data:e[2].map((t,n)=>(t||(t=e[1][n]),{text:t}))}}catch(t){return{error:t}}};var A=n(190),T=n(7),E=n.n(T),C=n(105),R=n.n(C),I=n(48),P=n.n(I);n(52),n(249),n(13),n(17),n(44);const M=l.C.lang,L=async({page:t=0,type:e,keyword:n,source:r}={})=>{try{const o=await p.a.get(l.w+"/get-icons",{lang:M,page:t,type:e,source:r,keyword:n},{_single:!0,_delay:200});if(o.success)return o.icons.forEach(t=>{if("infinity"===t.source)switch("infinity://wallpaper"===t.url&&(t.name="wallpaper_library"),t.url){case"infinity://wallpaper":case"infinity://weather":case"infinity://todos":case"infinity://notes":case"infinity://history":case"infinity://bookmarks":case"infinity://settings":t.name=i18n(t.name),t.description=i18n(t.description);break;case"infinity://extension":t.name=i18n(t.name),t.description=i18n(t.description,l.C.vendor)}t._footer=t.description||i18n("no_description")}),{data:o};throw o}catch(t){return{error:t}}},N=async t=>{try{const e=await p.a.get(l.x+"/icon/title",{url:t},{_single:!0,_delay:0,timeout:3e3});if(0===e.code)return{data:{name:e.data.title}};throw e}catch(t){return{error:t}}},B=/<title[^>]*>\s*(.*)\s*<\/title>/,D=t=>window.__INFINITY__.hasAllUrlPermission?new E.a(async e=>{let n=0;N(t).then(t=>{n+=1,t.error&&2!==n||e(t)}),(async t=>{try{const e=await p.a.get(t,{},{_single:"getUrlInfoFromFE",timeout:3e3,responseType:"text",_responseAll:!0}),n=e.data;if(n&&e.status>=200&&e.status<300){const t=n.indexOf("<title");if(t>0){const e=n.slice(t,t+200),r=B.exec(e),o=null==r?void 0:r[1];if(o)return{data:{name:o}}}}return{error:"error"}}catch(t){return{error:t}}})(t).then(t=>{n+=1,t.error&&2!==n||e(t)})}):new E.a(async e=>{e(await N(t))}),U=(t,e)=>{if(0===e.length)return e;const n=new Map,r=[];return t.forEach((t,e)=>{n.set(t,e)}),e.forEach(t=>{const e=n.get(t);r[e]=t}),r.filter(t=>!!t)},$=t=>new E.a(e=>{const n=()=>{const e=U(t,i),n=U(t,a),r=U(t,s);return e.concat(n,r)},r=t.length;let o=0;const i=[],a=[],s=[];t.forEach(t=>{const c=new Image;c.onload=function(){o+=1;const{width:c,height:u}=this,l=Math.max(c,u),p=Math.min(c,u);l/p<5?p>50&&l>100?i.push(t):p>50||l>100?a.push(t):s.push(t):s.push(t),o===r&&e(n())},c.onerror=()=>{o+=1,o===r&&e(n())},c.src=t}),setTimeout(()=>{e(n())},3e3)}),z=/\.(ico|png|jpg|jpeg|svg|webp)$/,V=async t=>{var e;try{const n=await p.a.get(t,{},{_single:"getUrlIcon",timeout:3e3,responseType:"text",_responseAll:!0}),r=n.data;if(r&&n.status>=200&&n.status<300){const o=(null===(e=n.request)||void 0===e?void 0:e.responseURL)||t;let i=((t,e)=>{const n=[];return e.replace(/<link [^>]*href=['"]([^'"]+)[^>]*/gi,(t,e)=>{n.push(e)}),R()(n).call(n,(e,n)=>{if(n&&z.test(n)){const r=new P.a(n,t);e.push(r.href)}return e},[])})(o,r);if(i.length<6){const t=((t,e)=>{const n=[];return e.replace(/<img [^>]*src=['"]([^'"]+)[^>]*/gi,(t,e)=>{n.push(e)}),R()(n).call(n,(e,n)=>{if(n&&z.test(n)){const r=new P.a(n,t);e.push(r.href)}return e},[])})(o,r);i=i.concat(t)}i.length>4&&(i.length=4);let a=await $(i);return a=Array.from(new Set(a)),a.length>2&&(a.length=2),{data:a}}return{error:""}}catch(t){return{error:t}}},q=async t=>{try{const{host:e}=new P.a(t),n=await p.a.get(l.x+"/icon/get_icon_urls",{host:e});return 0!==n.code?{error:n}:{data:n.data.map(t=>t.url)}}catch(t){return{error:t}}},F=async t=>{var e;let n=l.q?36e5:6e4;t||(n=0);try{if(!g.a.requestFirefoxThrottle("/icon/rt",n,!0))return{error:"request throttle error"};const r=await p.a.post(l.x+"/icon/rt",{version:t||""+Date.now()});return 0===r.code&&g.a.requestFirefoxThrottle("/icon/rt",!0,!0),0===r.code&&r.data?{data:{list:r.data,version:null===(e=r.meta)||void 0===e?void 0:e.version}}:{error:r}}catch(t){return{error:t}}};function H(t){return t?t.textContent:null}function W(t){return new E.a((e,n)=>{const r=new XMLHttpRequest;r.onreadystatechange=function(){var t,o;if(4==r.readyState)if(r.responseXML){const n=r.responseXML;let i=H(n.querySelector("title"));if(i)try{i=/(\w+)@(\w+\.\w+)/.exec(i)[0]}catch(t){}const a=parseInt(H(n.querySelector("fullcount")),10),s=n.querySelectorAll("entry"),c=[];let u=-1;for(let e=0,n=s.length;e<n;e++){const n=s[e],r={id:H(n.querySelector("id")),issued:H(n.querySelector("issued")),title:H(n.querySelector("title")),summary:H(n.querySelector("summary")),link:(t=n.querySelector("link"),o="href",t?t.getAttribute(o):null),authorName:H(n.querySelector("author name")),authorEmail:H(n.querySelector("author email"))};r.issued&&(r.issued=new Date(r.issued).valueOf(),u=Math.max(u,r.issued)),c.push(r)}e({account:i,lastIssuedTime:u,count:a,emails:c})}else n()},r.onerror=n,r.open("GET",function(t){return l.f+"/mail/feed/atom?zx="+encodeURIComponent(t)}(t),!0),r.send(null)})}var G=n(107),X=n.n(G),Y=n(22);const K=async({email:t,password:e,repeatPassword:n,code:r})=>{const o={email:X()(t).call(t),password:m()(e),repeatPassword:m()(n),code:X()(r).call(r)};try{return await p.a.post(l.x+"/user/register",o)}catch(t){return t}},J=async({email:t,password:e})=>{const n={email:X()(t).call(t),password:m()(e)};try{return await p.a.post(l.x+"/user/login",n)}catch(t){return t}};async function Q(t){const e=(await Object(Y.b)("store-user")).userInfo.uid;try{return await p.a.post(l.x+"/user/update_profile/"+e,t,{_auth:!0})}catch(t){throw new Error(t.message)}}async function Z(){try{return await p.a.get(l.x+"/user/get_user_profile",{},{_auth:!0,_proxy:!0})}catch(t){return t}}async function tt(t){const e=new FormData;e.append("file",t);try{const t=await p.a.post(l.x+"/upload/avatar",e,{_auth:!0,headers:{"Content-Type":"multipart/form-data"}});if(0===(null==t?void 0:t.code))return t;throw new Error(i18n("upload_avatar_failure"))}catch(t){throw new Error(t)}}async function et({originPassword:t,newPassword:e}){const n=await Object(Y.b)("store-user"),r=n.userInfo.uid,{token:o}=n;if(!o)throw new Error(i18n("unknown_mistake"));const i={originPassword:m()(t),newPassword:m()(e)};try{return await p.a.post(l.x+"/user/modify_password/"+r,i,{_auth:!0})}catch(t){return t}}async function nt(t){try{return await p.a.post(l.x+"/user/forget_password",t)}catch(t){return t}}async function rt({password:t,repeatPassword:e,email:n,code:r}){const o={password:m()(t),repeatPassword:m()(e),email:X()(n).call(n),code:X()(r).call(r)};try{return await p.a.post(l.x+"/user/reset_password",o)}catch(t){return t}}async function ot(t){try{return await p.a.post(`${l.x}/get_code?lang=${l.C.lang}`,t)}catch(t){return t}}async function it(t){try{return await p.a.post(`${l.x}/get_register_code?lang=${l.C.lang}`,t)}catch(t){return t}}async function at(t){try{return await p.a.post(l.x+"/inspce_code",t)}catch(t){return t}}async function st(){try{return await p.a.get(l.x+"/check_token",{},{_auth:!0})}catch(t){return t}}async function ct(){const t=(await Object(Y.b)("store-user")).userInfo.uid;try{return await p.a.post(l.x+"/user/delete/"+t,{},{_auth:!0})}catch(t){return t}}const ut=async t=>{try{return await p.a.post(l.x+"/user/login_uid",t,{timeout:1e4})}catch(t){return t}},lt=async t=>{try{return await p.a.post(l.x+"/user/v1_basic_login",t,{timeout:1e4})}catch(t){return t}},pt=async(t,e)=>{try{return await p.a.get(`${l.x}/user/user_hash?uid=${t}&secret=${e}`)}catch(t){return t}},ht=async()=>{try{const t=await p.a.get(l.x+"/login_code/mobile_code",{},{_auth:!0});return 0===t.code?{data:t.data}:{error:t}}catch(t){return{error:t}}},dt=async(t,e)=>{try{const n=await p.a.post(l.x+"/login_code/check",{code:t,type:e},{_auth:!0});return 0===n.code?{data:n.data}:{error:n}}catch(t){return{error:t}}},ft=async()=>{try{const t=await p.a.get(l.x+"/get_concat_info");if(0===t.code)return{data:t.data};throw t}catch(t){return{error:t}}},gt=async(t,e)=>{try{const{response:n,stack:r,config:o}=e;let i=n||o;i&&(i=JSON.stringify(i,(t,e)=>{if(e instanceof FormData){const t={};for(const[n,r]of e)t[n]=r;return t}if(e instanceof File){return{lastModified:e.lastModified,name:e.name,size:e.size,type:e.type}}return e}));let a=await Object(Y.b)("store-user");if(a){const t=["mobileuid","avatar","refreshToken","secret","gender","name"];a=JSON.stringify(a,(e,n)=>{if(!t.includes(e))return n})}const s=await p.a.post(l.x+"/collect",{type:t,user:a,stack:r,info:i,env:Object.assign({},l.C)});if(0===s.code)return{data:s.data};throw s}catch(t){return{error:t}}},vt=async t=>{await p.a.get(t,void 0,{_proxy:!0,_proxyIgnoreRes:!0})},mt=t=>{const e=JSON.stringify(t),n=(new TextEncoder).encode(e);return new Blob([n],{type:"application/json;charset=utf-8"})},yt=t=>{const e={};return t.forEach(t=>{const{platform:n}=t;e[n]?e[n].push(t):e[n]=[t]}),e},bt=t=>{const{_id:e,_platform:n="pc"}=t;return{id:e,time:g.a.fmtTime(Number(e)),platform:n}},wt=async()=>{try{const t=await p.a.get(l.x+"/sync/list",void 0,{_auth:!0,_proxy:!0});if(0!==t.code)return{error:t};const e={};return e.auto=t.meta.auto.map(bt),e.manual=yt(t.meta.manual.map(bt)),{data:e}}catch(t){return{error:t}}},xt=async(t,e,n="all")=>{try{const r=await p.a.get(l.x+"/sync/download_url",{id:t,type:e,keys:n},{_auth:!0});if(0!==r.code)return{error:r};const o=r.data;let i={};const a=await E.a.all(o.map(e=>p.a.get(e.url+"&timestampid="+("latest"===t?Date.now():t),{},{timeout:18e4})));return o.forEach((t,n)=>{const r=t.fileKey;"manual"===e?i=Object.assign(Object.assign({},i),a[n]):"auto"===e&&(i[r]=a[n])}),{data:i}}catch(t){return gt("getSyncDetail",t),{error:t}}},_t=async(t,e="")=>{const n=Object.keys(t).join(",");try{const r=await p.a.get(l.x+"/sync/token",{type:"auto",keys:n},{_auth:!0});if(0!==r.code||!r.data.length)return{error:r};const o=r.data;await E.a.all(o.map(e=>{const{url:n,key:r,token:o,host:i}=e,a=new FormData;return a.append("token",o),a.append("key",n),a.append("file",mt(t[r])),p.a.post(i,a,{headers:{"Content-Type":"multipart/form-data"},timeout:18e4})})),localStorage.setItem("pre-sync-id",o[0].timestamp+"");const i=await p.a.post(l.x+"/sync/done",{type:"auto",websocketkeys:e,keys:n,record_time:o[0].timestamp},{_auth:!0});return 0!==i.code?{error:i}:{data:i.meta.map(bt)}}catch(t){return gt("autoBackup",t),{error:t}}},Ot=async t=>{try{const e=await p.a.get(l.x+"/sync/token",{type:"manual",keys:"data"},{_auth:!0});if(0!==e.code||!e.data.length)return{error:e};const{token:n,url:r,timestamp:o,host:i}=e.data[0],a=new FormData;a.append("token",n),a.append("key",r),a.append("file",mt(t)),await p.a.post(i,a,{headers:{"Content-Type":"multipart/form-data"},timeout:18e4});const s=await p.a.post(l.x+"/sync/done",{type:"manual",keys:"data",record_time:o},{_auth:!0});return 0!==s.code?{error:s}:{data:yt(s.meta.map(bt))}}catch(t){return gt("manualBackup",t),{error:t}}},St=t=>"pro"===t?async function(){try{const{userInfo:t={}}=await Object(Y.b)("store-user"),{uid:e,secret:n}=t,r=await p.a.get(l.w+"/user/recovery-pro",{uid:e,secret:n},{timeout:2e5});if(r.success)return{data:r.data};throw r}catch(t){return gt("getProV1Data",t),{error:t}}}():"basic"===t?async function(){try{const t=await p.a.get(l.x+"/sync/recover_basic",{},{_auth:!0,timeout:2e5});return 0!==t.code?{error:t}:{data:t.data}}catch(t){return gt("getBasicV1Data",t),{error:t}}}():void 0;var jt=n(257)},function(t,e,n){var r=n(99),o=n(68);t.exports=function(t){return r(o(t))}},function(t,e,n){var r=n(70),o=n(12),i=function(t){return"function"==typeof t?t:void 0};t.exports=function(t,e){return arguments.length<2?i(r[t])||i(o[t]):r[t]&&r[t][e]||o[t]&&o[t][e]}},function(t,e){var n={}.toString;t.exports=function(t){return n.call(t).slice(8,-1)}},function(t,e,n){var r=n(16);t.exports=function(t,e){if(!r(t))return t;var n,o;if(e&&"function"==typeof(n=t.toString)&&!r(o=n.call(t)))return o;if("function"==typeof(n=t.valueOf)&&!r(o=n.call(t)))return o;if(!e&&"function"==typeof(n=t.toString)&&!r(o=n.call(t)))return o;throw TypeError("Can't convert object to primitive value")}},function(t,e,n){var r=n(20),o=n(8),i=n(55);t.exports=!r&&!o((function(){return 7!=Object.defineProperty(i("div"),"a",{get:function(){return 7}}).a}))},function(t,e,n){var r=n(11),o=n(42),i=n(139).indexOf,a=n(61);t.exports=function(t,e){var n,s=o(t),c=0,u=[];for(n in s)!r(a,n)&&r(s,n)&&u.push(n);for(;e.length>c;)r(s,n=e[c++])&&(~i(u,n)||u.push(n));return u}},function(t,e,n){var r=n(77),o=n(8);t.exports=!!Object.getOwnPropertySymbols&&!o((function(){var t=Symbol();return!String(t)||!(Object(t)instanceof Symbol)||!Symbol.sham&&r&&r<41}))},function(t,e,n){var r,o,i,a=n(4),s=n(8),c=n(74),u=n(90),l=n(55),p=n(91),h=n(64),d=a.location,f=a.setImmediate,g=a.clearImmediate,v=a.process,m=a.MessageChannel,y=a.Dispatch,b=0,w={},x=function(t){if(w.hasOwnProperty(t)){var e=w[t];delete w[t],e()}},_=function(t){return function(){x(t)}},O=function(t){x(t.data)},S=function(t){a.postMessage(t+"",d.protocol+"//"+d.host)};f&&g||(f=function(t){for(var e=[],n=1;arguments.length>n;)e.push(arguments[n++]);return w[++b]=function(){("function"==typeof t?t:Function(t)).apply(void 0,e)},r(b),b},g=function(t){delete w[t]},h?r=function(t){v.nextTick(_(t))}:y&&y.now?r=function(t){y.now(_(t))}:m&&!p?(i=(o=new m).port2,o.port1.onmessage=O,r=c(i.postMessage,i,1)):a.addEventListener&&"function"==typeof postMessage&&!a.importScripts&&d&&"file:"!==d.protocol&&!s(S)?(r=S,a.addEventListener("message",O,!1)):r="onreadystatechange"in l("script")?function(t){u.appendChild(l("script")).onreadystatechange=function(){u.removeChild(this),x(t)}}:function(t){setTimeout(_(t),0)}),t.exports={set:f,clear:g}},function(t,e,n){var r=n(31);t.exports=r("document","documentElement")},function(t,e,n){var r=n(40);t.exports=/(?:iphone|ipod|ipad).*applewebkit/i.test(r)},function(t,e,n){"use strict";var r=n(37),o=function(t){var e,n;this.promise=new t((function(t,r){if(void 0!==e||void 0!==n)throw TypeError("Bad Promise constructor");e=t,n=r})),this.resolve=r(e),this.reject=r(n)};t.exports.f=function(t){return new o(t)}},function(t,e,n){"use strict";var r,o,i,a=n(8),s=n(78),c=n(15),u=n(11),l=n(6),p=n(41),h=l("iterator"),d=!1;[].keys&&("next"in(i=[].keys())?(o=s(s(i)))!==Object.prototype&&(r=o):d=!0);var f=null==r||a((function(){var t={};return r[h].call(t)!==t}));f&&(r={}),p&&!f||u(r,h)||c(r,h,(function(){return this})),t.exports={IteratorPrototype:r,BUGGY_SAFARI_ITERATORS:d}},function(t,e,n){n(27)({global:!0},{globalThis:n(12)})},function(t,e,n){var r=n(25),o=n(19),i=n(98);t.exports=!r&&!o((function(){return 7!=Object.defineProperty(i("div"),"a",{get:function(){return 7}}).a}))},function(t,e){t.exports=!0},function(t,e,n){"use strict";n.d(e,"a",(function(){return s}));var r=n(7),o=n.n(r),i=(n(13),n(17),n(0));const a={};const s=new class{constructor(){this.request=(t,e)=>((i.n||i.k||i.h)&&e&&e.includes("chrome://favicon/")&&(e=Array.from(new Set(e))).splice(e.findIndex(t=>"chrome://favicon/"===t),1),new o.a((n,r)=>{if(i.r)return void r();let o="";if(i.n){if(o=t.join(",")+(null==e?void 0:e.join(",")),a[o])return void r(new Error("repeat"));a[o]=!0}chrome.permissions.request({permissions:t,origins:e},t=>{i.n&&a[o]&&delete a[o],chrome.runtime.lastError?r(chrome.runtime.lastError):t?n(!0):r(new Error("REJECT"))})})),this.has=(t,e)=>new o.a(n=>{i.r?n(!1):chrome.permissions.contains({permissions:t,origins:e},t=>{n(t)})})}}},function(t,e,n){var r=n(12),o=n(30),i=r.document,a=o(i)&&o(i.createElement);t.exports=function(t){return a?i.createElement(t):{}}},function(t,e,n){var r=n(19),o=n(84),i="".split;t.exports=r((function(){return!Object("z").propertyIsEnumerable(0)}))?function(t){return"String"==o(t)?i.call(t,""):Object(t)}:Object},function(t,e,n){var r,o,i,a,s;r=n(361),o=n(258).utf8,i=n(362),a=n(258).bin,(s=function(t,e){t.constructor==String?t=e&&"binary"===e.encoding?a.stringToBytes(t):o.stringToBytes(t):i(t)?t=Array.prototype.slice.call(t,0):Array.isArray(t)||t.constructor===Uint8Array||(t=t.toString());for(var n=r.bytesToWords(t),c=8*t.length,u=1732584193,l=-271733879,p=-1732584194,h=271733878,d=0;d<n.length;d++)n[d]=16711935&(n[d]<<8|n[d]>>>24)|4278255360&(n[d]<<24|n[d]>>>8);n[c>>>5]|=128<<c%32,n[14+(c+64>>>9<<4)]=c;var f=s._ff,g=s._gg,v=s._hh,m=s._ii;for(d=0;d<n.length;d+=16){var y=u,b=l,w=p,x=h;u=f(u,l,p,h,n[d+0],7,-680876936),h=f(h,u,l,p,n[d+1],12,-389564586),p=f(p,h,u,l,n[d+2],17,606105819),l=f(l,p,h,u,n[d+3],22,-1044525330),u=f(u,l,p,h,n[d+4],7,-176418897),h=f(h,u,l,p,n[d+5],12,1200080426),p=f(p,h,u,l,n[d+6],17,-1473231341),l=f(l,p,h,u,n[d+7],22,-45705983),u=f(u,l,p,h,n[d+8],7,1770035416),h=f(h,u,l,p,n[d+9],12,-1958414417),p=f(p,h,u,l,n[d+10],17,-42063),l=f(l,p,h,u,n[d+11],22,-1990404162),u=f(u,l,p,h,n[d+12],7,1804603682),h=f(h,u,l,p,n[d+13],12,-40341101),p=f(p,h,u,l,n[d+14],17,-1502002290),u=g(u,l=f(l,p,h,u,n[d+15],22,1236535329),p,h,n[d+1],5,-165796510),h=g(h,u,l,p,n[d+6],9,-1069501632),p=g(p,h,u,l,n[d+11],14,643717713),l=g(l,p,h,u,n[d+0],20,-373897302),u=g(u,l,p,h,n[d+5],5,-701558691),h=g(h,u,l,p,n[d+10],9,38016083),p=g(p,h,u,l,n[d+15],14,-660478335),l=g(l,p,h,u,n[d+4],20,-405537848),u=g(u,l,p,h,n[d+9],5,568446438),h=g(h,u,l,p,n[d+14],9,-1019803690),p=g(p,h,u,l,n[d+3],14,-187363961),l=g(l,p,h,u,n[d+8],20,1163531501),u=g(u,l,p,h,n[d+13],5,-1444681467),h=g(h,u,l,p,n[d+2],9,-51403784),p=g(p,h,u,l,n[d+7],14,1735328473),u=v(u,l=g(l,p,h,u,n[d+12],20,-1926607734),p,h,n[d+5],4,-378558),h=v(h,u,l,p,n[d+8],11,-2022574463),p=v(p,h,u,l,n[d+11],16,1839030562),l=v(l,p,h,u,n[d+14],23,-35309556),u=v(u,l,p,h,n[d+1],4,-1530992060),h=v(h,u,l,p,n[d+4],11,1272893353),p=v(p,h,u,l,n[d+7],16,-155497632),l=v(l,p,h,u,n[d+10],23,-1094730640),u=v(u,l,p,h,n[d+13],4,681279174),h=v(h,u,l,p,n[d+0],11,-358537222),p=v(p,h,u,l,n[d+3],16,-722521979),l=v(l,p,h,u,n[d+6],23,76029189),u=v(u,l,p,h,n[d+9],4,-640364487),h=v(h,u,l,p,n[d+12],11,-421815835),p=v(p,h,u,l,n[d+15],16,530742520),u=m(u,l=v(l,p,h,u,n[d+2],23,-995338651),p,h,n[d+0],6,-198630844),h=m(h,u,l,p,n[d+7],10,1126891415),p=m(p,h,u,l,n[d+14],15,-1416354905),l=m(l,p,h,u,n[d+5],21,-57434055),u=m(u,l,p,h,n[d+12],6,1700485571),h=m(h,u,l,p,n[d+3],10,-1894986606),p=m(p,h,u,l,n[d+10],15,-1051523),l=m(l,p,h,u,n[d+1],21,-2054922799),u=m(u,l,p,h,n[d+8],6,1873313359),h=m(h,u,l,p,n[d+15],10,-30611744),p=m(p,h,u,l,n[d+6],15,-1560198380),l=m(l,p,h,u,n[d+13],21,1309151649),u=m(u,l,p,h,n[d+4],6,-145523070),h=m(h,u,l,p,n[d+11],10,-1120210379),p=m(p,h,u,l,n[d+2],15,718787259),l=m(l,p,h,u,n[d+9],21,-343485551),u=u+y>>>0,l=l+b>>>0,p=p+w>>>0,h=h+x>>>0}return r.endian([u,l,p,h])})._ff=function(t,e,n,r,o,i,a){var s=t+(e&n|~e&r)+(o>>>0)+a;return(s<<i|s>>>32-i)+e},s._gg=function(t,e,n,r,o,i,a){var s=t+(e&r|n&~r)+(o>>>0)+a;return(s<<i|s>>>32-i)+e},s._hh=function(t,e,n,r,o,i,a){var s=t+(e^n^r)+(o>>>0)+a;return(s<<i|s>>>32-i)+e},s._ii=function(t,e,n,r,o,i,a){var s=t+(n^(e|~r))+(o>>>0)+a;return(s<<i|s>>>32-i)+e},s._blocksize=16,s._digestsize=16,t.exports=function(t,e){if(null==t)throw new Error("Illegal argument "+t);var n=r.wordsToBytes(s(t,e));return e&&e.asBytes?n:e&&e.asString?a.bytesToString(n):r.bytesToHex(n)}},function(t,e){t.exports={}},function(t,e,n){var r=n(39);t.exports=function(t,e,n,o){o&&o.enumerable?t[e]=n:r(t,e,n)}},function(t,e,n){"use strict";n.d(e,"h",(function(){return u})),n.d(e,"a",(function(){return p})),n.d(e,"b",(function(){return h})),n.d(e,"e",(function(){return d})),n.d(e,"c",(function(){return f})),n.d(e,"f",(function(){return g})),n.d(e,"g",(function(){return v})),n.d(e,"d",(function(){return y}));var r=n(200),o=n(174),i=n(125),a=n(244),s=n(237),c=n(80);
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const u=t=>null===t||!("object"==typeof t||"function"==typeof t),l=t=>Array.isArray(t)||!(!t||!t[Symbol.iterator]);class p{constructor(t,e,n){this.dirty=!0,this.element=t,this.name=e,this.strings=n,this.parts=[];for(let t=0;t<n.length-1;t++)this.parts[t]=this._createPart()}_createPart(){return new h(this)}_getValue(){const t=this.strings,e=t.length-1,n=this.parts;if(1===e&&""===t[0]&&""===t[1]){const t=n[0].value;if("symbol"==typeof t)return String(t);if("string"==typeof t||!l(t))return t}let r="";for(let o=0;o<e;o++){r+=t[o];const e=n[o];if(void 0!==e){const t=e.value;if(u(t)||!l(t))r+="string"==typeof t?t:String(t);else for(const e of t)r+="string"==typeof e?e:String(e)}}return r+=t[e],r}commit(){this.dirty&&(this.dirty=!1,this.element.setAttribute(this.name,this._getValue()))}}class h{constructor(t){this.value=void 0,this.committer=t}setValue(t){t===i.a||u(t)&&t===this.value||(this.value=t,Object(r.b)(t)||(this.committer.dirty=!0))}commit(){for(;Object(r.b)(this.value);){const t=this.value;this.value=i.a,t(this)}this.value!==i.a&&this.committer.commit()}}class d{constructor(t){this.value=void 0,this.__pendingValue=void 0,this.options=t}appendInto(t){this.startNode=t.appendChild(Object(c.c)()),this.endNode=t.appendChild(Object(c.c)())}insertAfterNode(t){this.startNode=t,this.endNode=t.nextSibling}appendIntoPart(t){t.__insert(this.startNode=Object(c.c)()),t.__insert(this.endNode=Object(c.c)())}insertAfterPart(t){t.__insert(this.startNode=Object(c.c)()),this.endNode=t.endNode,t.endNode=this.startNode}setValue(t){this.__pendingValue=t}commit(){if(null===this.startNode.parentNode)return;for(;Object(r.b)(this.__pendingValue);){const t=this.__pendingValue;this.__pendingValue=i.a,t(this)}const t=this.__pendingValue;t!==i.a&&(u(t)?t!==this.value&&this.__commitText(t):t instanceof s.b?this.__commitTemplateResult(t):t instanceof Node?this.__commitNode(t):l(t)?this.__commitIterable(t):t===i.b?(this.value=i.b,this.clear()):this.__commitText(t))}__insert(t){this.endNode.parentNode.insertBefore(t,this.endNode)}__commitNode(t){this.value!==t&&(this.clear(),this.__insert(t),this.value=t)}__commitText(t){const e=this.startNode.nextSibling,n="string"==typeof(t=null==t?"":t)?t:String(t);e===this.endNode.previousSibling&&3===e.nodeType?e.data=n:this.__commitNode(document.createTextNode(n)),this.value=t}__commitTemplateResult(t){const e=this.options.templateFactory(t);if(this.value instanceof a.a&&this.value.template===e)this.value.update(t.values);else{const n=new a.a(e,t.processor,this.options),r=n._clone();n.update(t.values),this.__commitNode(r),this.value=n}}__commitIterable(t){Array.isArray(this.value)||(this.value=[],this.clear());const e=this.value;let n,r=0;for(const o of t)n=e[r],void 0===n&&(n=new d(this.options),e.push(n),0===r?n.appendIntoPart(this):n.insertAfterPart(e[r-1])),n.setValue(o),n.commit(),r++;r<e.length&&(e.length=r,this.clear(n&&n.endNode))}clear(t=this.startNode){Object(o.b)(this.startNode.parentNode,t.nextSibling,this.endNode)}}class f{constructor(t,e,n){if(this.value=void 0,this.__pendingValue=void 0,2!==n.length||""!==n[0]||""!==n[1])throw new Error("Boolean attributes can only contain a single expression");this.element=t,this.name=e,this.strings=n}setValue(t){this.__pendingValue=t}commit(){for(;Object(r.b)(this.__pendingValue);){const t=this.__pendingValue;this.__pendingValue=i.a,t(this)}if(this.__pendingValue===i.a)return;const t=!!this.__pendingValue;this.value!==t&&(t?this.element.setAttribute(this.name,""):this.element.removeAttribute(this.name),this.value=t),this.__pendingValue=i.a}}class g extends p{constructor(t,e,n){super(t,e,n),this.single=2===n.length&&""===n[0]&&""===n[1]}_createPart(){return new v(this)}_getValue(){return this.single?this.parts[0].value:super._getValue()}commit(){this.dirty&&(this.dirty=!1,this.element[this.name]=this._getValue())}}class v extends h{}let m=!1;(()=>{try{const t={get capture(){return m=!0,!1}};window.addEventListener("test",t,t),window.removeEventListener("test",t,t)}catch(t){}})();class y{constructor(t,e,n){this.value=void 0,this.__pendingValue=void 0,this.element=t,this.eventName=e,this.eventContext=n,this.__boundHandleEvent=t=>this.handleEvent(t)}setValue(t){this.__pendingValue=t}commit(){for(;Object(r.b)(this.__pendingValue);){const t=this.__pendingValue;this.__pendingValue=i.a,t(this)}if(this.__pendingValue===i.a)return;const t=this.__pendingValue,e=this.value,n=null==t||null!=e&&(t.capture!==e.capture||t.once!==e.once||t.passive!==e.passive),o=null!=t&&(null==e||n);n&&this.element.removeEventListener(this.eventName,this.__boundHandleEvent,this.__options),o&&(this.__options=b(t),this.element.addEventListener(this.eventName,this.__boundHandleEvent,this.__options)),this.value=t,this.__pendingValue=i.a}handleEvent(t){"function"==typeof this.value?this.value.call(this.eventContext||this.element,t):this.value.handleEvent(t)}}const b=t=>t&&(m?{capture:t.capture,passive:t.passive,once:t.once}:t.capture)},function(t,e,n){var r,o,i,a=n(283),s=n(12),c=n(30),u=n(39),l=n(29),p=n(182),h=n(181),d=n(185),f=s.WeakMap;if(a||p.state){var g=p.state||(p.state=new f),v=g.get,m=g.has,y=g.set;r=function(t,e){if(m.call(g,t))throw new TypeError("Object already initialized");return e.facade=t,y.call(g,t,e),e},o=function(t){return v.call(g,t)||{}},i=function(t){return m.call(g,t)}}else{var b=h("state");d[b]=!0,r=function(t,e){if(l(t,b))throw new TypeError("Object already initialized");return e.facade=t,u(t,b,e),e},o=function(t){return l(t,b)?t[b]:{}},i=function(t){return l(t,b)}}t.exports={set:r,get:o,has:i,enforce:function(t){return i(t)?o(t):r(t,{})},getterFor:function(t){return function(e){var n;if(!c(e)||(n=o(e)).type!==t)throw TypeError("Incompatible receiver, "+t+" required");return n}}}},function(t,e,n){t.exports=n(331)},function(t,e,n){t.exports=n(292)},function(t,e,n){t.exports=n(335)},function(t,e,n){var r=n(8),o=n(34),i="".split;t.exports=r((function(){return!Object("z").propertyIsEnumerable(0)}))?function(t){return"String"==o(t)?i.call(t,""):Object(t)}:Object},function(t,e){t.exports={CSSRuleList:0,CSSStyleDeclaration:0,CSSValueList:0,ClientRectList:0,DOMRectList:0,DOMStringList:0,DOMTokenList:1,DataTransferItemList:0,FileList:0,HTMLAllCollection:0,HTMLCollection:0,HTMLFormElement:0,HTMLSelectElement:0,MediaList:0,MimeTypeArray:0,NamedNodeMap:0,NodeList:1,PaintRequestList:0,Plugin:0,PluginArray:0,SVGLengthList:0,SVGNumberList:0,SVGPathSegList:0,SVGPointList:0,SVGStringList:0,SVGTransformList:0,SourceBufferList:0,StyleSheetList:0,TextTrackCueList:0,TextTrackList:0,TouchList:0}},function(t,e,n){var r=n(25),o=n(119),i=n(47),a=n(82),s=n(79),c=n(29),u=n(95),l=Object.getOwnPropertyDescriptor;e.f=r?l:function(t,e){if(t=a(t),e=s(e,!0),u)try{return l(t,e)}catch(t){}if(c(t,e))return i(!o.f.call(t,e),t[e])}},function(t,e,n){var r=n(19),o=/#|\.prototype\./,i=function(t,e){var n=s[a(t)];return n==u||n!=c&&("function"==typeof e?r(e):!!e)},a=i.normalize=function(t){return String(t).replace(o,".").toLowerCase()},s=i.data={},c=i.NATIVE="N",u=i.POLYFILL="P";t.exports=i},function(t,e,n){var r=n(87),o=n(62).concat("length","prototype");e.f=Object.getOwnPropertyNames||function(t){return r(t,o)}},function(t,e,n){"use strict";var r=n(31),o=n(21),i=n(6),a=n(20),s=i("species");t.exports=function(t){var e=r(t),n=o.f;a&&e&&!e[s]&&n(e,s,{configurable:!0,get:function(){return this}})}},function(t,e,n){var r=n(149),o=n(34),i=n(6)("toStringTag"),a="Arguments"==o(function(){return arguments}());t.exports=r?o:function(t){var e,n,r;return void 0===t?"Undefined":null===t?"Null":"string"==typeof(n=function(t,e){try{return t[e]}catch(t){}}(e=Object(t),i))?n:a?o(e):"Object"==(r=o(e))&&"function"==typeof e.callee?"Arguments":r}},function(t,e,n){"use strict";var r=n(9);t.exports=function(){var t=r(this),e="";return t.global&&(e+="g"),t.ignoreCase&&(e+="i"),t.multiline&&(e+="m"),t.dotAll&&(e+="s"),t.unicode&&(e+="u"),t.sticky&&(e+="y"),e}},function(t,e,n){var r=n(8),o=function(t,e){return RegExp(t,e)};e.UNSUPPORTED_Y=r((function(){var t=o("a","y");return t.lastIndex=2,null!=t.exec("abcd")})),e.BROKEN_CARET=r((function(){var t=o("^r","gy");return t.lastIndex=2,null!=t.exec("str")}))},function(t,e,n){var r=n(8);t.exports=r((function(){var t=RegExp(".","string".charAt(0));return!(t.dotAll&&t.exec("\n")&&"s"===t.flags)}))},function(t,e,n){var r=n(8);t.exports=r((function(){var t=RegExp("(?<a>b)","string".charAt(5));return"b"!==t.exec("b").groups.a||"bc"!=="b".replace(t,"$<a>c")}))},function(t,e,n){"use strict";var r={}.propertyIsEnumerable,o=Object.getOwnPropertyDescriptor,i=o&&!r.call({1:2},1);e.f=i?function(t){var e=o(this,t);return!!e&&e.enumerable}:r},function(t,e,n){"use strict";var r=n(49),o=function(t){var e,n;this.promise=new t((function(t,r){if(void 0!==e||void 0!==n)throw TypeError("Bad Promise constructor");e=t,n=r})),this.resolve=r(e),this.reject=r(n)};t.exports.f=function(t){return new o(t)}},function(t,e,n){var r=n(186),o=n(71).f,i=n(39),a=n(29),s=n(277),c=n(33)("toStringTag");t.exports=function(t,e,n,u){if(t){var l=n?t:t.prototype;a(l,c)||o(l,c,{configurable:!0,value:e}),u&&!r&&i(l,"toString",s)}}},function(t,e,n){"use strict";n.r(e),n.d(e,"iMessage",(function(){return p})),n.d(e,"message",(function(){return h}));n(13),n(17);var r=n(358),o=n(1),i=n(344),a=n(393),s=n.n(a),c=n(394),u=n.n(c),l=function(t,e,n,r){var o,i=arguments.length,a=i<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(t,e,n,r);else for(var s=t.length-1;s>=0;s--)(o=t[s])&&(a=(i<3?o(a):i>3?o(e,n,a):o(e,n))||a);return i>3&&a&&Object.defineProperty(e,n,a),a};let p=class extends o.a{constructor(){super(...arguments),this.content="",this.type="error"}render(){const t={"infinity-message":!0,"position-top":"top"===this.type};return o.e`
      <div class=${Object(i.a)(t)}>
        ${this.renderImg()}
        <span>${this.content}</span>
      </div>
    `}renderImg(){return"error"===this.type?o.e`<img .src=${s.a} />`:"warn"===this.type?o.e`<img .src=${u.a} />`:void 0}};p.styles=o.b`
    :host {
      box-sizing: border-box;
      display: flex;
      position: fixed;
      min-width: 330px;
      padding: 0 20px;
      height: 60px;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: rgba(255, 255, 255, 1);
      box-shadow: 0px 6px 48px 0px rgba(0, 0, 0, 0.24);
      border-radius: 6px;
      z-index: 99999999999;
    }
    :host([type='top']) {
      width: 100%;
      margin: 0;
      left: 0;
      top: var(--top-bar-height);
      height: auto;
      padding: 5px;
      border-radius: 0;
      background: rgba(95, 92, 92, 0.6);
      color: #fff;
      transform: none;
      transition: all 300ms;
      opacity: 0;
      pointer-events: none;
    }
    :host(.anim[type='top']) {
      opacity: 1;
    }

    .infinity-message {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 100%;
    }
    img {
      width: 20px;
      height: 20px;
      margin-right: 8px;
    }
  `,l([Object(o.g)({type:String})],p.prototype,"content",void 0),l([Object(o.g)({type:String})],p.prototype,"type",void 0),p=l([Object(o.c)("i-message")],p);const h={newInstance:function(t,e=2,n,r){let o;if(document.querySelector("i-message"))return void clearInterval(o);const i=document.createElement("i-message");return i.setAttribute("content",t),i.setAttribute("type",n),document.body.appendChild(i),0!==e&&(o=setTimeout(()=>{document.body.removeChild(i),r&&r()},1e3*e)),i},error:function(t,e,n){r.default.error(t,e),n&&setTimeout(n,e)},success:function(t,e,n){r.default.success(t,e),n&&setTimeout(n,e)},top:function(t,e,n){const r=this.newInstance(t,e,"top",n);setTimeout(()=>null==r?void 0:r.classList.add("anim"))},warn:function(t,e,n){this.newInstance(t,e,"warn",n)}}},function(t,e,n){"use strict";n.d(e,"b",(function(){return r})),n.d(e,"a",(function(){return o})),n.d(e,"d",(function(){return i})),n.d(e,"c",(function(){return a}));n(18);const r=n(0).r?"serviceworker":"background";let o=!1;"background"===r?o="undefined"==typeof ServiceWorkerGlobalScope&&chrome.extension.getBackgroundPage()===window:"serviceworker"===r&&(o="undefined"!=typeof ServiceWorkerGlobalScope);const i={timeout:0,taskId:""},a=()=>(""+Date.now()/1e3/1e5).split(".")[1].substr(0,8)+(""+Math.random()).split(".")[1].substr(0,8).padEnd(8,"0")},function(t,e,n){var r=n(11),o=n(137),i=n(53),a=n(21);t.exports=function(t,e){for(var n=o(e),s=a.f,c=i.f,u=0;u<n.length;u++){var l=n[u];r(t,l)||s(t,l,c(e,l))}}},function(t,e,n){"use strict";n.d(e,"a",(function(){return r})),n.d(e,"b",(function(){return o}));
/**
 * @license
 * Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const r={},o={}},function(t,e,n){var r=n(186),o=n(84),i=n(33)("toStringTag"),a="Arguments"==o(function(){return arguments}());t.exports=r?o:function(t){var e,n,r;return void 0===t?"Undefined":null===t?"Null":"string"==typeof(n=function(t,e){try{return t[e]}catch(t){}}(e=Object(t),i))?n:a?o(e):"Object"==(r=o(e))&&"function"==typeof e.callee?"Arguments":r}},function(t,e,n){"use strict";n.d(e,"e",(function(){return a.a})),n.d(e,"g",(function(){return s.c})),n.d(e,"a",(function(){return r.b})),n.d(e,"b",(function(){return r.e})),n.d(e,"c",(function(){return r.g})),n.d(e,"d",(function(){return i.b})),n.d(e,"f",(function(){return c}));var r=n(103);
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */const o=new class{handleAttributeExpressions(t,e,n,o){const i=e[0];if("."===i){return new r.f(t,e.slice(1),n).parts}if("@"===i)return[new r.d(t,e.slice(1),o.eventContext)];if("?"===i)return[new r.c(t,e.slice(1),n)];return new r.a(t,e,n).parts}handleTextExpression(t){return new r.e(t)}};var i=n(237),a=n(200),s=n(174);n(125),n(199),n(198),n(244),n(80);
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
"undefined"!=typeof window&&(window.litHtmlVersions||(window.litHtmlVersions=[])).push("1.4.1");const c=(t,...e)=>new i.b(t,e,"html",o)},function(t,e,n){var r=n(184),o=Math.min;t.exports=function(t){return t>0?o(r(t),9007199254740991):0}},function(t,e,n){var r=n(84),o=n(12);t.exports="process"==r(o.process)},function(t,e,n){"use strict";n.d(e,"b",(function(){return o})),n.d(e,"a",(function(){return i}));var r=n(188);const o={notice:{gmail:!1,gmailVoice:!1,gmailNumber:!1,todoNumber:!0},link:{icon:!!n(0).r,search:!0,bookmark:!1,history:!1},view:{topBookmark:!1,topUseful:!1,windmill:!0,pagin:!1,isShowHomepageBtn:!0,isHideIcp:!1,scaleSide:1,scaleMain:1},layout:{row:2,col:5,rowGap:.2,colGap:.3,custom:!1,customItem:[3,4]},animation:{easing:"linear"},icon:{miniMode:!1,shadow:!1,startAnimation:!1,opacity:1,radius:.5,scale:.5,isHideIconName:!1},search:{hide:!1,searchSuggest:!0,hideCategory:!1,hideButton:!0,shadow:!0,scale:.82,radius:r.i,opacity:1},font:{shadow:!0,size:15,color:"rgb(221, 221, 221)"}},i=function(t,e){let n=null;switch(t+"*"+e){case"2*4":case"2*5":n={iconScale:.5,colGap:.3,rowGap:.2,searchScale:.82};break;case"2*6":n={iconScale:.6,colGap:.3,rowGap:.3,searchScale:.9};break;case"2*7":n={iconScale:.7,colGap:.3,rowGap:.3,searchScale:.9};break;case"3*3":n={iconScale:.7,colGap:.24,rowGap:.2,searchScale:.82}}return n}},function(t,e,n){"use strict";n.d(e,"c",(function(){return a})),n.d(e,"a",(function(){return s})),n.d(e,"b",(function(){return c}));var r=n(7),o=n.n(r),i=(n(13),n(232),n(18),n(44),n(0));function a(t){return function(e){const n=new Uint8Array((e||40)/2);return window.crypto.getRandomValues(n),t+(new Date).getTime().toString(32)+function(t){let e="";const n="abcdefghijklmnopqrstuvwxyz0123456789";for(let r=0;r<t;r++)e+=n.charAt(Math.floor(Math.random()*n.length));return e}(18)}()}function s(t,e=i.C.lang){const n=this,r=/(\d{1,4})\D+(\d{1,2})\D+(\d{1,4})/;let o,a,s;return r.test(t)?(t.replace(r,(t,r,i,c)=>{4===r.length?(o=r,a=i,s=c):n.isFirstDate(e)?(s=r,a=i,o=c):(s=i,a=r,o=c),"th"===e&&(o=Number(o)-543)}),new Date(`${o}/${a}/${s}`)):null}function c(t,e,n){return new o.a((r,o)=>{const i=new Image(e,n);i.onload=()=>r(i),i.onerror=o,i.crossOrigin="anonymous",i.src=t})}},function(t,e,n){var r=n(4);t.exports=r.Promise},function(t,e,n){var r=n(9),o=n(37),i=n(6)("species");t.exports=function(t,e){var n,a=r(t).constructor;return void 0===a||null==(n=r(a)[i])?e:o(n)}},function(t,e,n){var r=n(9),o=n(16),i=n(92);t.exports=function(t,e){if(r(t),o(e)&&e.constructor===t)return e;var n=i.f(t);return(0,n.resolve)(e),n.promise}},function(t,e,n){"use strict";var r={}.propertyIsEnumerable,o=Object.getOwnPropertyDescriptor,i=o&&!r.call({1:2},1);e.f=i?function(t){var e=o(this,t);return!!e&&e.enumerable}:r},function(t,e,n){var r=n(4),o=n(57),i=r.WeakMap;t.exports="function"==typeof i&&/native code/.test(o(i))},function(t,e,n){var r=n(31),o=n(112),i=n(141),a=n(9);t.exports=r("Reflect","ownKeys")||function(t){var e=o.f(a(t)),n=i.f;return n?e.concat(n(t)):e}},function(t,e,n){var r=n(4);t.exports=r},function(t,e,n){var r=n(42),o=n(45),i=n(140),a=function(t){return function(e,n,a){var s,c=r(e),u=o(c.length),l=i(a,u);if(t&&n!=n){for(;u>l;)if((s=c[l++])!=s)return!0}else for(;u>l;l++)if((t||l in c)&&c[l]===n)return t||l||0;return!t&&-1}};t.exports={includes:a(!0),indexOf:a(!1)}},function(t,e,n){var r=n(43),o=Math.max,i=Math.min;t.exports=function(t,e){var n=r(t);return n<0?o(n+e,0):i(n,e)}},function(t,e){e.f=Object.getOwnPropertySymbols},function(t,e,n){var r=n(24);t.exports=function(t,e,n){for(var o in e)r(t,o,e[o],n);return t}},function(t,e,n){var r=n(16);t.exports=function(t){if(!r(t)&&null!==t)throw TypeError("Can't set "+String(t)+" as a prototype");return t}},function(t,e,n){var r=n(88);t.exports=r&&!Symbol.sham&&"symbol"==typeof Symbol.iterator},function(t,e){t.exports=function(t,e,n){if(!(t instanceof e))throw TypeError("Incorrect "+(n?n+" ":"")+"invocation");return t}},function(t,e,n){var r=n(9),o=n(147),i=n(45),a=n(74),s=n(148),c=n(150),u=function(t,e){this.stopped=t,this.result=e};t.exports=function(t,e,n){var l,p,h,d,f,g,v,m=n&&n.that,y=!(!n||!n.AS_ENTRIES),b=!(!n||!n.IS_ITERATOR),w=!(!n||!n.INTERRUPTED),x=a(e,m,1+y+w),_=function(t){return l&&c(l),new u(!0,t)},O=function(t){return y?(r(t),w?x(t[0],t[1],_):x(t[0],t[1])):w?x(t,_):x(t)};if(b)l=t;else{if("function"!=typeof(p=s(t)))throw TypeError("Target is not iterable");if(o(p)){for(h=0,d=i(t.length);d>h;h++)if((f=O(t[h]))&&f instanceof u)return f;return new u(!1)}l=p.call(t)}for(g=l.next;!(v=g.call(l)).done;){try{f=O(v.value)}catch(t){throw c(l),t}if("object"==typeof f&&f&&f instanceof u)return f}return new u(!1)}},function(t,e,n){var r=n(6),o=n(32),i=r("iterator"),a=Array.prototype;t.exports=function(t){return void 0!==t&&(o.Array===t||a[i]===t)}},function(t,e,n){var r=n(114),o=n(32),i=n(6)("iterator");t.exports=function(t){if(null!=t)return t[i]||t["@@iterator"]||o[r(t)]}},function(t,e,n){var r={};r[n(6)("toStringTag")]="z",t.exports="[object z]"===String(r)},function(t,e,n){var r=n(9);t.exports=function(t){var e=t.return;if(void 0!==e)return r(e.call(t)).value}},function(t,e,n){var r=n(6)("iterator"),o=!1;try{var i=0,a={next:function(){return{done:!!i++}},return:function(){o=!0}};a[r]=function(){return this},Array.from(a,(function(){throw 2}))}catch(t){}t.exports=function(t,e){if(!e&&!o)return!1;var n=!1;try{var i={};i[r]=function(){return{next:function(){return{done:n=!0}}}},t(i)}catch(t){}return n}},function(t,e,n){var r,o,i,a,s,c,u,l,p=n(4),h=n(53).f,d=n(89).set,f=n(91),g=n(153),v=n(64),m=p.MutationObserver||p.WebKitMutationObserver,y=p.document,b=p.process,w=p.Promise,x=h(p,"queueMicrotask"),_=x&&x.value;_||(r=function(){var t,e;for(v&&(t=b.domain)&&t.exit();o;){e=o.fn,o=o.next;try{e()}catch(t){throw o?a():i=void 0,t}}i=void 0,t&&t.enter()},f||v||g||!m||!y?w&&w.resolve?((u=w.resolve(void 0)).constructor=w,l=u.then,a=function(){l.call(u,r)}):a=v?function(){b.nextTick(r)}:function(){d.call(p,r)}:(s=!0,c=y.createTextNode(""),new m(r).observe(c,{characterData:!0}),a=function(){c.data=s=!s})),t.exports=_||function(t){var e={fn:t,next:void 0};i&&(i.next=e),o||(o=e,a()),i=e}},function(t,e,n){var r=n(40);t.exports=/web0s(?!.*chrome)/i.test(r)},function(t,e,n){var r=n(4);t.exports=function(t,e){var n=r.console;n&&n.error&&(1===arguments.length?n.error(t):n.error(t,e))}},function(t,e){t.exports=function(t){try{return{error:!1,value:t()}}catch(t){return{error:!0,value:t}}}},function(t,e){t.exports="object"==typeof window},function(t,e,n){var r=n(6),o=n(65),i=n(21),a=r("unscopables"),s=Array.prototype;null==s[a]&&i.f(s,a,{configurable:!0,value:o(null)}),t.exports=function(t){s[a][t]=!0}},function(t,e,n){var r=n(20),o=n(21),i=n(9),a=n(159);t.exports=r?Object.defineProperties:function(t,e){i(t);for(var n,r=a(e),s=r.length,c=0;s>c;)o.f(t,n=r[c++],e[n]);return t}},function(t,e,n){var r=n(87),o=n(62);t.exports=Object.keys||function(t){return r(t,o)}},function(t,e,n){"use strict";var r=n(46),o=n(161),i=n(78),a=n(69),s=n(63),c=n(15),u=n(24),l=n(6),p=n(41),h=n(32),d=n(93),f=d.IteratorPrototype,g=d.BUGGY_SAFARI_ITERATORS,v=l("iterator"),m=function(){return this};t.exports=function(t,e,n,l,d,y,b){o(n,e,l);var w,x,_,O=function(t){if(t===d&&T)return T;if(!g&&t in k)return k[t];switch(t){case"keys":case"values":case"entries":return function(){return new n(this,t)}}return function(){return new n(this)}},S=e+" Iterator",j=!1,k=t.prototype,A=k[v]||k["@@iterator"]||d&&k[d],T=!g&&A||O(d),E="Array"==e&&k.entries||A;if(E&&(w=i(E.call(new t)),f!==Object.prototype&&w.next&&(p||i(w)===f||(a?a(w,f):"function"!=typeof w[v]&&c(w,v,m)),s(w,S,!0,!0),p&&(h[S]=m))),"values"==d&&A&&"values"!==A.name&&(j=!0,T=function(){return A.call(this)}),p&&!b||k[v]===T||c(k,v,T),h[e]=T,d)if(x={values:O("values"),keys:y?T:O("keys"),entries:O("entries")},b)for(_ in x)(g||j||!(_ in k))&&u(k,_,x[_]);else r({target:e,proto:!0,forced:g||j},x);return x}},function(t,e,n){"use strict";var r=n(93).IteratorPrototype,o=n(65),i=n(54),a=n(63),s=n(32),c=function(){return this};t.exports=function(t,e,n){var u=e+" Iterator";return t.prototype=o(r,{next:i(1,n)}),a(t,u,!1,!0),s[u]=c,t}},function(t,e,n){var r=n(8);t.exports=!r((function(){function t(){}return t.prototype.constructor=null,Object.getPrototypeOf(new t)!==t.prototype}))},function(t,e,n){"use strict";n(18);var r=n(24),o=n(66),i=n(8),a=n(6),s=n(15),c=a("species"),u=RegExp.prototype;t.exports=function(t,e,n,l){var p=a(t),h=!i((function(){var e={};return e[p]=function(){return 7},7!=""[t](e)})),d=h&&!i((function(){var e=!1,n=/a/;return"split"===t&&((n={}).constructor={},n.constructor[c]=function(){return n},n.flags="",n[p]=/./[p]),n.exec=function(){return e=!0,null},n[p](""),!e}));if(!h||!d||n){var f=/./[p],g=e(p,""[t],(function(t,e,n,r,i){var a=e.exec;return a===o||a===u.exec?h&&!i?{done:!0,value:f.call(e,n,r)}:{done:!0,value:t.call(n,e,r)}:{done:!1}}));r(String.prototype,t,g[0]),r(u,p,g[1])}l&&s(u[p],"sham",!0)}},function(t,e,n){"use strict";var r=n(165).charAt;t.exports=function(t,e,n){return e+(n?r(t,e).length:1)}},function(t,e,n){var r=n(43),o=n(35),i=function(t){return function(e,n){var i,a,s=String(o(e)),c=r(n),u=s.length;return c<0||c>=u?t?"":void 0:(i=s.charCodeAt(c))<55296||i>56319||c+1===u||(a=s.charCodeAt(c+1))<56320||a>57343?t?s.charAt(c):i:t?s.slice(c,c+2):a-56320+(i-55296<<10)+65536}};t.exports={codeAt:i(!1),charAt:i(!0)}},function(t,e,n){var r=n(50),o=Math.floor,i="".replace,a=/\$([$&'`]|\d{1,2}|<[^>]*>)/g,s=/\$([$&'`]|\d{1,2})/g;t.exports=function(t,e,n,c,u,l){var p=n+t.length,h=c.length,d=s;return void 0!==u&&(u=r(u),d=a),i.call(l,d,(function(r,i){var a;switch(i.charAt(0)){case"$":return"$";case"&":return t;case"`":return e.slice(0,n);case"'":return e.slice(p);case"<":a=u[i.slice(1,-1)];break;default:var s=+i;if(0===s)return r;if(s>h){var l=o(s/10);return 0===l?r:l<=h?void 0===c[l-1]?i.charAt(1):c[l-1]+i.charAt(1):r}a=c[s-1]}return void 0===a?"":a}))}},function(t,e,n){var r=n(34),o=n(66);t.exports=function(t,e){var n=t.exec;if("function"==typeof n){var i=n.call(t,e);if("object"!=typeof i)throw TypeError("RegExp exec method returned something other than an Object or null");return i}if("RegExp"!==r(t))throw TypeError("RegExp#exec called on incompatible receiver");return o.call(t,e)}},function(t,e,n){n(169);var r=n(170);t.exports=r},function(t,e,n){n(94)},function(t,e,n){n(94),t.exports=n(12)},function(t,e,n){var r=n(28),o=n(226),i=n(128),a=n(73),s=n(173),c=n(227),u=function(t,e){this.stopped=t,this.result=e};t.exports=function(t,e,n){var l,p,h,d,f,g,v,m=n&&n.that,y=!(!n||!n.AS_ENTRIES),b=!(!n||!n.IS_ITERATOR),w=!(!n||!n.INTERRUPTED),x=a(e,m,1+y+w),_=function(t){return l&&c(l),new u(!0,t)},O=function(t){return y?(r(t),w?x(t[0],t[1],_):x(t[0],t[1])):w?x(t,_):x(t)};if(b)l=t;else{if("function"!=typeof(p=s(t)))throw TypeError("Target is not iterable");if(o(p)){for(h=0,d=i(t.length);d>h;h++)if((f=O(t[h]))&&f instanceof u)return f;return new u(!1)}l=p.call(t)}for(g=l.next;!(v=g.call(l)).done;){try{f=O(v.value)}catch(t){throw c(l),t}if("object"==typeof f&&f&&f instanceof u)return f}return new u(!1)}},function(t,e){t.exports=function(t){try{return{error:!1,value:t()}}catch(t){return{error:!0,value:t}}}},function(t,e,n){var r=n(126),o=n(101),i=n(33)("iterator");t.exports=function(t){if(null!=t)return t[i]||t["@@iterator"]||o[r(t)]}},function(t,e,n){"use strict";n.d(e,"a",(function(){return r})),n.d(e,"c",(function(){return o})),n.d(e,"b",(function(){return i}));
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const r="undefined"!=typeof window&&null!=window.customElements&&void 0!==window.customElements.polyfillWrapFlushCallback,o=(t,e,n=null,r=null)=>{for(;e!==n;){const n=e.nextSibling;t.insertBefore(e,r),e=n}},i=(t,e,n=null)=>{for(;e!==n;){const n=e.nextSibling;t.removeChild(e),e=n}}},,function(t,e,n){var r,o,i=n(12),a=n(179),s=i.process,c=s&&s.versions,u=c&&c.v8;u?o=(r=u.split("."))[0]<4?1:r[0]+r[1]:a&&(!(r=a.match(/Edge\/(\d+)/))||r[1]>=74)&&(r=a.match(/Chrome\/(\d+)/))&&(o=r[1]),t.exports=o&&+o},function(t,e,n){var r=n(70);t.exports=function(t){return r[t+"Prototype"]}},function(t,e,n){"use strict";n.r(e),n.d(e,"slave",(function(){return s}));n(10),n(13),n(17),n(52);var r=n(7),o=n.n(r),i=n(259),a=n(123);const s=new class{constructor(){if(this.channel=null,this.initResolve=[],this.initReject=[],this.messageScheduler=new i.a,this.initChannel=()=>{"serviceworker"===a.b?this.initServiceworker():"background"===a.b&&this.initBackground()},this.awaitChannel=()=>new o.a(async(t,e)=>{"serviceworker"===a.b?this.channel?(await this.channel.active,await this.channel.controlling,t(null)):(this.initResolve.push(t),this.initReject.push(e)):"background"===a.b&&t(null)}),this.initServiceworker=async()=>{try{const{createWorkBox:t}=await n.e(12).then(n.bind(null,575)),e=await t();if(!e)return;e.addEventListener("message",t=>{const{type:e,payload:n={}}=t.data;"master:bordcast-message"===e&&this.messageScheduler.execTask(n.type,n.payload)}),await e.active,await e.controlling,this.channel=e,this.initResolve.forEach(t=>{t()}),this.channel.postTask=this.channel.messageSW}catch(t){console.log("slave初始化错误：",t),this.initReject.forEach(t=>{t()})}},this.initBackground=()=>{this.channel={postTask:t=>new o.a((e,n)=>{chrome.runtime.sendMessage(t,t=>{chrome.runtime.lastError&&n(chrome.runtime.lastError),e(t)})})},chrome.runtime.onMessage.addListener(({type:t,payload:e,ignoreId:n})=>{"master:bordcast-message"===t?chrome.tabs.getCurrent(t=>{n!==t.id&&this.messageScheduler.execTask(e.type,e.payload)}):"slave:bordcast-message"===t&&this.messageScheduler.execTask(e.data.type,e.data.payload)})},a.a)throw new Error("it's not page");this.initChannel()}postTask(t,e,n){return new o.a(async(r,o)=>{let i=!1;await this.awaitChannel();const s=Object.assign(Object.assign(Object.assign({},a.d),{taskId:Object(a.c)()}),n);s.timeout&&setTimeout(()=>{i||r({error:"timeout"})},s.timeout);try{const n=await this.channel.postTask({type:t,payload:Object.assign({data:e},s)});i=!0,r(n)}catch(t){r({error:t})}})}listenMessage(t,e){this.messageScheduler.listenTask(t,e)}sendMessage(t,e=""){this.postTask("slave:bordcast-message",{type:t,payload:e})}}},function(t,e,n){var r=n(83);t.exports=r("navigator","userAgent")||""},function(t,e,n){var r=n(29),o=n(72),i=n(181),a=n(269),s=i("IE_PROTO"),c=Object.prototype;t.exports=a?Object.getPrototypeOf:function(t){return t=o(t),r(t,s)?t[s]:"function"==typeof t.constructor&&t instanceof t.constructor?t.constructor.prototype:t instanceof Object?c:null}},function(t,e,n){var r=n(202),o=n(203),i=r("keys");t.exports=function(t){return i[t]||(i[t]=o(t))}},function(t,e,n){var r=n(12),o=n(268),i=r["__core-js_shared__"]||o("__core-js_shared__",{});t.exports=i},function(t,e,n){var r=n(28),o=n(270);t.exports=Object.setPrototypeOf||("__proto__"in{}?function(){var t,e=!1,n={};try{(t=Object.getOwnPropertyDescriptor(Object.prototype,"__proto__").set).call(n,[]),e=n instanceof Array}catch(t){}return function(n,i){return r(n),o(i),e?t.call(n,i):n.__proto__=i,n}}():void 0)},function(t,e){var n=Math.ceil,r=Math.floor;t.exports=function(t){return isNaN(t=+t)?0:(t>0?r:n)(t)}},function(t,e){t.exports={}},function(t,e,n){var r={};r[n(33)("toStringTag")]="z",t.exports="[object z]"===String(r)},function(t,e,n){var r,o=n(28),i=n(224),a=n(204),s=n(185),c=n(205),u=n(98),l=n(181),p=l("IE_PROTO"),h=function(){},d=function(t){return"<script>"+t+"<\/script>"},f=function(){try{r=document.domain&&new ActiveXObject("htmlfile")}catch(t){}var t,e;f=r?function(t){t.write(d("")),t.close();var e=t.parentWindow.Object;return t=null,e}(r):((e=u("iframe")).style.display="none",c.appendChild(e),e.src=String("javascript:"),(t=e.contentWindow.document).open(),t.write(d("document.F=Object")),t.close(),t.F);for(var n=a.length;n--;)delete f.prototype[a[n]];return f()};s[p]=!0,t.exports=Object.create||function(t,e){var n;return null!==t?(h.prototype=o(t),n=new h,h.prototype=null,n[p]=t):n=f(),void 0===e?n:i(n,e)}},function(t,e,n){"use strict";n.d(e,"i",(function(){return o})),n.d(e,"b",(function(){return i})),n.d(e,"a",(function(){return a})),n.d(e,"c",(function(){return s})),n.d(e,"h",(function(){return c})),n.d(e,"g",(function(){return u})),n.d(e,"e",(function(){return l})),n.d(e,"d",(function(){return p})),n.d(e,"f",(function(){return h}));var r=n(0);const o=.5;function i(t){return`https://chrome.google.com/webstore/detail/infinity-new-tab-producti/${t}/reviews?utm_source=infinity-rate`}const a="https://addons.mozilla.org/"+r.C.lang+"/firefox/addon/infinity-new-tab-firefox/";function s(t){return"https://microsoftedge.microsoft.com/addons/detail/infinity-new-tab-produc/"+t}const c="privacy_data_uninstall_title",u="privacy_data_uninstall_confirm",l=!0,p=()=>{chrome.runtime.setUninstallURL("https://uninstall.infinitynewtab.com/?from="+r.c)},h="https://infinityicon.infinitynewtab.com/assets/logo-basic.png"},function(t,e){t.exports=function(t,e,n){if(!(t instanceof e))throw TypeError("Incorrect "+(n?n+" ":"")+"invocation");return t}},function(t,e,n){"use strict";n.r(e),n.d(e,"imgConfig",(function(){return c})),n.d(e,"getRandomWallpaper",(function(){return u})),n.d(e,"getBingWallpaper",(function(){return l})),n.d(e,"getWallpapers",(function(){return p})),n.d(e,"likeWallpaper",(function(){return h})),n.d(e,"collectionWallpaper",(function(){return d})),n.d(e,"addCustomColor",(function(){return f})),n.d(e,"setCustomColorItems",(function(){return g})),n.d(e,"getCustomColor",(function(){return v})),n.d(e,"removeCustomColor",(function(){return m})),n.d(e,"uploadWallpaper",(function(){return y})),n.d(e,"getWallpapersById",(function(){return b})),n.d(e,"createWallpaperLibrary",(function(){return w})),n.d(e,"getUserWallpaperLibrary",(function(){return x})),n.d(e,"hasWallpaperLibrary",(function(){return _})),n.d(e,"getLikedWallpaper",(function(){return O})),n.d(e,"getCollectionWallpaper",(function(){return S})),n.d(e,"getWallpaperLibraryItems",(function(){return j})),n.d(e,"getUserWallpaperLibraryItemsById",(function(){return k})),n.d(e,"removeWallpaperLibraryItem",(function(){return A})),n.d(e,"removeWallpaperLibrary",(function(){return T})),n.d(e,"addImagesToLibrary",(function(){return E})),n.d(e,"renameWallpaperLibrary",(function(){return C})),n.d(e,"getNextWallpaper",(function(){return R})),n.d(e,"convertURL",(function(){return I}));n(10),n(52);var r=n(0),o=n(5),i=n(23);const a=Math.floor(screen.width*window.devicePixelRatio),s=Math.floor(203*window.devicePixelRatio),c={smallWidth:s>3840?3840:s,normalWidth:a>3840?3840:a,format:i.c?"":"format/webp/"},u=async()=>{try{const t=await o.a.get(r.w+"/random-wallpaper",{_:(new Date).getTime()});if(!t.success)throw t;const{src:e,_id:n,source:i}=t.data[0],{url:a,rawUrl:s}=I(e.rawSrc);return{data:{url:a,rawUrl:s,id:n,source:i}}}catch(t){return{error:t}}},l=async()=>{try{const t=await o.a.get(r.x+"/get_bing_wallpaper",null,{_single:"getBingWallpaper"});if(t.error)throw t.error;const{data:e}=t,{content:n,url:i,rawUrl:a}=I(e.src.rawSrc);return e.thumbnail=n,e.url=i,e.rawUrl=a,t}catch(t){return{error:t}}},p=async t=>{const{source:e}=t;t.source="all"===e?"":e;try{const e=await o.a.get(r.w+"/get-wallpaper",t,{_single:"getWallpapers"}),{data:n}=e;return n.forEach(t=>{const{content:e,url:n,rawUrl:r}=I(t.src.rawSrc);t.thumbnail=e,t.url=n,t.rawUrl=r}),{result:e}}catch(t){return{error:t}}},h=async(t,e)=>{try{const n=await o.a.post(r.x+"/like_wallpaper",{id:t,state:e},{_auth:!0});if(0!==n.code)throw n;return n}catch(t){return{error:t}}},d=async(t,e)=>{try{const n=await o.a.post(r.x+"/collection_wallpaper",{id:t,state:e},{_auth:!0});if(0!==n.code)throw n;return n}catch(t){return{error:t}}},f=async t=>{try{const e=await o.a.post(r.x+"/add_custom_color",Object.assign(Object.assign({},t),{newVer:!0}),{_auth:!0});if(0!==e.code)throw e;return e}catch(t){return{error:t}}},g=async t=>{try{const e=await o.a.post(r.x+"/set_custom_color_items",t,{_auth:!0});if(0!==e.code)throw e;return e}catch(t){return{error:t}}},v=async()=>{try{const t=await o.a.get(r.x+"/get_custom_color",null,{_auth:!0});if(0!==t.code)throw t;return t}catch(t){return{error:t}}},m=async t=>{try{const e=await o.a.post(r.x+"/remove_custom_color",{id:t,newVer:!0},{_auth:!0});if(0!==e.code)throw e;return e}catch(t){return{error:t}}},y=async t=>{try{const e=await o.a.post(r.x+"/upload_wallpaper",t,{headers:{"Content-Type":"multipart/form-data"}});if(0!==e.code)throw e;return{data:e.data}}catch(t){return{error:t}}},b=async t=>{try{const e=await o.a.get(r.x+"/get_wallpapers_by_id",{id:t});if(0!==e.code)throw e;const{data:n}=e;return n.forEach(t=>{const{content:e,url:n,rawUrl:r}=I(t.src.rawSrc);t.thumbnail=e,t.url=n,t.rawUrl=r}),{data:n}}catch(t){return{error:t}}},w=async({libraryName:t,libraryId:e,wallpapers:n})=>{try{return await o.a.post(r.x+"/create_wallpaper_library",{libraryName:t,libraryId:e,wallpapers:n},{_auth:!0})}catch(t){return{error:t}}},x=async()=>await o.a.get(r.x+"/get_user_wallpaper_library",null,{_auth:!0}),_=async t=>{try{return await o.a.get(r.x+"/has_wallpaper_library",{libraryId:t},{_auth:!0,_proxy:!0})}catch(t){return{error:t}}},O=async()=>{try{return await o.a.get(r.x+"/get_liked_wallpaper",null,{_auth:!0})}catch(t){return{error:t}}},S=async()=>{try{return await o.a.get(r.x+"/get_collection_wallpaper",null,{_auth:!0})}catch(t){return{error:t}}},j=async t=>{const e=await o.a.get(r.x+"/get_user_wallpaper_library_items",{libraryId:t});e.data.map(t=>{const{content:e,url:n,rawUrl:r}=I(t.url);return t.content=e,t.url=n,t.rawUrl=r,t});const{data:n}=e;return e.data={items:n,count:n.length},e.data},k=async t=>{try{const e=await o.a.get(r.x+"/get_user_wallpaper_library_items_by_id",{libraryItemsId:t}),{data:n}=e;return e.data={items:n,count:n.length},e.data}catch(t){return{error:t}}},A=async(t,e,n)=>{try{return await o.a.post(r.x+"/remove_wallpaper_library_item",{libraryId:t,libraryItemId:e,ext:n},{_auth:!0})}catch(t){return{error:t}}},T=async t=>{try{return await o.a.post(r.x+"/remove_wallpaper_library",{libraryId:t},{_auth:!0})}catch(t){return{error:t}}},E=async(t,e)=>{try{return await o.a.post(r.x+"/add_images_to_library",{libraryId:t,wallpapers:e},{_auth:!0})}catch(t){return{error:t}}},C=async(t,e)=>{try{return await o.a.post(r.x+"/rename_wallpaper_library",{libraryId:t,libraryName:e},{_auth:!0})}catch(t){return{error:t}}},R=async(t,e,n="library")=>{const i={source:t,type:n};e&&(i._id=e);const a=await o.a.get(r.x+"/get_next_wallpaper",i,{_single:"getNextWallpaper"});if(0!==a.code)throw new Error;const{data:s}=a,{content:c,url:u,rawUrl:l}=I(s.rawUrl);return s.thumbnail=c,s.url=u,s.rawUrl=l,a},I=t=>({rawUrl:t,url:`${t}?imageView2/2/w/${c.normalWidth}/${c.format}interlace/1`,content:`${t}?imageView2/2/w/${c.smallWidth}/${c.format}interlace/1`})},function(t,e,n){"use strict";var r=n(82),o=n(286),i=n(101),a=n(104),s=n(214),c=a.set,u=a.getterFor("Array Iterator");t.exports=s(Array,"Array",(function(t,e){c(this,{type:"Array Iterator",target:r(t),index:0,kind:e})}),(function(){var t=u(this),e=t.target,n=t.kind,r=t.index++;return!e||r>=e.length?(t.target=void 0,{value:void 0,done:!0}):"keys"==n?{value:r,done:!1}:"values"==n?{value:e[r],done:!1}:{value:[r,e[r]],done:!1}}),"values"),i.Arguments=i.Array,o("keys"),o("values"),o("entries")},function(t,e){var n,r,o=t.exports={};function i(){throw new Error("setTimeout has not been defined")}function a(){throw new Error("clearTimeout has not been defined")}function s(t){if(n===setTimeout)return setTimeout(t,0);if((n===i||!n)&&setTimeout)return n=setTimeout,setTimeout(t,0);try{return n(t,0)}catch(e){try{return n.call(null,t,0)}catch(e){return n.call(this,t,0)}}}!function(){try{n="function"==typeof setTimeout?setTimeout:i}catch(t){n=i}try{r="function"==typeof clearTimeout?clearTimeout:a}catch(t){r=a}}();var c,u=[],l=!1,p=-1;function h(){l&&c&&(l=!1,c.length?u=c.concat(u):p=-1,u.length&&d())}function d(){if(!l){var t=s(h);l=!0;for(var e=u.length;e;){for(c=u,u=[];++p<e;)c&&c[p].run();p=-1,e=u.length}c=null,l=!1,function(t){if(r===clearTimeout)return clearTimeout(t);if((r===a||!r)&&clearTimeout)return r=clearTimeout,clearTimeout(t);try{r(t)}catch(e){try{return r.call(null,t)}catch(e){return r.call(this,t)}}}(t)}}function f(t,e){this.fun=t,this.array=e}function g(){}o.nextTick=function(t){var e=new Array(arguments.length-1);if(arguments.length>1)for(var n=1;n<arguments.length;n++)e[n-1]=arguments[n];u.push(new f(t,e)),1!==u.length||l||s(d)},f.prototype.run=function(){this.fun.apply(null,this.array)},o.title="browser",o.browser=!0,o.env={},o.argv=[],o.version="",o.versions={},o.on=g,o.addListener=g,o.once=g,o.off=g,o.removeListener=g,o.removeAllListeners=g,o.emit=g,o.prependListener=g,o.prependOnceListener=g,o.listeners=function(t){return[]},o.binding=function(t){throw new Error("process.binding is not supported")},o.cwd=function(){return"/"},o.chdir=function(t){throw new Error("process.chdir is not supported")},o.umask=function(){return 0}},function(t,e,n){var r=n(404),o="object"==typeof self&&self&&self.Object===Object&&self,i=r||o||Function("return this")();t.exports=i},,function(t,e,n){var r=n(28),o=n(49),i=n(33)("species");t.exports=function(t,e){var n,a=r(t).constructor;return void 0===a||null==(n=r(a)[i])?e:o(n)}},function(t,e,n){var r=n(184),o=n(68),i=function(t){return function(e,n){var i,a,s=String(o(e)),c=r(n),u=s.length;return c<0||c>=u?t?"":void 0:(i=s.charCodeAt(c))<55296||i>56319||c+1===u||(a=s.charCodeAt(c+1))<56320||a>57343?t?s.charAt(c):i:t?s.slice(c,c+2):a-56320+(i-55296<<10)+65536}};t.exports={codeAt:i(!1),charAt:i(!0)}},function(t,e,n){"use strict";var r=n(215).IteratorPrototype,o=n(187),i=n(47),a=n(121),s=n(101),c=function(){return this};t.exports=function(t,e,n){var u=e+" Iterator";return t.prototype=o(r,{next:i(1,n)}),a(t,u,!1,!0),s[u]=c,t}},function(t,e,n){"use strict";n.d(e,"b",(function(){return o})),n.d(e,"a",(function(){return i}));var r=n(80);
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */function o(t){let e=i.get(t.type);void 0===e&&(e={stringsArray:new WeakMap,keyString:new Map},i.set(t.type,e));let n=e.stringsArray.get(t.strings);if(void 0!==n)return n;const o=t.strings.join(r.f);return n=e.keyString.get(o),void 0===n&&(n=new r.a(t,t.getTemplateElement()),e.keyString.set(o,n)),e.stringsArray.set(t.strings,n),n}const i=new Map},function(t,e,n){"use strict";n.d(e,"a",(function(){return a})),n.d(e,"b",(function(){return s}));var r=n(174),o=n(103),i=n(198);
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const a=new WeakMap,s=(t,e,n)=>{let s=a.get(e);void 0===s&&(Object(r.b)(e,e.firstChild),a.set(e,s=new o.e(Object.assign({templateFactory:i.b},n))),s.appendInto(e)),s.setValue(t),s.commit()}},function(t,e,n){"use strict";n.d(e,"a",(function(){return o})),n.d(e,"b",(function(){return i}));
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const r=new WeakMap,o=t=>(...e)=>{const n=t(...e);return r.set(n,!0),n},i=t=>"function"==typeof t&&r.has(t)},function(t,e,n){"use strict";var r=n(27),o=n(180),i=n(183),a=n(187),s=n(39),c=n(47),u=n(171),l=function(t,e){var n=this;if(!(n instanceof l))return new l(t,e);i&&(n=i(new Error(void 0),o(n))),void 0!==e&&s(n,"message",String(e));var r=[];return u(t,r.push,{that:r}),s(n,"errors",r),n};l.prototype=a(Error.prototype,{constructor:c(5,l),message:c(5,""),name:c(5,"AggregateError")}),r({global:!0},{AggregateError:l})},function(t,e,n){var r=n(96),o=n(182);(t.exports=function(t,e){return o[t]||(o[t]=void 0!==e?e:{})})("versions",[]).push({version:"3.15.2",mode:r?"pure":"global",copyright:"© 2021 Denis Pushkarev (zloirock.ru)"})},function(t,e){var n=0,r=Math.random();t.exports=function(t){return"Symbol("+String(void 0===t?"":t)+")_"+(++n+r).toString(36)}},function(t,e){t.exports=["constructor","hasOwnProperty","isPrototypeOf","propertyIsEnumerable","toLocaleString","toString","valueOf"]},function(t,e,n){var r=n(83);t.exports=r("document","documentElement")},function(t,e,n){var r=n(176),o=n(19);t.exports=!!Object.getOwnPropertySymbols&&!o((function(){var t=Symbol();return!String(t)||!(Object(t)instanceof Symbol)||!Symbol.sham&&r&&r<41}))},function(t,e,n){var r=n(12);t.exports=r.Promise},function(t,e,n){var r=n(182),o=Function.toString;"function"!=typeof r.inspectSource&&(r.inspectSource=function(t){return o.call(t)}),t.exports=r.inspectSource},function(t,e,n){var r,o,i,a=n(12),s=n(19),c=n(73),u=n(205),l=n(98),p=n(210),h=n(129),d=a.location,f=a.setImmediate,g=a.clearImmediate,v=a.process,m=a.MessageChannel,y=a.Dispatch,b=0,w={},x=function(t){if(w.hasOwnProperty(t)){var e=w[t];delete w[t],e()}},_=function(t){return function(){x(t)}},O=function(t){x(t.data)},S=function(t){a.postMessage(t+"",d.protocol+"//"+d.host)};f&&g||(f=function(t){for(var e=[],n=1;arguments.length>n;)e.push(arguments[n++]);return w[++b]=function(){("function"==typeof t?t:Function(t)).apply(void 0,e)},r(b),b},g=function(t){delete w[t]},h?r=function(t){v.nextTick(_(t))}:y&&y.now?r=function(t){y.now(_(t))}:m&&!p?(i=(o=new m).port2,o.port1.onmessage=O,r=c(i.postMessage,i,1)):a.addEventListener&&"function"==typeof postMessage&&!a.importScripts&&d&&"file:"!==d.protocol&&!s(S)?(r=S,a.addEventListener("message",O,!1)):r="onreadystatechange"in l("script")?function(t){u.appendChild(l("script")).onreadystatechange=function(){u.removeChild(this),x(t)}}:function(t){setTimeout(_(t),0)}),t.exports={set:f,clear:g}},function(t,e,n){var r=n(179);t.exports=/(?:iphone|ipod|ipad).*applewebkit/i.test(r)},function(t,e,n){var r=n(28),o=n(30),i=n(120);t.exports=function(t,e){if(r(t),o(e)&&e.constructor===t)return e;var n=i.f(t);return(0,n.resolve)(e),n.promise}},function(t,e,n){"use strict";var r=n(27),o=n(49),i=n(120),a=n(172),s=n(171);r({target:"Promise",stat:!0},{allSettled:function(t){var e=this,n=i.f(e),r=n.resolve,c=n.reject,u=a((function(){var n=o(e.resolve),i=[],a=0,c=1;s(t,(function(t){var o=a++,s=!1;i.push(void 0),c++,n.call(e,t).then((function(t){s||(s=!0,i[o]={status:"fulfilled",value:t},--c||r(i))}),(function(t){s||(s=!0,i[o]={status:"rejected",reason:t},--c||r(i))}))})),--c||r(i)}));return u.error&&c(u.value),n.promise}})},function(t,e,n){"use strict";var r=n(27),o=n(49),i=n(83),a=n(120),s=n(172),c=n(171);r({target:"Promise",stat:!0},{any:function(t){var e=this,n=a.f(e),r=n.resolve,u=n.reject,l=s((function(){var n=o(e.resolve),a=[],s=0,l=1,p=!1;c(t,(function(t){var o=s++,c=!1;a.push(void 0),l++,n.call(e,t).then((function(t){c||p||(p=!0,r(t))}),(function(t){c||p||(c=!0,a[o]=t,--l||u(new(i("AggregateError"))(a,"No one promise resolved")))}))})),--l||u(new(i("AggregateError"))(a,"No one promise resolved"))}));return l.error&&u(l.value),n.promise}})},function(t,e,n){"use strict";var r=n(27),o=n(197),i=n(180),a=n(183),s=n(121),c=n(39),u=n(102),l=n(33),p=n(96),h=n(101),d=n(215),f=d.IteratorPrototype,g=d.BUGGY_SAFARI_ITERATORS,v=l("iterator"),m=function(){return this};t.exports=function(t,e,n,l,d,y,b){o(n,e,l);var w,x,_,O=function(t){if(t===d&&T)return T;if(!g&&t in k)return k[t];switch(t){case"keys":case"values":case"entries":return function(){return new n(this,t)}}return function(){return new n(this)}},S=e+" Iterator",j=!1,k=t.prototype,A=k[v]||k["@@iterator"]||d&&k[d],T=!g&&A||O(d),E="Array"==e&&k.entries||A;if(E&&(w=i(E.call(new t)),f!==Object.prototype&&w.next&&(p||i(w)===f||(a?a(w,f):"function"!=typeof w[v]&&c(w,v,m)),s(w,S,!0,!0),p&&(h[S]=m))),"values"==d&&A&&"values"!==A.name&&(j=!0,T=function(){return A.call(this)}),p&&!b||k[v]===T||c(k,v,T),h[e]=T,d)if(x={values:O("values"),keys:y?T:O("keys"),entries:O("entries")},b)for(_ in x)(g||j||!(_ in k))&&u(k,_,x[_]);else r({target:e,proto:!0,forced:g||j},x);return x}},function(t,e,n){"use strict";var r,o,i,a=n(19),s=n(180),c=n(39),u=n(29),l=n(33),p=n(96),h=l("iterator"),d=!1;[].keys&&("next"in(i=[].keys())?(o=s(s(i)))!==Object.prototype&&(r=o):d=!0);var f=null==r||a((function(){var t={};return r[h].call(t)!==t}));f&&(r={}),p&&!f||u(r,h)||c(r,h,(function(){return this})),t.exports={IteratorPrototype:r,BUGGY_SAFARI_ITERATORS:d}},function(t,e,n){"use strict";t.exports=function(t,e){return function(){for(var n=new Array(arguments.length),r=0;r<n.length;r++)n[r]=arguments[r];return t.apply(e,n)}}},function(t,e,n){"use strict";var r=n(38);function o(t){return encodeURIComponent(t).replace(/%40/gi,"@").replace(/%3A/gi,":").replace(/%24/g,"$").replace(/%2C/gi,",").replace(/%20/g,"+").replace(/%5B/gi,"[").replace(/%5D/gi,"]")}t.exports=function(t,e,n){if(!e)return t;var i;if(n)i=n(e);else if(r.isURLSearchParams(e))i=e.toString();else{var a=[];r.forEach(e,(function(t,e){null!=t&&(r.isArray(t)?e+="[]":t=[t],r.forEach(t,(function(t){r.isDate(t)?t=t.toISOString():r.isObject(t)&&(t=JSON.stringify(t)),a.push(o(e)+"="+o(t))})))})),i=a.join("&")}if(i){var s=t.indexOf("#");-1!==s&&(t=t.slice(0,s)),t+=(-1===t.indexOf("?")?"?":"&")+i}return t}},function(t,e,n){"use strict";t.exports=function(t){return!(!t||!t.__CANCEL__)}},function(t,e,n){"use strict";(function(e){var r=n(38),o=n(297),i={"Content-Type":"application/x-www-form-urlencoded"};function a(t,e){!r.isUndefined(t)&&r.isUndefined(t["Content-Type"])&&(t["Content-Type"]=e)}var s,c={adapter:(("undefined"!=typeof XMLHttpRequest||void 0!==e&&"[object process]"===Object.prototype.toString.call(e))&&(s=n(220)),s),transformRequest:[function(t,e){return o(e,"Accept"),o(e,"Content-Type"),r.isFormData(t)||r.isArrayBuffer(t)||r.isBuffer(t)||r.isStream(t)||r.isFile(t)||r.isBlob(t)?t:r.isArrayBufferView(t)?t.buffer:r.isURLSearchParams(t)?(a(e,"application/x-www-form-urlencoded;charset=utf-8"),t.toString()):r.isObject(t)?(a(e,"application/json;charset=utf-8"),JSON.stringify(t)):t}],transformResponse:[function(t){if("string"==typeof t)try{t=JSON.parse(t)}catch(t){}return t}],timeout:0,xsrfCookieName:"XSRF-TOKEN",xsrfHeaderName:"X-XSRF-TOKEN",maxContentLength:-1,validateStatus:function(t){return t>=200&&t<300}};c.headers={common:{Accept:"application/json, text/plain, */*"}},r.forEach(["delete","get","head"],(function(t){c.headers[t]={}})),r.forEach(["post","put","patch"],(function(t){c.headers[t]=r.merge(i)})),t.exports=c}).call(this,n(192))},function(t,e,n){"use strict";var r=n(38),o=n(298),i=n(217),a=n(300),s=n(303),c=n(304),u=n(221);t.exports=function(t){return new Promise((function(e,l){var p=t.data,h=t.headers;r.isFormData(p)&&delete h["Content-Type"];var d=new XMLHttpRequest;if(t.auth){var f=t.auth.username||"",g=t.auth.password||"";h.Authorization="Basic "+btoa(f+":"+g)}var v=a(t.baseURL,t.url);if(d.open(t.method.toUpperCase(),i(v,t.params,t.paramsSerializer),!0),d.timeout=t.timeout,d.onreadystatechange=function(){if(d&&4===d.readyState&&(0!==d.status||d.responseURL&&0===d.responseURL.indexOf("file:"))){var n="getAllResponseHeaders"in d?s(d.getAllResponseHeaders()):null,r={data:t.responseType&&"text"!==t.responseType?d.response:d.responseText,status:d.status,statusText:d.statusText,headers:n,config:t,request:d};o(e,l,r),d=null}},d.onabort=function(){d&&(l(u("Request aborted",t,"ECONNABORTED",d)),d=null)},d.onerror=function(){l(u("Network Error",t,null,d)),d=null},d.ontimeout=function(){var e="timeout of "+t.timeout+"ms exceeded";t.timeoutErrorMessage&&(e=t.timeoutErrorMessage),l(u(e,t,"ECONNABORTED",d)),d=null},r.isStandardBrowserEnv()){var m=n(305),y=(t.withCredentials||c(v))&&t.xsrfCookieName?m.read(t.xsrfCookieName):void 0;y&&(h[t.xsrfHeaderName]=y)}if("setRequestHeader"in d&&r.forEach(h,(function(t,e){void 0===p&&"content-type"===e.toLowerCase()?delete h[e]:d.setRequestHeader(e,t)})),r.isUndefined(t.withCredentials)||(d.withCredentials=!!t.withCredentials),t.responseType)try{d.responseType=t.responseType}catch(e){if("json"!==t.responseType)throw e}"function"==typeof t.onDownloadProgress&&d.addEventListener("progress",t.onDownloadProgress),"function"==typeof t.onUploadProgress&&d.upload&&d.upload.addEventListener("progress",t.onUploadProgress),t.cancelToken&&t.cancelToken.promise.then((function(t){d&&(d.abort(),l(t),d=null)})),void 0===p&&(p=null),d.send(p)}))}},function(t,e,n){"use strict";var r=n(299);t.exports=function(t,e,n,o,i){var a=new Error(t);return r(a,e,n,o,i)}},function(t,e,n){"use strict";var r=n(38);t.exports=function(t,e){e=e||{};var n={},o=["url","method","params","data"],i=["headers","auth","proxy"],a=["baseURL","url","transformRequest","transformResponse","paramsSerializer","timeout","withCredentials","adapter","responseType","xsrfCookieName","xsrfHeaderName","onUploadProgress","onDownloadProgress","maxContentLength","validateStatus","maxRedirects","httpAgent","httpsAgent","cancelToken","socketPath"];r.forEach(o,(function(t){void 0!==e[t]&&(n[t]=e[t])})),r.forEach(i,(function(o){r.isObject(e[o])?n[o]=r.deepMerge(t[o],e[o]):void 0!==e[o]?n[o]=e[o]:r.isObject(t[o])?n[o]=r.deepMerge(t[o]):void 0!==t[o]&&(n[o]=t[o])})),r.forEach(a,(function(r){void 0!==e[r]?n[r]=e[r]:void 0!==t[r]&&(n[r]=t[r])}));var s=o.concat(i).concat(a),c=Object.keys(e).filter((function(t){return-1===s.indexOf(t)}));return r.forEach(c,(function(r){void 0!==e[r]?n[r]=e[r]:void 0!==t[r]&&(n[r]=t[r])})),n}},function(t,e,n){"use strict";function r(t){this.message=t}r.prototype.toString=function(){return"Cancel"+(this.message?": "+this.message:"")},r.prototype.__CANCEL__=!0,t.exports=r},function(t,e,n){var r=n(25),o=n(71),i=n(28),a=n(225);t.exports=r?Object.defineProperties:function(t,e){i(t);for(var n,r=a(e),s=r.length,c=0;s>c;)o.f(t,n=r[c++],e[n]);return t}},function(t,e,n){var r=n(271),o=n(204);t.exports=Object.keys||function(t){return r(t,o)}},function(t,e,n){var r=n(33),o=n(101),i=r("iterator"),a=Array.prototype;t.exports=function(t){return void 0!==t&&(o.Array===t||a[i]===t)}},function(t,e,n){var r=n(28);t.exports=function(t){var e=t.return;if(void 0!==e)return r(e.call(t)).value}},function(t,e,n){var r=n(102);t.exports=function(t,e,n){for(var o in e)n&&n.unsafe&&t[o]?t[o]=e[o]:r(t,o,e[o],n);return t}},function(t,e,n){"use strict";var r=n(196).charAt,o=n(104),i=n(214),a=o.set,s=o.getterFor("String Iterator");i(String,"String",(function(t){a(this,{type:"String Iterator",string:String(t),index:0})}),(function(){var t,e=s(this),n=e.string,o=e.index;return o>=n.length?{value:void 0,done:!0}:(t=r(n,o),e.index+=t.length,{value:t,done:!1})}))},function(t,e,n){"use strict";n(191);var r=n(27),o=n(83),i=n(231),a=n(102),s=n(228),c=n(121),u=n(197),l=n(104),p=n(189),h=n(29),d=n(73),f=n(126),g=n(28),v=n(30),m=n(187),y=n(47),b=n(318),w=n(173),x=n(33),_=o("fetch"),O=o("Headers"),S=x("iterator"),j=l.set,k=l.getterFor("URLSearchParams"),A=l.getterFor("URLSearchParamsIterator"),T=/\+/g,E=Array(4),C=function(t){return E[t-1]||(E[t-1]=RegExp("((?:%[\\da-f]{2}){"+t+"})","gi"))},R=function(t){try{return decodeURIComponent(t)}catch(e){return t}},I=function(t){var e=t.replace(T," "),n=4;try{return decodeURIComponent(e)}catch(t){for(;n;)e=e.replace(C(n--),R);return e}},P=/[!'()~]|%20/g,M={"!":"%21","'":"%27","(":"%28",")":"%29","~":"%7E","%20":"+"},L=function(t){return M[t]},N=function(t){return encodeURIComponent(t).replace(P,L)},B=function(t,e){if(e)for(var n,r,o=e.split("&"),i=0;i<o.length;)(n=o[i++]).length&&(r=n.split("="),t.push({key:I(r.shift()),value:I(r.join("="))}))},D=function(t){this.entries.length=0,B(this.entries,t)},U=function(t,e){if(t<e)throw TypeError("Not enough arguments")},$=u((function(t,e){j(this,{type:"URLSearchParamsIterator",iterator:b(k(t).entries),kind:e})}),"Iterator",(function(){var t=A(this),e=t.kind,n=t.iterator.next(),r=n.value;return n.done||(n.value="keys"===e?r.key:"values"===e?r.value:[r.key,r.value]),n})),z=function(){p(this,z,"URLSearchParams");var t,e,n,r,o,i,a,s,c,u=arguments.length>0?arguments[0]:void 0,l=this,d=[];if(j(l,{type:"URLSearchParams",entries:d,updateURL:function(){},updateSearchParams:D}),void 0!==u)if(v(u))if("function"==typeof(t=w(u)))for(n=(e=t.call(u)).next;!(r=n.call(e)).done;){if((a=(i=(o=b(g(r.value))).next).call(o)).done||(s=i.call(o)).done||!i.call(o).done)throw TypeError("Expected sequence with length 2");d.push({key:a.value+"",value:s.value+""})}else for(c in u)h(u,c)&&d.push({key:c,value:u[c]+""});else B(d,"string"==typeof u?"?"===u.charAt(0)?u.slice(1):u:u+"")},V=z.prototype;s(V,{append:function(t,e){U(arguments.length,2);var n=k(this);n.entries.push({key:t+"",value:e+""}),n.updateURL()},delete:function(t){U(arguments.length,1);for(var e=k(this),n=e.entries,r=t+"",o=0;o<n.length;)n[o].key===r?n.splice(o,1):o++;e.updateURL()},get:function(t){U(arguments.length,1);for(var e=k(this).entries,n=t+"",r=0;r<e.length;r++)if(e[r].key===n)return e[r].value;return null},getAll:function(t){U(arguments.length,1);for(var e=k(this).entries,n=t+"",r=[],o=0;o<e.length;o++)e[o].key===n&&r.push(e[o].value);return r},has:function(t){U(arguments.length,1);for(var e=k(this).entries,n=t+"",r=0;r<e.length;)if(e[r++].key===n)return!0;return!1},set:function(t,e){U(arguments.length,1);for(var n,r=k(this),o=r.entries,i=!1,a=t+"",s=e+"",c=0;c<o.length;c++)(n=o[c]).key===a&&(i?o.splice(c--,1):(i=!0,n.value=s));i||o.push({key:a,value:s}),r.updateURL()},sort:function(){var t,e,n,r=k(this),o=r.entries,i=o.slice();for(o.length=0,n=0;n<i.length;n++){for(t=i[n],e=0;e<n;e++)if(o[e].key>t.key){o.splice(e,0,t);break}e===n&&o.push(t)}r.updateURL()},forEach:function(t){for(var e,n=k(this).entries,r=d(t,arguments.length>1?arguments[1]:void 0,3),o=0;o<n.length;)r((e=n[o++]).value,e.key,this)},keys:function(){return new $(this,"keys")},values:function(){return new $(this,"values")},entries:function(){return new $(this,"entries")}},{enumerable:!0}),a(V,S,V.entries),a(V,"toString",(function(){for(var t,e=k(this).entries,n=[],r=0;r<e.length;)t=e[r++],n.push(N(t.key)+"="+N(t.value));return n.join("&")}),{enumerable:!0}),c(z,"URLSearchParams"),r({global:!0,forced:!i},{URLSearchParams:z}),i||"function"!=typeof _||"function"!=typeof O||r({global:!0,enumerable:!0,forced:!0},{fetch:function(t){var e,n,r,o=[t];return arguments.length>1&&(v(e=arguments[1])&&(n=e.body,"URLSearchParams"===f(n)&&((r=e.headers?new O(e.headers):new O).has("content-type")||r.set("content-type","application/x-www-form-urlencoded;charset=UTF-8"),e=m(e,{body:y(0,String(n)),headers:y(0,r)}))),o.push(e)),_.apply(this,o)}}),t.exports={URLSearchParams:z,getState:k}},function(t,e,n){var r=n(19),o=n(33),i=n(96),a=o("iterator");t.exports=!r((function(){var t=new URL("b?a=1&b=2&c=3","http://a"),e=t.searchParams,n="";return t.pathname="c%20d",e.forEach((function(t,r){e.delete("b"),n+=r+t})),i&&!t.toJSON||!e.sort||"http://a/c%20d?a=1&c=3"!==t.href||"3"!==e.get("c")||"a=1"!==String(new URLSearchParams("?a=1"))||!e[a]||"a"!==new URL("https://a@b").username||"b"!==new URLSearchParams(new URLSearchParams("a=b")).get("a")||"xn--e1aybc"!==new URL("http://тест").host||"#%D0%B1"!==new URL("http://a#б").hash||"a1c3"!==n||"x"!==new URL("http://x",void 0).host}))},function(t,e,n){"use strict";var r=n(320),o=n(4),i=n(8),a=n(37),s=n(45),c=n(322),u=n(323),l=n(324),p=n(77),h=n(325),d=r.aTypedArray,f=r.exportTypedArrayMethod,g=o.Uint16Array,v=g&&g.prototype.sort,m=!!v&&!i((function(){var t=new g(2);t.sort(null),t.sort({})})),y=!!v&&!i((function(){if(p)return p<74;if(u)return u<67;if(l)return!0;if(h)return h<602;var t,e,n=new g(516),r=Array(516);for(t=0;t<516;t++)e=t%4,n[t]=515-t,r[t]=t-2*e+3;for(n.sort((function(t,e){return(t/4|0)-(e/4|0)})),t=0;t<516;t++)if(n[t]!==r[t])return!0}));f("sort",(function(t){if(void 0!==t&&a(t),y)return v.call(this,t);d(this);var e,n=s(this.length),r=Array(n);for(e=0;e<n;e++)r[e]=this[e];for(r=c(this,function(t){return function(e,n){return void 0!==t?+t(e,n)||0:n!=n?-1:e!=e?1:0===e&&0===n?1/e>0&&1/n<0?1:-1:e>n}}(t)),e=0;e<n;e++)this[e]=r[e];return this}),!y||m)},function(t,e){t.exports="\t\n\v\f\r                　\u2028\u2029\ufeff"},function(t,e){t.exports="\t\n\v\f\r                　\u2028\u2029\ufeff"},function(t,e,n){"use strict";(function(t){n.d(e,"a",(function(){return d}));n(260),n(18),n(44),n(328);var r=n(236),o=n.n(r),i=/^[A-Za-z][A-Za-z0-9+-.]*:\/\//,a=/^([a-z][a-z0-9.+-]*:)?(\/\/)?([\S\s]*)/i,s=new RegExp("^[\\x09\\x0A\\x0B\\x0C\\x0D\\x20\\xA0\\u1680\\u180E\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200A\\u202F\\u205F\\u3000\\u2028\\u2029\\uFEFF]+");function c(t){return(t||"").toString().replace(s,"")}var u=[["#","hash"],["?","query"],function(t){return t.replace("\\","/")},["/","pathname"],["@","auth",1],[NaN,"host",void 0,1,1],[/:(\d+)$/,"port",void 0,1],[NaN,"hostname",void 0,1,1]],l={hash:1,query:1};function p(e){var n,r=("undefined"!=typeof window?window:void 0!==t?t:"undefined"!=typeof self?self:{}).location||{},o={},a=typeof(e=e||r);if("blob:"===e.protocol)o=new d(unescape(e.pathname),{});else if("string"===a)for(n in o=new d(e,{}),l)delete o[n];else if("object"===a){for(n in e)n in l||(o[n]=e[n]);void 0===o.slashes&&(o.slashes=i.test(e.href))}return o}function h(t){t=c(t);var e=a.exec(t);return{protocol:e[1]?e[1].toLowerCase():"",slashes:!!e[2],rest:e[3]}}function d(t,e){t=c(t);var n,r,i,a,s,l,d=u.slice(),f=this,g=0;for(e=p(e),n=!(r=h(t||"")).protocol&&!r.slashes,f.slashes=r.slashes||n&&e.slashes,f.protocol=r.protocol||e.protocol||"",t=r.rest,r.slashes||(d[3]=[/(.*)/,"pathname"]);g<d.length;g++)"function"!=typeof(a=d[g])?(i=a[0],l=a[1],i!=i?f[l]=t:"string"==typeof i?~(s=t.indexOf(i))&&("number"==typeof a[2]?(f[l]=t.slice(0,s),t=t.slice(s+a[2])):(f[l]=t.slice(s),t=t.slice(0,s))):(s=i.exec(t))&&(f[l]=s[1],t=t.slice(0,s.index)),f[l]=f[l]||n&&a[3]&&e[l]||"",a[4]&&(f[l]=f[l].toLowerCase())):t=a(t);n&&e.slashes&&"/"!==f.pathname.charAt(0)&&(""!==f.pathname||""!==e.pathname)&&(f.pathname=function(t,e){if(""===t)return e;for(var n=(e||"/").split("/").slice(0,-1).concat(t.split("/")),r=n.length,o=n[r-1],i=!1,a=0;r--;)"."===n[r]?n.splice(r,1):".."===n[r]?(n.splice(r,1),a++):a&&(0===r&&(i=!0),n.splice(r,1),a--);return i&&n.unshift(""),"."!==o&&".."!==o||n.push(""),n.join("/")}(f.pathname,e.pathname)),o()(f.port,f.protocol)||(f.host=f.hostname,f.port=""),f.username=f.password="",f.auth&&(a=f.auth.split(":"),f.username=a[0]||"",f.password=a[1]||""),f.origin=f.protocol&&f.host&&"file:"!==f.protocol?f.protocol+"//"+f.host:"null",f.href=f.toString()}d.prototype={toString:function(){var t,e=this,n=e.protocol;n&&":"!==n.charAt(n.length-1)&&(n+=":");var r=n+(e.slashes?"//":"");return e.username&&(r+=e.username,e.password&&(r+=":"+e.password),r+="@"),r+=e.host+e.pathname,(t=e.query)&&(r+="?"!==t.charAt(0)?"?"+t:t),e.hash&&(r+=e.hash),r}},d.extractProtocol=h,d.location=p,d.trimLeft=c}).call(this,n(51))},function(t,e,n){"use strict";t.exports=function(t,e){if(e=e.split(":")[0],!(t=+t))return!1;switch(e){case"http":case"ws":return 80!==t;case"https":case"wss":return 443!==t;case"ftp":return 21!==t;case"gopher":return 70!==t;case"file":return!1}return 0!==t}},function(t,e,n){"use strict";n.d(e,"b",(function(){return s})),n.d(e,"a",(function(){return c}));var r=n(174),o=n(80);
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const i=window.trustedTypes&&trustedTypes.createPolicy("lit-html",{createHTML:t=>t}),a=` ${o.f} `;class s{constructor(t,e,n,r){this.strings=t,this.values=e,this.type=n,this.processor=r}getHTML(){const t=this.strings.length-1;let e="",n=!1;for(let r=0;r<t;r++){const t=this.strings[r],i=t.lastIndexOf("\x3c!--");n=(i>-1||n)&&-1===t.indexOf("--\x3e",i+1);const s=o.e.exec(t);e+=null===s?t+(n?a:o.g):t.substr(0,s.index)+s[1]+s[2]+o.b+s[3]+o.f}return e+=this.strings[t],e}getTemplateElement(){const t=document.createElement("template");let e=this.getHTML();return void 0!==i&&(e=i.createHTML(e)),t.innerHTML=e,t}}class c extends s{getHTML(){return`<svg>${super.getHTML()}</svg>`}getTemplateElement(){const t=super.getTemplateElement(),e=t.content,n=e.firstChild;return e.removeChild(n),Object(r.c)(e,n.firstChild),t}}},function(t,e,n){"use strict";n.d(e,"a",(function(){return o}));n(18);var r=n(239);const o=t=>`<svg\n      class="icon-svg"\n      preserveAspectRatio="xMinYMin meet"\n      viewBox="0,0,90,90"\n      style="background-color:${t.bgColor||"transparent"}; border-radius: var(--svg-radius);display: block;width: 100%;height: 100%;"\n    >\n      <foreignObject width="100%" height="100%">\n          <div\n            style="width:90px;height:90px;display:flex;flex-direction: column;align-items: center;justify-content: center;"\n          >\n            ${t.bgText.split("\n").map(e=>`<p\n                style="line-height:1.1;margin:0;font-size:${t.bgFont}px;color:#ffffff;text-align:center;white-space: nowrap;min-height:4px;flex-shrink: 0;"\n              >\n              ${Object(r.a)(e)}\n              </p>`).join("")}\n        </div>\n      </foreignObject>\n    </svg> `},function(t,e,n){"use strict";n.d(e,"a",(function(){return r}));n(18),n(44);const r=function(t){return(t=""+t).replace(/</g,"&lt;").replace(/>/g,"&gt;")}},function(t,e,n){n(191);var r=n(287),o=n(12),i=n(126),a=n(39),s=n(101),c=n(33)("toStringTag");for(var u in r){var l=o[u],p=l&&l.prototype;p&&i(p)!==c&&a(p,c,u),s[u]=s.Array}},function(t,e){var n=1;function r(t){var e=[];for(var n in t)e.push(encodeURIComponent(n)+"="+encodeURIComponent(t[n]));return e.join("&")}t.exports=function(t){return new Promise((function(e,o){var i=document.createElement("script"),a=t.url;if(t.params){var s=r(t.params);s&&(a+=(a.indexOf("?")>=0?"&":"?")+s)}function c(){i&&(i.onload=i.onreadystatechange=i.onerror=null,i.parentNode&&i.parentNode.removeChild(i),i=null)}i.async=!0;var u="axiosJsonpCallback"+n++,l=window[u],p=!1;window[u]=function(t){(window[u]=l,p)||e({data:t,status:200})};var h={_:(new Date).getTime()};h[t.callbackParamName||"callback"]=u,a+=(a.indexOf("?")>=0?"&":"?")+r(h),i.onload=i.onreadystatechange=function(){i.readyState&&!/loaded|complete/.test(i.readyState)||c()},i.onerror=function(){c(),o(new Error("Network Error"))},t.cancelToken&&t.cancelToken.promise.then((function(t){i&&(p=!0,o(t))})),i.src=a,document.head.appendChild(i)}))}},function(t,e,n){var r=n(468),o=n(473);t.exports=function(t,e){var n=o(t,e);return r(n)?n:void 0}},,function(t,e,n){"use strict";n.d(e,"a",(function(){return i}));var r=n(174),o=n(80);
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
class i{constructor(t,e,n){this.__parts=[],this.template=t,this.processor=e,this.options=n}update(t){let e=0;for(const n of this.__parts)void 0!==n&&n.setValue(t[e]),e++;for(const t of this.__parts)void 0!==t&&t.commit()}_clone(){const t=r.a?this.template.element.content.cloneNode(!0):document.importNode(this.template.element.content,!0),e=[],n=this.template.parts,i=document.createTreeWalker(t,133,null,!1);let a,s=0,c=0,u=i.nextNode();for(;s<n.length;)if(a=n[s],Object(o.d)(a)){for(;c<a.index;)c++,"TEMPLATE"===u.nodeName&&(e.push(u),i.currentNode=u.content),null===(u=i.nextNode())&&(i.currentNode=e.pop(),u=i.nextNode());if("node"===a.type){const t=this.processor.handleTextExpression(this.options);t.insertAfterNode(u.previousSibling),this.__parts.push(t)}else this.__parts.push(...this.processor.handleAttributeExpressions(u,a.name,a.strings,this.options));s++}else this.__parts.push(void 0),s++;return r.a&&(document.adoptNode(t),customElements.upgrade(t)),t}}},function(t,e,n){"use strict";n.d(e,"a",(function(){return s}));var r=n(3);const o=Symbol("LitMobxRenderReaction"),i=Symbol("LitMobxRequestUpdate");var a=n(1);class s extends(function(t){var e,n;return n=class extends t{constructor(){super(...arguments),this[e]=()=>{this.requestUpdate()}}connectedCallback(){super.connectedCallback();const t=this.constructor.name||this.nodeName;this[o]=new r.a(t+".update()",this[i]),this.hasUpdated&&this.requestUpdate()}disconnectedCallback(){super.disconnectedCallback(),this[o]&&(this[o].dispose(),this[o]=void 0)}update(t){this[o]?this[o].track(super.update.bind(this,t)):super.update(t)}},e=i,n}(a.a)){}},function(t,e,n){"use strict";n.d(e,"a",(function(){return u})),n.d(e,"b",(function(){return l}));n(13),n(17),n(10),n(52);var r=n(3),o=n(22),i=n(178),a=function(t,e,n,r){var o,i=arguments.length,a=i<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(t,e,n,r);else for(var s=t.length-1;s>=0;s--)(o=t[s])&&(a=(i<3?o(a):i>3?o(e,n,a):o(e,n))||a);return i>3&&a&&Object.defineProperty(e,n,a),a};const s={},c=new Set;class u{constructor(){this.firstSync=!1,this.syncTabTime=0,this._lockRollback=!1,this.isRollbackFromStorage=!1,this.backupFileKey="",this.backupValueKeys=[],this.rollbackFromStorage=()=>null,this.stopToStorageReaction=()=>{},this.stopAutoBackupReaction=()=>{},this.convertBackupEquals=t=>t}async initSyncStore(t,e,n={},a,c=20){if(s[t])throw new Error("storage key 重复");s[t]=this,0!==e.length&&(this.rollbackFromStorage=async()=>{let i=!1;const s=Object.create(null);Object.keys(n).forEach(t=>{e.includes(t)&&(s[t]=n[t])});try{const n=await Object(o.b)(t,a),r=n?Object.keys(n):[];n&&r.forEach(t=>{e.includes(t)&&(s[t]=n[t])}),this.firstSync||n&&!e.some(t=>!r.includes(t))||(i=!0)}catch(t){console.error("storageSync",t)}this.isRollbackFromStorage=!0,this.stopToStorageReaction(),this.stopAutoBackupReaction(),Object(r.i)(()=>{for(const t in s)this[t]=s[t];this.firstSync||(this.firstSync=!0)}),this.restartAutoBackupReaction(),this.stopToStorageReaction=Object(r.h)(()=>{const t={};return e.forEach(e=>{t[e]=Object(r.j)(this[e])}),t},e=>{this.isRollbackFromStorage=!1,Object(o.e)(t,e,a),Object(r.i)(()=>{this.syncTabTime=Date.now()})},{equals:r.d.structural,delay:c,fireImmediately:i})},await this.rollbackFromStorage(),Object(r.h)(()=>this.syncTabTime,e=>{e&&i.slave.sendMessage("tabs-sync",t)},{delay:60}))}restartAutoBackupReaction(t=!1){this.stopAutoBackupReaction(),this.stopAutoBackupReaction=Object(r.h)(()=>{const t={};return this.backupValueKeys.forEach(e=>{t[e]=Object(r.j)(this[e])}),t},t=>{(async(t,e)=>{try{const{syncStore:r}=await Promise.all([n.e(6),n.e(8),n.e(34)]).then(n.bind(null,574));r.pushAutoBackupPipe({[t]:e})}catch(t){}})(this.backupFileKey,t).catch()},{fireImmediately:t,equals:(t,e)=>{const n=this.convertBackupEquals(t),o=this.convertBackupEquals(e);return r.d.structural(n,o)},delay:40})}initAutoBackup(t,e){if(c.has(t))throw new Error("file key 重复");c.add(t),0!==e.length&&(this.backupFileKey=t,this.backupValueKeys=[...e])}async getBackupData(){const t={};return this.backupValueKeys.forEach(e=>{t[e]=Object(r.j)(this[e])}),t}}a([r.g],u.prototype,"firstSync",void 0),a([r.g],u.prototype,"syncTabTime",void 0),a([r.b],u.prototype,"initSyncStore",null);const l=t=>{const e=s[t];(null==e?void 0:e._lockRollback)||e.rollbackFromStorage()}},function(t,e,n){"use strict";n.d(e,"a",(function(){return u}));n(10),n(13),n(17),n(52);var r=n(0),o=n(398),i=n(48),a=n.n(i),s=n(5);var c=n(81);const u=new class{constructor(){this.ga=null,this.localKey="analytics-status-time",this.gap=432e5,this.getPermission=async()=>{let t=!0;if(r.n)try{const{privacyStore:e}=await Promise.all([n.e(6),n.e(8),n.e(33)]).then(n.bind(null,581));1!==e.collectData&&(t=!1)}catch(e){t=!1}return t},this.trySendStatus=t=>{const e=localStorage.getItem(this.localKey);e?(Date.now()-Number(e)>this.gap||Number(e)>Date.now())&&this.sendStatus(t):this.sendStatus(t)},this.sendPageView=async t=>{if(!await this.getPermission())return;const e=this.ga.getPageviewUrl(t);c.c.sendLog(e)},this.sendEvent=async(t,e=!1)=>{await this.getPermission()&&Object.keys(t).forEach(n=>{const r=t[n];if("object"==typeof r)Object.keys(r).forEach(t=>{const o=r[t],i=this.ga.getEventUrl({category:n,action:t,label:String(o),nonInteraction:e});c.c.sendLog(i)});else{const t=this.ga.getEventUrl({category:n,action:String(r),nonInteraction:e});c.c.sendLog(t)}})},this.sendBaidu=async t=>{await this.getPermission()&&(async(t="")=>{const e=r.C.runtimePlatform;if(null==t?void 0:t.includes("baidu.com")){const n=new a.a(t).searchParams.get("tn"),o=`https://manage-api.infinitytab.com/analysis-manager/send/60efd763a741942ac60374e1?label=${r.B.baiduLabel}&action=${n}&event=${e}`;r.r?navigator.sendBeacon(o):s.a.post(o,null,{_proxy:!0})}})(t)},this.ga=new o.a({trackingId:r.B.trackingId})}async sendStatus(t){try{this.sendEvent(t,!0),localStorage.setItem(this.localKey,""+Date.now())}catch(t){}}}},function(t,e,n){"use strict";var r=n(19);t.exports=function(t,e){var n=[][t];return!!n&&r((function(){n.call(null,e||function(){throw 1},1)}))}},function(t,e,n){"use strict";var r=n(46),o=n(20),i=n(4),a=n(11),s=n(16),c=n(21).f,u=n(124),l=i.Symbol;if(o&&"function"==typeof l&&(!("description"in l.prototype)||void 0!==l().description)){var p={},h=function(){var t=arguments.length<1||void 0===arguments[0]?void 0:String(arguments[0]),e=this instanceof h?new l(t):void 0===t?l():l(t);return""===t&&(p[e]=!0),e};u(h,l);var d=h.prototype=l.prototype;d.constructor=h;var f=d.toString,g="Symbol(test)"==String(l("test")),v=/^Symbol\((.*)\)[^)]+$/;c(d,"description",{configurable:!0,get:function(){var t=s(this)?this.valueOf():this,e=f.call(t);if(a(p,t))return"";var n=g?e.slice(7,-1):e.replace(v,"$1");return""===n?void 0:n}}),r({global:!0,forced:!0},{Symbol:h})}},function(t,e,n){"use strict";n.d(e,"a",(function(){return r}));const r=t=>{const e=o(t),n=i(t,e);return{searchWidth:e.width,searchHeight:e.height,searchMarginTop:e.marginTop,searchMarginBottom:e.marginBottom,searchRatio:e.searchRatio,iconBoxWidth:n.boxWidth,iconBoxHeight:n.boxHeight,iconOneHeight:n.iconOneHeight,iconWidth:n.width,miniIconPadding:n.miniIconPadding,iconRatio:n.iconRatio,iconsMargin:n.iconsMargin}},o=t=>{const{searchScale:e,innerHeight:n,innerWidth:r,miniMode:o,topBookmark:i,topUseful:a,mainRatio:s}=t;let c=0;a&&(c+=36),i&&(c+=36);const u=n-c,l=r-.2*r;let p=r,h=9*p/16;h>u&&(h=u,p=16*h/9);const d=p*(.575-.1818*Math.max(Math.min(720,p-1200),0)/720),f={width:d*e,height:h*(.0963-.0296*Math.max(Math.min(405,h-675),0)/405)*e};f.width>l&&(f.height=l/f.width*f.height,f.width=l);const g={width:f.width*s,height:f.height*s};let v=null;v=o?-.3:-.06;const m=f.width/d*s,y=Math.floor(v*u*m)+"px",b=Math.floor(.775*g.height)+"px";return{width:Math.floor(g.width)+"px",height:Math.floor(g.height)+"px",searchRatio:Number((g.width/625).toFixed(2)),marginTop:y,marginBottom:b,appContentWidth:l,appContentHeight:u,searcherSizeWithRatio:f}},i=(t,e)=>{const{row:n,col:r,rowGap:o,colGap:i,iconScale:a,innerWidth:s,mainRatio:c,fontSize:u}=t;let l=s;l<1200?l=1200:l>1920&&(l=1920);const{appContentHeight:p,appContentWidth:h,searcherSizeWithRatio:d}=e,f=h,g=.8*p-2.451*d.height,v=1+.5*(1920-l)/720,m=f/r,y=g/n,b=Math.min(Math.min(m,y)*a*v,m,y),w=(g-n*b)/n*o/2,x=r*(b+2*((f-r*b)/r*i/2));let _=Math.min(Math.ceil(x*c),s);let O=n*(b+2*w)*c;const S=b*c,j=1.3*Math.max(u*c,12)+.9*S*.08,k=1.2*(25+j);_<r*k&&(_=r*k),O<n*k&&(O=n*k);let A=.9*S-j-1;A<25&&(A=25);const T=.1*s*c;return{width:Math.floor(A)+"px",miniIconPadding:Math.floor(A/7+4)+"px",boxWidth:Math.ceil(_)+"px",boxHeight:Math.floor(O)+"px",iconOneHeight:Math.floor(O/n)+"px",iconRatio:Number((A/106).toFixed(2)),iconsMargin:Math.floor(T)+"px"}}},function(t,e,n){t.exports=n(363)},function(t,e,n){var r=n(49),o=n(72),i=n(99),a=n(128),s=function(t){return function(e,n,s,c){r(n);var u=o(e),l=i(u),p=a(u.length),h=t?p-1:0,d=t?-1:1;if(s<2)for(;;){if(h in l){c=l[h],h+=d;break}if(h+=d,t?h<0:p<=h)throw TypeError("Reduce of empty array with no initial value")}for(;t?h>=0:p>h;h+=d)h in l&&(c=n(c,l[h],h,u));return c}};t.exports={left:s(!1),right:s(!0)}},,,,,function(t,e,n){"use strict";n.r(e),n.d(e,"uploadFile",(function(){return s}));n(10);var r=n(0),o=n(5);const i=["infinity-notes-img","custom-wallpaper-library"],a={},s=async(t,e,n)=>{let s;try{if(a[n]&&a[n].endTime>Date.now())s=a[n];else{let t=null;if(t=i.includes(n)?await o.a.get(r.x+"/upload/public_private_token",{type:n},{_auth:!0}):await o.a.get(r.x+"/upload/token",{type:n}),0!==t.code||!t.data.token)return{error:t};s=t.data,s.endTime=Date.now()+1e3*(s.expires-600),a[n]=s}const{token:c,prefix:u}=s,l=new FormData;l.append("token",c),l.append("key",u+e),l.append("file",t,e);const{key:p,url:h}=await o.a.post(s.host,l,{timeout:18e4,headers:{"Content-Type":"multipart/form-data"}});return{data:{url:h,key:p}}}catch(t){return{error:t}}}},function(t,e){var n={utf8:{stringToBytes:function(t){return n.bin.stringToBytes(unescape(encodeURIComponent(t)))},bytesToString:function(t){return decodeURIComponent(escape(n.bin.bytesToString(t)))}},bin:{stringToBytes:function(t){for(var e=[],n=0;n<t.length;n++)e.push(255&t.charCodeAt(n));return e},bytesToString:function(t){for(var e=[],n=0;n<t.length;n++)e.push(String.fromCharCode(t[n]));return e.join("")}}};t.exports=n},function(t,e,n){"use strict";n.d(e,"a",(function(){return r}));n(13),n(17);class r{constructor(){this._events=new Map}listenTask(t,e){if("function"!=typeof e)return;this._events.has(t)||this._events.set(t,new Set);this._events.get(t).add(e)}execTask(t,e,...n){if(this._events.has(t)){const r=this._events.get(t);for(const t of r)t(e,...n)}}}},function(t,e,n){var r=n(20),o=n(4),i=n(76),a=n(326),s=n(15),c=n(21).f,u=n(112).f,l=n(327),p=n(115),h=n(116),d=n(24),f=n(8),g=n(11),v=n(36).enforce,m=n(113),y=n(6),b=n(117),w=n(118),x=y("match"),_=o.RegExp,O=_.prototype,S=/^\?<[^\s\d!#%&*+<=>@^][^\s!#%&*+<=>@^]*>/,j=/a/g,k=/a/g,A=new _(j)!==j,T=h.UNSUPPORTED_Y,E=r&&(!A||T||b||w||f((function(){return k[x]=!1,_(j)!=j||_(k)==k||"/a/i"!=_(j,"i")})));if(i("RegExp",E)){for(var C=function(t,e){var n,r,o,i,c,u,h=this instanceof C,d=l(t),f=void 0===e,m=[],y=t;if(!h&&d&&f&&t.constructor===C)return t;if((d||t instanceof C)&&(t=t.source,f&&(e="flags"in y?y.flags:p.call(y))),t=void 0===t?"":String(t),e=void 0===e?"":String(e),y=t,b&&"dotAll"in j&&(r=!!e&&e.indexOf("s")>-1)&&(e=e.replace(/s/g,"")),n=e,T&&"sticky"in j&&(o=!!e&&e.indexOf("y")>-1)&&(e=e.replace(/y/g,"")),w&&(t=(i=function(t){for(var e,n=t.length,r=0,o="",i=[],a={},s=!1,c=!1,u=0,l="";r<=n;r++){if("\\"===(e=t.charAt(r)))e+=t.charAt(++r);else if("]"===e)s=!1;else if(!s)switch(!0){case"["===e:s=!0;break;case"("===e:S.test(t.slice(r+1))&&(r+=2,c=!0),o+=e,u++;continue;case">"===e&&c:if(""===l||g(a,l))throw new SyntaxError("Invalid capture group name");a[l]=!0,i.push([l,u]),c=!1,l="";continue}c?l+=e:o+=e}return[o,i]}(t))[0],m=i[1]),c=a(_(t,e),h?this:O,C),(r||o||m.length)&&(u=v(c),r&&(u.dotAll=!0,u.raw=C(function(t){for(var e,n=t.length,r=0,o="",i=!1;r<=n;r++)"\\"!==(e=t.charAt(r))?i||"."!==e?("["===e?i=!0:"]"===e&&(i=!1),o+=e):o+="[\\s\\S]":o+=e+t.charAt(++r);return o}(t),n)),o&&(u.sticky=!0),m.length&&(u.groups=m)),t!==y)try{s(c,"source",""===y?"(?:)":y)}catch(t){}return c},R=function(t){t in C||c(C,t,{configurable:!0,get:function(){return _[t]},set:function(e){_[t]=e}})},I=u(_),P=0;I.length>P;)R(I[P++]);O.constructor=C,C.prototype=O,d(o,"RegExp",C)}m("RegExp")},function(t,e,n){"use strict";var r=n(262).forEach,o=n(265)("forEach");t.exports=o?[].forEach:function(t){return r(this,t,arguments.length>1?arguments[1]:void 0)}},function(t,e,n){var r=n(74),o=n(108),i=n(50),a=n(45),s=n(263),c=[].push,u=function(t){var e=1==t,n=2==t,u=3==t,l=4==t,p=6==t,h=7==t,d=5==t||p;return function(f,g,v,m){for(var y,b,w=i(f),x=o(w),_=r(g,v,3),O=a(x.length),S=0,j=m||s,k=e?j(f,O):n||h?j(f,0):void 0;O>S;S++)if((d||S in x)&&(b=_(y=x[S],S,w),t))if(e)k[S]=b;else if(b)switch(t){case 3:return!0;case 5:return y;case 6:return S;case 2:c.call(k,y)}else switch(t){case 4:return!1;case 7:c.call(k,y)}return p?-1:u||l?l:k}};t.exports={forEach:u(0),map:u(1),filter:u(2),some:u(3),every:u(4),find:u(5),findIndex:u(6),filterOut:u(7)}},function(t,e,n){var r=n(16),o=n(264),i=n(6)("species");t.exports=function(t,e){var n;return o(t)&&("function"!=typeof(n=t.constructor)||n!==Array&&!o(n.prototype)?r(n)&&null===(n=n[i])&&(n=void 0):n=void 0),new(void 0===n?Array:n)(0===e?0:e)}},function(t,e,n){var r=n(34);t.exports=Array.isArray||function(t){return"Array"==r(t)}},function(t,e,n){"use strict";var r=n(8);t.exports=function(t,e){var n=[][t];return!!n&&r((function(){n.call(null,e||function(){throw 1},1)}))}},function(t,e,n){var r=n(267);n(288),n(289),n(290),n(291),t.exports=r},function(t,e,n){n(201),n(275),n(276),n(212),n(213),n(285),n(229),n(240);var r=n(70);t.exports=r.Promise},function(t,e,n){var r=n(12),o=n(39);t.exports=function(t,e){try{o(r,t,e)}catch(n){r[t]=e}return e}},function(t,e,n){var r=n(19);t.exports=!r((function(){function t(){}return t.prototype.constructor=null,Object.getPrototypeOf(new t)!==t.prototype}))},function(t,e,n){var r=n(30);t.exports=function(t){if(!r(t)&&null!==t)throw TypeError("Can't set "+String(t)+" as a prototype");return t}},function(t,e,n){var r=n(29),o=n(82),i=n(272).indexOf,a=n(185);t.exports=function(t,e){var n,s=o(t),c=0,u=[];for(n in s)!r(a,n)&&r(s,n)&&u.push(n);for(;e.length>c;)r(s,n=e[c++])&&(~i(u,n)||u.push(n));return u}},function(t,e,n){var r=n(82),o=n(128),i=n(273),a=function(t){return function(e,n,a){var s,c=r(e),u=o(c.length),l=i(a,u);if(t&&n!=n){for(;u>l;)if((s=c[l++])!=s)return!0}else for(;u>l;l++)if((t||l in c)&&c[l]===n)return t||l||0;return!t&&-1}};t.exports={includes:a(!0),indexOf:a(!1)}},function(t,e,n){var r=n(184),o=Math.max,i=Math.min;t.exports=function(t,e){var n=r(t);return n<0?o(n+e,0):i(n,e)}},function(t,e,n){var r=n(206);t.exports=r&&!Symbol.sham&&"symbol"==typeof Symbol.iterator},function(t,e){},function(t,e,n){"use strict";var r,o,i,a,s=n(27),c=n(96),u=n(12),l=n(83),p=n(207),h=n(102),d=n(228),f=n(183),g=n(121),v=n(278),m=n(30),y=n(49),b=n(189),w=n(208),x=n(171),_=n(279),O=n(195),S=n(209).set,j=n(280),k=n(211),A=n(282),T=n(120),E=n(172),C=n(104),R=n(111),I=n(33),P=n(284),M=n(129),L=n(176),N=I("species"),B="Promise",D=C.get,U=C.set,$=C.getterFor(B),z=p&&p.prototype,V=p,q=z,F=u.TypeError,H=u.document,W=u.process,G=T.f,X=G,Y=!!(H&&H.createEvent&&u.dispatchEvent),K="function"==typeof PromiseRejectionEvent,J=!1,Q=R(B,(function(){var t=w(V),e=t!==String(V);if(!e&&66===L)return!0;if(c&&!q.finally)return!0;if(L>=51&&/native code/.test(t))return!1;var n=new V((function(t){t(1)})),r=function(t){t((function(){}),(function(){}))};return(n.constructor={})[N]=r,!(J=n.then((function(){}))instanceof r)||!e&&P&&!K})),Z=Q||!_((function(t){V.all(t).catch((function(){}))})),tt=function(t){var e;return!(!m(t)||"function"!=typeof(e=t.then))&&e},et=function(t,e){if(!t.notified){t.notified=!0;var n=t.reactions;j((function(){for(var r=t.value,o=1==t.state,i=0;n.length>i;){var a,s,c,u=n[i++],l=o?u.ok:u.fail,p=u.resolve,h=u.reject,d=u.domain;try{l?(o||(2===t.rejection&&it(t),t.rejection=1),!0===l?a=r:(d&&d.enter(),a=l(r),d&&(d.exit(),c=!0)),a===u.promise?h(F("Promise-chain cycle")):(s=tt(a))?s.call(a,p,h):p(a)):h(r)}catch(t){d&&!c&&d.exit(),h(t)}}t.reactions=[],t.notified=!1,e&&!t.rejection&&rt(t)}))}},nt=function(t,e,n){var r,o;Y?((r=H.createEvent("Event")).promise=e,r.reason=n,r.initEvent(t,!1,!0),u.dispatchEvent(r)):r={promise:e,reason:n},!K&&(o=u["on"+t])?o(r):"unhandledrejection"===t&&A("Unhandled promise rejection",n)},rt=function(t){S.call(u,(function(){var e,n=t.facade,r=t.value;if(ot(t)&&(e=E((function(){M?W.emit("unhandledRejection",r,n):nt("unhandledrejection",n,r)})),t.rejection=M||ot(t)?2:1,e.error))throw e.value}))},ot=function(t){return 1!==t.rejection&&!t.parent},it=function(t){S.call(u,(function(){var e=t.facade;M?W.emit("rejectionHandled",e):nt("rejectionhandled",e,t.value)}))},at=function(t,e,n){return function(r){t(e,r,n)}},st=function(t,e,n){t.done||(t.done=!0,n&&(t=n),t.value=e,t.state=2,et(t,!0))},ct=function(t,e,n){if(!t.done){t.done=!0,n&&(t=n);try{if(t.facade===e)throw F("Promise can't be resolved itself");var r=tt(e);r?j((function(){var n={done:!1};try{r.call(e,at(ct,n,t),at(st,n,t))}catch(e){st(n,e,t)}})):(t.value=e,t.state=1,et(t,!1))}catch(e){st({done:!1},e,t)}}};if(Q&&(q=(V=function(t){b(this,V,B),y(t),r.call(this);var e=D(this);try{t(at(ct,e),at(st,e))}catch(t){st(e,t)}}).prototype,(r=function(t){U(this,{type:B,done:!1,notified:!1,parent:!1,reactions:[],rejection:!1,state:0,value:void 0})}).prototype=d(q,{then:function(t,e){var n=$(this),r=G(O(this,V));return r.ok="function"!=typeof t||t,r.fail="function"==typeof e&&e,r.domain=M?W.domain:void 0,n.parent=!0,n.reactions.push(r),0!=n.state&&et(n,!1),r.promise},catch:function(t){return this.then(void 0,t)}}),o=function(){var t=new r,e=D(t);this.promise=t,this.resolve=at(ct,e),this.reject=at(st,e)},T.f=G=function(t){return t===V||t===i?new o(t):X(t)},!c&&"function"==typeof p&&z!==Object.prototype)){a=z.then,J||(h(z,"then",(function(t,e){var n=this;return new V((function(t,e){a.call(n,t,e)})).then(t,e)}),{unsafe:!0}),h(z,"catch",q.catch,{unsafe:!0}));try{delete z.constructor}catch(t){}f&&f(z,q)}s({global:!0,wrap:!0,forced:Q},{Promise:V}),g(V,B,!1,!0),v(B),i=l(B),s({target:B,stat:!0,forced:Q},{reject:function(t){var e=G(this);return e.reject.call(void 0,t),e.promise}}),s({target:B,stat:!0,forced:c||Q},{resolve:function(t){return k(c&&this===i?V:this,t)}}),s({target:B,stat:!0,forced:Z},{all:function(t){var e=this,n=G(e),r=n.resolve,o=n.reject,i=E((function(){var n=y(e.resolve),i=[],a=0,s=1;x(t,(function(t){var c=a++,u=!1;i.push(void 0),s++,n.call(e,t).then((function(t){u||(u=!0,i[c]=t,--s||r(i))}),o)})),--s||r(i)}));return i.error&&o(i.value),n.promise},race:function(t){var e=this,n=G(e),r=n.reject,o=E((function(){var o=y(e.resolve);x(t,(function(t){o.call(e,t).then(n.resolve,r)}))}));return o.error&&r(o.value),n.promise}})},function(t,e,n){"use strict";var r=n(186),o=n(126);t.exports=r?{}.toString:function(){return"[object "+o(this)+"]"}},function(t,e,n){"use strict";var r=n(83),o=n(71),i=n(33),a=n(25),s=i("species");t.exports=function(t){var e=r(t),n=o.f;a&&e&&!e[s]&&n(e,s,{configurable:!0,get:function(){return this}})}},function(t,e,n){var r=n(33)("iterator"),o=!1;try{var i=0,a={next:function(){return{done:!!i++}},return:function(){o=!0}};a[r]=function(){return this},Array.from(a,(function(){throw 2}))}catch(t){}t.exports=function(t,e){if(!e&&!o)return!1;var n=!1;try{var i={};i[r]=function(){return{next:function(){return{done:n=!0}}}},t(i)}catch(t){}return n}},function(t,e,n){var r,o,i,a,s,c,u,l,p=n(12),h=n(110).f,d=n(209).set,f=n(210),g=n(281),v=n(129),m=p.MutationObserver||p.WebKitMutationObserver,y=p.document,b=p.process,w=p.Promise,x=h(p,"queueMicrotask"),_=x&&x.value;_||(r=function(){var t,e;for(v&&(t=b.domain)&&t.exit();o;){e=o.fn,o=o.next;try{e()}catch(t){throw o?a():i=void 0,t}}i=void 0,t&&t.enter()},f||v||g||!m||!y?w&&w.resolve?((u=w.resolve(void 0)).constructor=w,l=u.then,a=function(){l.call(u,r)}):a=v?function(){b.nextTick(r)}:function(){d.call(p,r)}:(s=!0,c=y.createTextNode(""),new m(r).observe(c,{characterData:!0}),a=function(){c.data=s=!s})),t.exports=_||function(t){var e={fn:t,next:void 0};i&&(i.next=e),o||(o=e,a()),i=e}},function(t,e,n){var r=n(179);t.exports=/web0s(?!.*chrome)/i.test(r)},function(t,e,n){var r=n(12);t.exports=function(t,e){var n=r.console;n&&n.error&&(1===arguments.length?n.error(t):n.error(t,e))}},function(t,e,n){var r=n(12),o=n(208),i=r.WeakMap;t.exports="function"==typeof i&&/native code/.test(o(i))},function(t,e){t.exports="object"==typeof window},function(t,e,n){"use strict";var r=n(27),o=n(96),i=n(207),a=n(19),s=n(83),c=n(195),u=n(211),l=n(102);if(r({target:"Promise",proto:!0,real:!0,forced:!!i&&a((function(){i.prototype.finally.call({then:function(){}},(function(){}))}))},{finally:function(t){var e=c(this,s("Promise")),n="function"==typeof t;return this.then(n?function(n){return u(e,t()).then((function(){return n}))}:t,n?function(n){return u(e,t()).then((function(){throw n}))}:t)}}),!o&&"function"==typeof i){var p=s("Promise").prototype.finally;i.prototype.finally!==p&&l(i.prototype,"finally",p,{unsafe:!0})}},function(t,e){t.exports=function(){}},function(t,e){t.exports={CSSRuleList:0,CSSStyleDeclaration:0,CSSValueList:0,ClientRectList:0,DOMRectList:0,DOMStringList:0,DOMTokenList:1,DataTransferItemList:0,FileList:0,HTMLAllCollection:0,HTMLCollection:0,HTMLFormElement:0,HTMLSelectElement:0,MediaList:0,MimeTypeArray:0,NamedNodeMap:0,NodeList:1,PaintRequestList:0,Plugin:0,PluginArray:0,SVGLengthList:0,SVGNumberList:0,SVGPathSegList:0,SVGPointList:0,SVGStringList:0,SVGTransformList:0,SourceBufferList:0,StyleSheetList:0,TextTrackCueList:0,TextTrackList:0,TouchList:0}},function(t,e,n){n(201)},function(t,e,n){n(212)},function(t,e,n){"use strict";var r=n(27),o=n(120),i=n(172);r({target:"Promise",stat:!0},{try:function(t){var e=o.f(this),n=i(t);return(n.error?e.reject:e.resolve)(n.value),e.promise}})},function(t,e,n){n(213)},function(t,e,n){"use strict";var r=n(38),o=n(216),i=n(293),a=n(222);function s(t){var e=new i(t),n=o(i.prototype.request,e);return r.extend(n,i.prototype,e),r.extend(n,e),n}var c=s(n(219));c.Axios=i,c.create=function(t){return s(a(c.defaults,t))},c.Cancel=n(223),c.CancelToken=n(306),c.isCancel=n(218),c.all=function(t){return Promise.all(t)},c.spread=n(307),t.exports=c,t.exports.default=c},function(t,e,n){"use strict";var r=n(38),o=n(217),i=n(294),a=n(295),s=n(222);function c(t){this.defaults=t,this.interceptors={request:new i,response:new i}}c.prototype.request=function(t){"string"==typeof t?(t=arguments[1]||{}).url=arguments[0]:t=t||{},(t=s(this.defaults,t)).method?t.method=t.method.toLowerCase():this.defaults.method?t.method=this.defaults.method.toLowerCase():t.method="get";var e=[a,void 0],n=Promise.resolve(t);for(this.interceptors.request.forEach((function(t){e.unshift(t.fulfilled,t.rejected)})),this.interceptors.response.forEach((function(t){e.push(t.fulfilled,t.rejected)}));e.length;)n=n.then(e.shift(),e.shift());return n},c.prototype.getUri=function(t){return t=s(this.defaults,t),o(t.url,t.params,t.paramsSerializer).replace(/^\?/,"")},r.forEach(["delete","get","head","options"],(function(t){c.prototype[t]=function(e,n){return this.request(r.merge(n||{},{method:t,url:e}))}})),r.forEach(["post","put","patch"],(function(t){c.prototype[t]=function(e,n,o){return this.request(r.merge(o||{},{method:t,url:e,data:n}))}})),t.exports=c},function(t,e,n){"use strict";var r=n(38);function o(){this.handlers=[]}o.prototype.use=function(t,e){return this.handlers.push({fulfilled:t,rejected:e}),this.handlers.length-1},o.prototype.eject=function(t){this.handlers[t]&&(this.handlers[t]=null)},o.prototype.forEach=function(t){r.forEach(this.handlers,(function(e){null!==e&&t(e)}))},t.exports=o},function(t,e,n){"use strict";var r=n(38),o=n(296),i=n(218),a=n(219);function s(t){t.cancelToken&&t.cancelToken.throwIfRequested()}t.exports=function(t){return s(t),t.headers=t.headers||{},t.data=o(t.data,t.headers,t.transformRequest),t.headers=r.merge(t.headers.common||{},t.headers[t.method]||{},t.headers),r.forEach(["delete","get","head","post","put","patch","common"],(function(e){delete t.headers[e]})),(t.adapter||a.adapter)(t).then((function(e){return s(t),e.data=o(e.data,e.headers,t.transformResponse),e}),(function(e){return i(e)||(s(t),e&&e.response&&(e.response.data=o(e.response.data,e.response.headers,t.transformResponse))),Promise.reject(e)}))}},function(t,e,n){"use strict";var r=n(38);t.exports=function(t,e,n){return r.forEach(n,(function(n){t=n(t,e)})),t}},function(t,e,n){"use strict";var r=n(38);t.exports=function(t,e){r.forEach(t,(function(n,r){r!==e&&r.toUpperCase()===e.toUpperCase()&&(t[e]=n,delete t[r])}))}},function(t,e,n){"use strict";var r=n(221);t.exports=function(t,e,n){var o=n.config.validateStatus;!o||o(n.status)?t(n):e(r("Request failed with status code "+n.status,n.config,null,n.request,n))}},function(t,e,n){"use strict";t.exports=function(t,e,n,r,o){return t.config=e,n&&(t.code=n),t.request=r,t.response=o,t.isAxiosError=!0,t.toJSON=function(){return{message:this.message,name:this.name,description:this.description,number:this.number,fileName:this.fileName,lineNumber:this.lineNumber,columnNumber:this.columnNumber,stack:this.stack,config:this.config,code:this.code}},t}},function(t,e,n){"use strict";var r=n(301),o=n(302);t.exports=function(t,e){return t&&!r(e)?o(t,e):e}},function(t,e,n){"use strict";t.exports=function(t){return/^([a-z][a-z\d\+\-\.]*:)?\/\//i.test(t)}},function(t,e,n){"use strict";t.exports=function(t,e){return e?t.replace(/\/+$/,"")+"/"+e.replace(/^\/+/,""):t}},function(t,e,n){"use strict";var r=n(38),o=["age","authorization","content-length","content-type","etag","expires","from","host","if-modified-since","if-unmodified-since","last-modified","location","max-forwards","proxy-authorization","referer","retry-after","user-agent"];t.exports=function(t){var e,n,i,a={};return t?(r.forEach(t.split("\n"),(function(t){if(i=t.indexOf(":"),e=r.trim(t.substr(0,i)).toLowerCase(),n=r.trim(t.substr(i+1)),e){if(a[e]&&o.indexOf(e)>=0)return;a[e]="set-cookie"===e?(a[e]?a[e]:[]).concat([n]):a[e]?a[e]+", "+n:n}})),a):a}},function(t,e,n){"use strict";var r=n(38);t.exports=r.isStandardBrowserEnv()?function(){var t,e=/(msie|trident)/i.test(navigator.userAgent),n=document.createElement("a");function o(t){var r=t;return e&&(n.setAttribute("href",r),r=n.href),n.setAttribute("href",r),{href:n.href,protocol:n.protocol?n.protocol.replace(/:$/,""):"",host:n.host,search:n.search?n.search.replace(/^\?/,""):"",hash:n.hash?n.hash.replace(/^#/,""):"",hostname:n.hostname,port:n.port,pathname:"/"===n.pathname.charAt(0)?n.pathname:"/"+n.pathname}}return t=o(window.location.href),function(e){var n=r.isString(e)?o(e):e;return n.protocol===t.protocol&&n.host===t.host}}():function(){return!0}},function(t,e,n){"use strict";var r=n(38);t.exports=r.isStandardBrowserEnv()?{write:function(t,e,n,o,i,a){var s=[];s.push(t+"="+encodeURIComponent(e)),r.isNumber(n)&&s.push("expires="+new Date(n).toGMTString()),r.isString(o)&&s.push("path="+o),r.isString(i)&&s.push("domain="+i),!0===a&&s.push("secure"),document.cookie=s.join("; ")},read:function(t){var e=document.cookie.match(new RegExp("(^|;\\s*)("+t+")=([^;]*)"));return e?decodeURIComponent(e[3]):null},remove:function(t){this.write(t,"",Date.now()-864e5)}}:{write:function(){},read:function(){return null},remove:function(){}}},function(t,e,n){"use strict";var r=n(223);function o(t){if("function"!=typeof t)throw new TypeError("executor must be a function.");var e;this.promise=new Promise((function(t){e=t}));var n=this;t((function(t){n.reason||(n.reason=new r(t),e(n.reason))}))}o.prototype.throwIfRequested=function(){if(this.reason)throw this.reason},o.source=function(){var t;return{token:new o((function(e){t=e})),cancel:t}},t.exports=o},function(t,e,n){"use strict";t.exports=function(t){return function(e){return t.apply(null,e)}}},function(t,e,n){var r=n(309);t.exports=r},function(t,e,n){var r=n(310);t.exports=r},function(t,e,n){n(311),n(319),n(230);var r=n(70);t.exports=r.URL},function(t,e,n){"use strict";n(229);var r,o=n(27),i=n(25),a=n(231),s=n(12),c=n(224),u=n(102),l=n(189),p=n(29),h=n(312),d=n(314),f=n(196).codeAt,g=n(317),v=n(121),m=n(230),y=n(104),b=s.URL,w=m.URLSearchParams,x=m.getState,_=y.set,O=y.getterFor("URL"),S=Math.floor,j=Math.pow,k=/[A-Za-z]/,A=/[\d+-.A-Za-z]/,T=/\d/,E=/^0x/i,C=/^[0-7]+$/,R=/^\d+$/,I=/^[\dA-Fa-f]+$/,P=/[\0\t\n\r #%/:<>?@[\\\]^|]/,M=/[\0\t\n\r #/:<>?@[\\\]^|]/,L=/^[\u0000-\u001F ]+|[\u0000-\u001F ]+$/g,N=/[\t\n\r]/g,B=function(t,e){var n,r,o;if("["==e.charAt(0)){if("]"!=e.charAt(e.length-1))return"Invalid host";if(!(n=U(e.slice(1,-1))))return"Invalid host";t.host=n}else if(G(t)){if(e=g(e),P.test(e))return"Invalid host";if(null===(n=D(e)))return"Invalid host";t.host=n}else{if(M.test(e))return"Invalid host";for(n="",r=d(e),o=0;o<r.length;o++)n+=H(r[o],z);t.host=n}},D=function(t){var e,n,r,o,i,a,s,c=t.split(".");if(c.length&&""==c[c.length-1]&&c.pop(),(e=c.length)>4)return t;for(n=[],r=0;r<e;r++){if(""==(o=c[r]))return t;if(i=10,o.length>1&&"0"==o.charAt(0)&&(i=E.test(o)?16:8,o=o.slice(8==i?1:2)),""===o)a=0;else{if(!(10==i?R:8==i?C:I).test(o))return t;a=parseInt(o,i)}n.push(a)}for(r=0;r<e;r++)if(a=n[r],r==e-1){if(a>=j(256,5-e))return null}else if(a>255)return null;for(s=n.pop(),r=0;r<n.length;r++)s+=n[r]*j(256,3-r);return s},U=function(t){var e,n,r,o,i,a,s,c=[0,0,0,0,0,0,0,0],u=0,l=null,p=0,h=function(){return t.charAt(p)};if(":"==h()){if(":"!=t.charAt(1))return;p+=2,l=++u}for(;h();){if(8==u)return;if(":"!=h()){for(e=n=0;n<4&&I.test(h());)e=16*e+parseInt(h(),16),p++,n++;if("."==h()){if(0==n)return;if(p-=n,u>6)return;for(r=0;h();){if(o=null,r>0){if(!("."==h()&&r<4))return;p++}if(!T.test(h()))return;for(;T.test(h());){if(i=parseInt(h(),10),null===o)o=i;else{if(0==o)return;o=10*o+i}if(o>255)return;p++}c[u]=256*c[u]+o,2!=++r&&4!=r||u++}if(4!=r)return;break}if(":"==h()){if(p++,!h())return}else if(h())return;c[u++]=e}else{if(null!==l)return;p++,l=++u}}if(null!==l)for(a=u-l,u=7;0!=u&&a>0;)s=c[u],c[u--]=c[l+a-1],c[l+--a]=s;else if(8!=u)return;return c},$=function(t){var e,n,r,o;if("number"==typeof t){for(e=[],n=0;n<4;n++)e.unshift(t%256),t=S(t/256);return e.join(".")}if("object"==typeof t){for(e="",r=function(t){for(var e=null,n=1,r=null,o=0,i=0;i<8;i++)0!==t[i]?(o>n&&(e=r,n=o),r=null,o=0):(null===r&&(r=i),++o);return o>n&&(e=r,n=o),e}(t),n=0;n<8;n++)o&&0===t[n]||(o&&(o=!1),r===n?(e+=n?":":"::",o=!0):(e+=t[n].toString(16),n<7&&(e+=":")));return"["+e+"]"}return t},z={},V=h({},z,{" ":1,'"':1,"<":1,">":1,"`":1}),q=h({},V,{"#":1,"?":1,"{":1,"}":1}),F=h({},q,{"/":1,":":1,";":1,"=":1,"@":1,"[":1,"\\":1,"]":1,"^":1,"|":1}),H=function(t,e){var n=f(t,0);return n>32&&n<127&&!p(e,t)?t:encodeURIComponent(t)},W={ftp:21,file:null,http:80,https:443,ws:80,wss:443},G=function(t){return p(W,t.scheme)},X=function(t){return""!=t.username||""!=t.password},Y=function(t){return!t.host||t.cannotBeABaseURL||"file"==t.scheme},K=function(t,e){var n;return 2==t.length&&k.test(t.charAt(0))&&(":"==(n=t.charAt(1))||!e&&"|"==n)},J=function(t){var e;return t.length>1&&K(t.slice(0,2))&&(2==t.length||"/"===(e=t.charAt(2))||"\\"===e||"?"===e||"#"===e)},Q=function(t){var e=t.path,n=e.length;!n||"file"==t.scheme&&1==n&&K(e[0],!0)||e.pop()},Z=function(t){return"."===t||"%2e"===t.toLowerCase()},tt={},et={},nt={},rt={},ot={},it={},at={},st={},ct={},ut={},lt={},pt={},ht={},dt={},ft={},gt={},vt={},mt={},yt={},bt={},wt={},xt=function(t,e,n,o){var i,a,s,c,u,l=n||tt,h=0,f="",g=!1,v=!1,m=!1;for(n||(t.scheme="",t.username="",t.password="",t.host=null,t.port=null,t.path=[],t.query=null,t.fragment=null,t.cannotBeABaseURL=!1,e=e.replace(L,"")),e=e.replace(N,""),i=d(e);h<=i.length;){switch(a=i[h],l){case tt:if(!a||!k.test(a)){if(n)return"Invalid scheme";l=nt;continue}f+=a.toLowerCase(),l=et;break;case et:if(a&&(A.test(a)||"+"==a||"-"==a||"."==a))f+=a.toLowerCase();else{if(":"!=a){if(n)return"Invalid scheme";f="",l=nt,h=0;continue}if(n&&(G(t)!=p(W,f)||"file"==f&&(X(t)||null!==t.port)||"file"==t.scheme&&!t.host))return;if(t.scheme=f,n)return void(G(t)&&W[t.scheme]==t.port&&(t.port=null));f="","file"==t.scheme?l=dt:G(t)&&o&&o.scheme==t.scheme?l=rt:G(t)?l=st:"/"==i[h+1]?(l=ot,h++):(t.cannotBeABaseURL=!0,t.path.push(""),l=yt)}break;case nt:if(!o||o.cannotBeABaseURL&&"#"!=a)return"Invalid scheme";if(o.cannotBeABaseURL&&"#"==a){t.scheme=o.scheme,t.path=o.path.slice(),t.query=o.query,t.fragment="",t.cannotBeABaseURL=!0,l=wt;break}l="file"==o.scheme?dt:it;continue;case rt:if("/"!=a||"/"!=i[h+1]){l=it;continue}l=ct,h++;break;case ot:if("/"==a){l=ut;break}l=mt;continue;case it:if(t.scheme=o.scheme,a==r)t.username=o.username,t.password=o.password,t.host=o.host,t.port=o.port,t.path=o.path.slice(),t.query=o.query;else if("/"==a||"\\"==a&&G(t))l=at;else if("?"==a)t.username=o.username,t.password=o.password,t.host=o.host,t.port=o.port,t.path=o.path.slice(),t.query="",l=bt;else{if("#"!=a){t.username=o.username,t.password=o.password,t.host=o.host,t.port=o.port,t.path=o.path.slice(),t.path.pop(),l=mt;continue}t.username=o.username,t.password=o.password,t.host=o.host,t.port=o.port,t.path=o.path.slice(),t.query=o.query,t.fragment="",l=wt}break;case at:if(!G(t)||"/"!=a&&"\\"!=a){if("/"!=a){t.username=o.username,t.password=o.password,t.host=o.host,t.port=o.port,l=mt;continue}l=ut}else l=ct;break;case st:if(l=ct,"/"!=a||"/"!=f.charAt(h+1))continue;h++;break;case ct:if("/"!=a&&"\\"!=a){l=ut;continue}break;case ut:if("@"==a){g&&(f="%40"+f),g=!0,s=d(f);for(var y=0;y<s.length;y++){var b=s[y];if(":"!=b||m){var w=H(b,F);m?t.password+=w:t.username+=w}else m=!0}f=""}else if(a==r||"/"==a||"?"==a||"#"==a||"\\"==a&&G(t)){if(g&&""==f)return"Invalid authority";h-=d(f).length+1,f="",l=lt}else f+=a;break;case lt:case pt:if(n&&"file"==t.scheme){l=gt;continue}if(":"!=a||v){if(a==r||"/"==a||"?"==a||"#"==a||"\\"==a&&G(t)){if(G(t)&&""==f)return"Invalid host";if(n&&""==f&&(X(t)||null!==t.port))return;if(c=B(t,f))return c;if(f="",l=vt,n)return;continue}"["==a?v=!0:"]"==a&&(v=!1),f+=a}else{if(""==f)return"Invalid host";if(c=B(t,f))return c;if(f="",l=ht,n==pt)return}break;case ht:if(!T.test(a)){if(a==r||"/"==a||"?"==a||"#"==a||"\\"==a&&G(t)||n){if(""!=f){var x=parseInt(f,10);if(x>65535)return"Invalid port";t.port=G(t)&&x===W[t.scheme]?null:x,f=""}if(n)return;l=vt;continue}return"Invalid port"}f+=a;break;case dt:if(t.scheme="file","/"==a||"\\"==a)l=ft;else{if(!o||"file"!=o.scheme){l=mt;continue}if(a==r)t.host=o.host,t.path=o.path.slice(),t.query=o.query;else if("?"==a)t.host=o.host,t.path=o.path.slice(),t.query="",l=bt;else{if("#"!=a){J(i.slice(h).join(""))||(t.host=o.host,t.path=o.path.slice(),Q(t)),l=mt;continue}t.host=o.host,t.path=o.path.slice(),t.query=o.query,t.fragment="",l=wt}}break;case ft:if("/"==a||"\\"==a){l=gt;break}o&&"file"==o.scheme&&!J(i.slice(h).join(""))&&(K(o.path[0],!0)?t.path.push(o.path[0]):t.host=o.host),l=mt;continue;case gt:if(a==r||"/"==a||"\\"==a||"?"==a||"#"==a){if(!n&&K(f))l=mt;else if(""==f){if(t.host="",n)return;l=vt}else{if(c=B(t,f))return c;if("localhost"==t.host&&(t.host=""),n)return;f="",l=vt}continue}f+=a;break;case vt:if(G(t)){if(l=mt,"/"!=a&&"\\"!=a)continue}else if(n||"?"!=a)if(n||"#"!=a){if(a!=r&&(l=mt,"/"!=a))continue}else t.fragment="",l=wt;else t.query="",l=bt;break;case mt:if(a==r||"/"==a||"\\"==a&&G(t)||!n&&("?"==a||"#"==a)){if(".."===(u=(u=f).toLowerCase())||"%2e."===u||".%2e"===u||"%2e%2e"===u?(Q(t),"/"==a||"\\"==a&&G(t)||t.path.push("")):Z(f)?"/"==a||"\\"==a&&G(t)||t.path.push(""):("file"==t.scheme&&!t.path.length&&K(f)&&(t.host&&(t.host=""),f=f.charAt(0)+":"),t.path.push(f)),f="","file"==t.scheme&&(a==r||"?"==a||"#"==a))for(;t.path.length>1&&""===t.path[0];)t.path.shift();"?"==a?(t.query="",l=bt):"#"==a&&(t.fragment="",l=wt)}else f+=H(a,q);break;case yt:"?"==a?(t.query="",l=bt):"#"==a?(t.fragment="",l=wt):a!=r&&(t.path[0]+=H(a,z));break;case bt:n||"#"!=a?a!=r&&("'"==a&&G(t)?t.query+="%27":t.query+="#"==a?"%23":H(a,z)):(t.fragment="",l=wt);break;case wt:a!=r&&(t.fragment+=H(a,V))}h++}},_t=function(t){var e,n,r=l(this,_t,"URL"),o=arguments.length>1?arguments[1]:void 0,a=String(t),s=_(r,{type:"URL"});if(void 0!==o)if(o instanceof _t)e=O(o);else if(n=xt(e={},String(o)))throw TypeError(n);if(n=xt(s,a,null,e))throw TypeError(n);var c=s.searchParams=new w,u=x(c);u.updateSearchParams(s.query),u.updateURL=function(){s.query=String(c)||null},i||(r.href=St.call(r),r.origin=jt.call(r),r.protocol=kt.call(r),r.username=At.call(r),r.password=Tt.call(r),r.host=Et.call(r),r.hostname=Ct.call(r),r.port=Rt.call(r),r.pathname=It.call(r),r.search=Pt.call(r),r.searchParams=Mt.call(r),r.hash=Lt.call(r))},Ot=_t.prototype,St=function(){var t=O(this),e=t.scheme,n=t.username,r=t.password,o=t.host,i=t.port,a=t.path,s=t.query,c=t.fragment,u=e+":";return null!==o?(u+="//",X(t)&&(u+=n+(r?":"+r:"")+"@"),u+=$(o),null!==i&&(u+=":"+i)):"file"==e&&(u+="//"),u+=t.cannotBeABaseURL?a[0]:a.length?"/"+a.join("/"):"",null!==s&&(u+="?"+s),null!==c&&(u+="#"+c),u},jt=function(){var t=O(this),e=t.scheme,n=t.port;if("blob"==e)try{return new _t(e.path[0]).origin}catch(t){return"null"}return"file"!=e&&G(t)?e+"://"+$(t.host)+(null!==n?":"+n:""):"null"},kt=function(){return O(this).scheme+":"},At=function(){return O(this).username},Tt=function(){return O(this).password},Et=function(){var t=O(this),e=t.host,n=t.port;return null===e?"":null===n?$(e):$(e)+":"+n},Ct=function(){var t=O(this).host;return null===t?"":$(t)},Rt=function(){var t=O(this).port;return null===t?"":String(t)},It=function(){var t=O(this),e=t.path;return t.cannotBeABaseURL?e[0]:e.length?"/"+e.join("/"):""},Pt=function(){var t=O(this).query;return t?"?"+t:""},Mt=function(){return O(this).searchParams},Lt=function(){var t=O(this).fragment;return t?"#"+t:""},Nt=function(t,e){return{get:t,set:e,configurable:!0,enumerable:!0}};if(i&&c(Ot,{href:Nt(St,(function(t){var e=O(this),n=String(t),r=xt(e,n);if(r)throw TypeError(r);x(e.searchParams).updateSearchParams(e.query)})),origin:Nt(jt),protocol:Nt(kt,(function(t){var e=O(this);xt(e,String(t)+":",tt)})),username:Nt(At,(function(t){var e=O(this),n=d(String(t));if(!Y(e)){e.username="";for(var r=0;r<n.length;r++)e.username+=H(n[r],F)}})),password:Nt(Tt,(function(t){var e=O(this),n=d(String(t));if(!Y(e)){e.password="";for(var r=0;r<n.length;r++)e.password+=H(n[r],F)}})),host:Nt(Et,(function(t){var e=O(this);e.cannotBeABaseURL||xt(e,String(t),lt)})),hostname:Nt(Ct,(function(t){var e=O(this);e.cannotBeABaseURL||xt(e,String(t),pt)})),port:Nt(Rt,(function(t){var e=O(this);Y(e)||(""==(t=String(t))?e.port=null:xt(e,t,ht))})),pathname:Nt(It,(function(t){var e=O(this);e.cannotBeABaseURL||(e.path=[],xt(e,t+"",vt))})),search:Nt(Pt,(function(t){var e=O(this);""==(t=String(t))?e.query=null:("?"==t.charAt(0)&&(t=t.slice(1)),e.query="",xt(e,t,bt)),x(e.searchParams).updateSearchParams(e.query)})),searchParams:Nt(Mt),hash:Nt(Lt,(function(t){var e=O(this);""!=(t=String(t))?("#"==t.charAt(0)&&(t=t.slice(1)),e.fragment="",xt(e,t,wt)):e.fragment=null}))}),u(Ot,"toJSON",(function(){return St.call(this)}),{enumerable:!0}),u(Ot,"toString",(function(){return St.call(this)}),{enumerable:!0}),b){var Bt=b.createObjectURL,Dt=b.revokeObjectURL;Bt&&u(_t,"createObjectURL",(function(t){return Bt.apply(b,arguments)})),Dt&&u(_t,"revokeObjectURL",(function(t){return Dt.apply(b,arguments)}))}v(_t,"URL"),o({global:!0,forced:!a,sham:!i},{URL:_t})},function(t,e,n){"use strict";var r=n(25),o=n(19),i=n(225),a=n(313),s=n(119),c=n(72),u=n(99),l=Object.assign,p=Object.defineProperty;t.exports=!l||o((function(){if(r&&1!==l({b:1},l(p({},"a",{enumerable:!0,get:function(){p(this,"b",{value:3,enumerable:!1})}}),{b:2})).b)return!0;var t={},e={},n=Symbol();return t[n]=7,"abcdefghijklmnopqrst".split("").forEach((function(t){e[t]=t})),7!=l({},t)[n]||"abcdefghijklmnopqrst"!=i(l({},e)).join("")}))?function(t,e){for(var n=c(t),o=arguments.length,l=1,p=a.f,h=s.f;o>l;)for(var d,f=u(arguments[l++]),g=p?i(f).concat(p(f)):i(f),v=g.length,m=0;v>m;)d=g[m++],r&&!h.call(f,d)||(n[d]=f[d]);return n}:l},function(t,e){e.f=Object.getOwnPropertySymbols},function(t,e,n){"use strict";var r=n(73),o=n(72),i=n(315),a=n(226),s=n(128),c=n(316),u=n(173);t.exports=function(t){var e,n,l,p,h,d,f=o(t),g="function"==typeof this?this:Array,v=arguments.length,m=v>1?arguments[1]:void 0,y=void 0!==m,b=u(f),w=0;if(y&&(m=r(m,v>2?arguments[2]:void 0,2)),null==b||g==Array&&a(b))for(n=new g(e=s(f.length));e>w;w++)d=y?m(f[w],w):f[w],c(n,w,d);else for(h=(p=b.call(f)).next,n=new g;!(l=h.call(p)).done;w++)d=y?i(p,m,[l.value,w],!0):l.value,c(n,w,d);return n.length=w,n}},function(t,e,n){var r=n(28),o=n(227);t.exports=function(t,e,n,i){try{return i?e(r(n)[0],n[1]):e(n)}catch(e){throw o(t),e}}},function(t,e,n){"use strict";var r=n(79),o=n(71),i=n(47);t.exports=function(t,e,n){var a=r(e);a in t?o.f(t,a,i(0,n)):t[a]=n}},function(t,e,n){"use strict";var r=/[^\0-\u007E]/,o=/[.\u3002\uFF0E\uFF61]/g,i="Overflow: input needs wider integers to process",a=Math.floor,s=String.fromCharCode,c=function(t){return t+22+75*(t<26)},u=function(t,e,n){var r=0;for(t=n?a(t/700):t>>1,t+=a(t/e);t>455;r+=36)t=a(t/35);return a(r+36*t/(t+38))},l=function(t){var e,n,r=[],o=(t=function(t){for(var e=[],n=0,r=t.length;n<r;){var o=t.charCodeAt(n++);if(o>=55296&&o<=56319&&n<r){var i=t.charCodeAt(n++);56320==(64512&i)?e.push(((1023&o)<<10)+(1023&i)+65536):(e.push(o),n--)}else e.push(o)}return e}(t)).length,l=128,p=0,h=72;for(e=0;e<t.length;e++)(n=t[e])<128&&r.push(s(n));var d=r.length,f=d;for(d&&r.push("-");f<o;){var g=2147483647;for(e=0;e<t.length;e++)(n=t[e])>=l&&n<g&&(g=n);var v=f+1;if(g-l>a((2147483647-p)/v))throw RangeError(i);for(p+=(g-l)*v,l=g,e=0;e<t.length;e++){if((n=t[e])<l&&++p>2147483647)throw RangeError(i);if(n==l){for(var m=p,y=36;;y+=36){var b=y<=h?1:y>=h+26?26:y-h;if(m<b)break;var w=m-b,x=36-b;r.push(s(c(b+w%x))),m=a(w/x)}r.push(s(c(m))),h=u(p,v,f==d),p=0,++f}}++p,++l}return r.join("")};t.exports=function(t){var e,n,i=[],a=t.toLowerCase().replace(o,".").split(".");for(e=0;e<a.length;e++)n=a[e],i.push(r.test(n)?"xn--"+l(n):n);return i.join(".")}},function(t,e,n){var r=n(28),o=n(173);t.exports=function(t){var e=o(t);if("function"!=typeof e)throw TypeError(String(t)+" is not iterable");return r(e.call(t))}},function(t,e){},function(t,e,n){"use strict";var r,o=n(321),i=n(20),a=n(4),s=n(16),c=n(11),u=n(114),l=n(15),p=n(24),h=n(21).f,d=n(78),f=n(69),g=n(6),v=n(75),m=a.Int8Array,y=m&&m.prototype,b=a.Uint8ClampedArray,w=b&&b.prototype,x=m&&d(m),_=y&&d(y),O=Object.prototype,S=O.isPrototypeOf,j=g("toStringTag"),k=v("TYPED_ARRAY_TAG"),A=o&&!!f&&"Opera"!==u(a.opera),T=!1,E={Int8Array:1,Uint8Array:1,Uint8ClampedArray:1,Int16Array:2,Uint16Array:2,Int32Array:4,Uint32Array:4,Float32Array:4,Float64Array:8},C={BigInt64Array:8,BigUint64Array:8},R=function(t){if(!s(t))return!1;var e=u(t);return c(E,e)||c(C,e)};for(r in E)a[r]||(A=!1);if((!A||"function"!=typeof x||x===Function.prototype)&&(x=function(){throw TypeError("Incorrect invocation")},A))for(r in E)a[r]&&f(a[r],x);if((!A||!_||_===O)&&(_=x.prototype,A))for(r in E)a[r]&&f(a[r].prototype,_);if(A&&d(w)!==_&&f(w,_),i&&!c(_,j))for(r in T=!0,h(_,j,{get:function(){return s(this)?this[k]:void 0}}),E)a[r]&&l(a[r],k,r);t.exports={NATIVE_ARRAY_BUFFER_VIEWS:A,TYPED_ARRAY_TAG:T&&k,aTypedArray:function(t){if(R(t))return t;throw TypeError("Target is not a typed array")},aTypedArrayConstructor:function(t){if(f){if(S.call(x,t))return t}else for(var e in E)if(c(E,r)){var n=a[e];if(n&&(t===n||S.call(n,t)))return t}throw TypeError("Target is not a typed array constructor")},exportTypedArrayMethod:function(t,e,n){if(i){if(n)for(var r in E){var o=a[r];if(o&&c(o.prototype,t))try{delete o.prototype[t]}catch(t){}}_[t]&&!n||p(_,t,n?e:A&&y[t]||e)}},exportTypedArrayStaticMethod:function(t,e,n){var r,o;if(i){if(f){if(n)for(r in E)if((o=a[r])&&c(o,t))try{delete o[t]}catch(t){}if(x[t]&&!n)return;try{return p(x,t,n?e:A&&x[t]||e)}catch(t){}}for(r in E)!(o=a[r])||o[t]&&!n||p(o,t,e)}},isView:function(t){if(!s(t))return!1;var e=u(t);return"DataView"===e||c(E,e)||c(C,e)},isTypedArray:R,TypedArray:x,TypedArrayPrototype:_}},function(t,e){t.exports="undefined"!=typeof ArrayBuffer&&"undefined"!=typeof DataView},function(t,e){var n=Math.floor,r=function(t,e){var a=t.length,s=n(a/2);return a<8?o(t,e):i(r(t.slice(0,s),e),r(t.slice(s),e),e)},o=function(t,e){for(var n,r,o=t.length,i=1;i<o;){for(r=i,n=t[i];r&&e(t[r-1],n)>0;)t[r]=t[--r];r!==i++&&(t[r]=n)}return t},i=function(t,e,n){for(var r=t.length,o=e.length,i=0,a=0,s=[];i<r||a<o;)i<r&&a<o?s.push(n(t[i],e[a])<=0?t[i++]:e[a++]):s.push(i<r?t[i++]:e[a++]);return s};t.exports=r},function(t,e,n){var r=n(40).match(/firefox\/(\d+)/i);t.exports=!!r&&+r[1]},function(t,e,n){var r=n(40);t.exports=/MSIE|Trident/.test(r)},function(t,e,n){var r=n(40).match(/AppleWebKit\/(\d+)\./);t.exports=!!r&&+r[1]},function(t,e,n){var r=n(16),o=n(69);t.exports=function(t,e,n){var i,a;return o&&"function"==typeof(i=e.constructor)&&i!==n&&r(a=i.prototype)&&a!==n.prototype&&o(t,a),t}},function(t,e,n){var r=n(16),o=n(34),i=n(6)("match");t.exports=function(t){var e;return r(t)&&(void 0!==(e=t[i])?!!e:"RegExp"==o(t))}},function(t,e,n){"use strict";var r=n(46),o=n(329).start,i=n(330)("trimStart"),a=i?function(){return o(this)}:"".trimStart;r({target:"String",proto:!0,forced:i},{trimStart:a,trimLeft:a})},function(t,e,n){var r=n(35),o="["+n(233)+"]",i=RegExp("^"+o+o+"*"),a=RegExp(o+o+"*$"),s=function(t){return function(e){var n=String(r(e));return 1&t&&(n=n.replace(i,"")),2&t&&(n=n.replace(a,"")),n}};t.exports={start:s(1),end:s(2),trim:s(3)}},function(t,e,n){var r=n(8),o=n(233);t.exports=function(t){return r((function(){return!!o[t]()||"​᠎"!="​᠎"[t]()||o[t].name!==t}))}},function(t,e,n){var r=n(332);t.exports=r},function(t,e,n){var r=n(333),o=Array.prototype;t.exports=function(t){var e=t.reduce;return t===o||t instanceof Array&&e===o.reduce?r:e}},function(t,e,n){n(334);var r=n(177);t.exports=r("Array").reduce},function(t,e,n){"use strict";var r=n(27),o=n(252).left,i=n(248),a=n(176),s=n(129);r({target:"Array",proto:!0,forced:!i("reduce")||!s&&a>79&&a<83},{reduce:function(t){return o(this,t,arguments.length,arguments.length>1?arguments[1]:void 0)}})},function(t,e,n){var r=n(336);t.exports=r},function(t,e,n){var r=n(337),o=String.prototype;t.exports=function(t){var e=t.trim;return"string"==typeof t||t===o||t instanceof String&&e===o.trim?r:e}},function(t,e,n){n(338);var r=n(177);t.exports=r("String").trim},function(t,e,n){"use strict";var r=n(27),o=n(339).trim;r({target:"String",proto:!0,forced:n(340)("trim")},{trim:function(){return o(this)}})},function(t,e,n){var r=n(68),o="["+n(234)+"]",i=RegExp("^"+o+o+"*"),a=RegExp(o+o+"*$"),s=function(t){return function(e){var n=String(r(e));return 1&t&&(n=n.replace(i,"")),2&t&&(n=n.replace(a,"")),n}};t.exports={start:s(1),end:s(2),trim:s(3)}},function(t,e,n){var r=n(19),o=n(234);t.exports=function(t){return r((function(){return!!o[t]()||"​᠎"!="​᠎"[t]()||o[t].name!==t}))}},function(t,e){t.exports=function(t){var e=typeof t;return null!=t&&("object"==e||"function"==e)}},function(t,e){t.exports=function(t){return null!=t&&"object"==typeof t}},function(t,e,n){"use strict";var r=n(1);e.a=r.b`.global-scrollbar {
  overflow: auto;
  scrollbar-width: thin;
  scrollbar-color: #ddd #f2f2f2;
}
.global-scrollbar::-webkit-scrollbar {
  width: 6px;
  height: 6px;
}
.global-scrollbar::-webkit-scrollbar-thumb {
  border-radius: 3px;
  background-color: transparent;
  border: 1px dashed transparent;
  background-clip: padding-box;
  -webkit-transition: all 0.3s;
  transition: all 0.3s;
}
.global-scrollbar::-webkit-scrollbar-thumb:hover,
.global-scrollbar:hover::-webkit-scrollbar-thumb:hover {
  background-color: #ccc;
  background-clip: border-box;
}
.global-scrollbar::-webkit-scrollbar-track {
  background-color: transparent;
}
.global-scrollbar:hover::-webkit-scrollbar-thumb {
  background-color: #ddd;
}
@media only screen and (hover: none) {
  .global-scrollbar::-webkit-scrollbar-thumb {
    background-color: #ddd;
  }
}
`},function(t,e,n){"use strict";n.d(e,"a",(function(){return a}));var r=n(127);
/**
 * @license
 * Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */class o{constructor(t){this.classes=new Set,this.changed=!1,this.element=t;const e=(t.getAttribute("class")||"").split(/\s+/);for(const t of e)this.classes.add(t)}add(t){this.classes.add(t),this.changed=!0}remove(t){this.classes.delete(t),this.changed=!0}commit(){if(this.changed){let t="";this.classes.forEach(e=>t+=e+" "),this.element.setAttribute("class",t)}}}const i=new WeakMap,a=Object(r.e)(t=>e=>{if(!(e instanceof r.a)||e instanceof r.c||"class"!==e.committer.name||e.committer.parts.length>1)throw new Error("The `classMap` directive must be used in the `class` attribute and must be the only part in the attribute.");const{committer:n}=e,{element:a}=n;let s=i.get(e);void 0===s&&(a.setAttribute("class",n.strings.join(" ")),i.set(e,s=new Set));const c=a.classList||new o(a);s.forEach(e=>{e in t||(c.remove(e),s.delete(e))});for(const e in t){const n=t[e];n!=s.has(e)&&(n?(c.add(e),s.add(e)):(c.remove(e),s.delete(e)))}"function"==typeof c.commit&&c.commit()})},function(t,e,n){"use strict";n.d(e,"a",(function(){return d}));var r=n(107),o=n.n(r),i=(n(13),n(17),n(10),n(3)),a=n(368),s=n.n(a),c=n(246),u=n(14),l=function(t,e,n,r){var o,i=arguments.length,a=i<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(t,e,n,r);else for(var s=t.length-1;s>=0;s--)(o=t[s])&&(a=(i<3?o(a):i>3?o(e,n,a):o(e,n))||a);return i>3&&a&&Object.defineProperty(e,n,a),a};const p=[{text:i18n("todo_welcome"),todoId:"todo-id1dtkk87it2iepal6dv4hr2uig0c",time:Date.now(),updatetime:0,done:!1}];class h extends c.a{constructor(){super(...arguments),this.todoList=p,this.currenetState="done",this.listLength=localStorage.getItem("todo-length")||0}toggleState(t){this.currenetState=t}get needNotificationPermission(){return this.todoList.some(t=>!!t.dueDate)}diffRemote(t){const e=t=>{if(null==t?void 0:t.updatetime){const e={updatetime:void 0};return t.done=!!t.done,Object.assign(Object.assign({},t),e)}},n=s()(t.todoList||[],e),r=s()(Object(i.j)(this.todoList),e);return!i.d.structural(n,r)}mergeRemote(t,e){if(t.todoList)if(e)this.todoList=t.todoList;else{const e=this.todoList,n=t.todoList,{result:r}=u.a.mergeArray(e,n,"todoId");this.todoList=r}}edit(t){this.todoList=this.todoList.map(e=>e.todoId===t?Object.assign(Object.assign({},e),{edit:!e.edit}):e)}get hasDoneTodo(){return this.todoList.filter(t=>t.done).length}async addTodo(t){if(!o()(t).call(t).length)return;const e={done:!1,time:+new Date,todoId:u.a.randomId("todo-"),updatetime:await u.a.getTimestamp(),text:t};Object(i.i)(()=>{this.todoList=[e,...this.todoList]})}removeTodo(){this.todoList=this.todoList.filter(t=>!t.done)}deleteTodo(t){this.todoList=this.todoList.filter(e=>e.todoId!==t)}async toggleTodo(t){const e=await u.a.getTimestamp();Object(i.i)(()=>{this.todoList=this.todoList.map(n=>n.todoId===t?Object.assign(Object.assign({},n),{done:!n.done,updatetime:e}):Object.assign({},n))})}async updateTodo(t,e){const n=await u.a.getTimestamp();Object(i.i)(()=>{this.todoList=this.todoList.map(r=>r.todoId===t?Object.assign(Object.assign(Object.assign({},r),e),{updatetime:n,edit:!1}):Object.assign({},r))})}removeTime(t){this.todoList=this.todoList.map(e=>e.todoId===t?Object.assign(Object.assign({},e),{dueDate:"",dueTime:"",dueTimestamp:null}):e)}}l([i.g],h.prototype,"todoList",void 0),l([i.g],h.prototype,"currenetState",void 0),l([i.b],h.prototype,"toggleState",null),l([i.e],h.prototype,"needNotificationPermission",null),l([i.b],h.prototype,"mergeRemote",null),l([i.b],h.prototype,"edit",null),l([i.g],h.prototype,"listLength",void 0),l([i.e],h.prototype,"hasDoneTodo",null),l([i.b],h.prototype,"addTodo",null),l([i.b],h.prototype,"removeTodo",null),l([i.b],h.prototype,"deleteTodo",null),l([i.b],h.prototype,"toggleTodo",null),l([i.b],h.prototype,"updateTodo",null),l([i.b],h.prototype,"removeTime",null);const d=new h;d.initSyncStore("store-todo",["todoList","listLength"],{},!0),d.initAutoBackup("todo",["todoList"]),Object(i.c)(()=>{if(d.firstSync){const t=d.todoList.filter(t=>!t.done).length;Object(i.i)(()=>{d.listLength=t}),localStorage.setItem("todo-length",t+"")}}),Object(i.c)(()=>{let t=!1;const{todoList:e}=d;for(let n=0;n<e.length-1;n++){const{done:r}=e[n],o=e[n+1].done;if(r&&!o){t=!0;break}}t&&(Object(i.i)(()=>{const t=e.filter(t=>t.done),n=e.filter(t=>!t.done);d.todoList=[...n,...t]}),t=!1)},{delay:300})},,function(t,e,n){var r=n(458),o=n(459),i=n(460),a=n(461),s=n(462);function c(t){var e=-1,n=null==t?0:t.length;for(this.clear();++e<n;){var r=t[e];this.set(r[0],r[1])}}c.prototype.clear=r,c.prototype.delete=o,c.prototype.get=i,c.prototype.has=a,c.prototype.set=s,t.exports=c},function(t,e,n){var r=n(402);t.exports=function(t,e){for(var n=t.length;n--;)if(r(t[n][0],e))return n;return-1}},function(t,e,n){var r=n(371),o=n(469),i=n(470),a=r?r.toStringTag:void 0;t.exports=function(t){return null==t?void 0===t?"[object Undefined]":"[object Null]":a&&a in Object(t)?o(t):i(t)}},function(t,e,n){var r=n(242)(Object,"create");t.exports=r},function(t,e,n){var r=n(483);t.exports=function(t,e){var n=t.__data__;return r(e)?n["string"==typeof e?"string":"hash"]:n.map}},function(t,e,n){var r=n(406),o=n(407);t.exports=function(t,e,n,i){var a=!n;n||(n={});for(var s=-1,c=e.length;++s<c;){var u=e[s],l=i?i(n[u],t[u],u,n,t):void 0;void 0===l&&(l=t[u]),a?o(n,u,l):r(n,u,l)}return n}},,,,,,function(t,e,n){"use strict";n.r(e);var r=n(7),o=n.n(r),i=(n(13),n(17),n(245)),a=n(390),s=n(1),c=n(3),u=s.b`.i-bubble {
  position: fixed;
  top: 80px;
  left: 50%;
  transform: translateX(-50%);
  z-index: 99999999;
}
.i-bubble.network-error .i-bubble-wrap,
.i-bubble.error .i-bubble-wrap,
.i-bubble.success .i-bubble-wrap {
  padding-left: 30px;
  padding-right: 32px;
}
.i-bubble + .i-bubble-mask {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(255, 255, 255, 0.7);
  z-index: 999999;
  display: none;
  opacity: 0;
  transition: opacity 150ms ease-in 0s;
}
.i-bubble.loading + .i-bubble-mask {
  display: block;
}
.i-bubble.loading.popup + .i-bubble-mask {
  opacity: 1;
}
.i-bubble .i-bubble-wrap {
  margin: 0 auto;
  box-sizing: border-box;
  padding: 12px 20px;
  background-color: #333;
  box-shadow: 0px 2px 20px 0px rgba(0, 0, 0, 0.1);
  border-radius: 4px;
  display: flex;
  flex-flow: row nowrap;
  align-items: center;
  font-size: 14px;
  line-height: 1.4em;
  transition: opacity 0.15s cubic-bezier(0, 0, 0.2, 1) 0ms, transform 0.15s cubic-bezier(0, 0, 0.2, 1) 0ms;
  transform: scale(0.8);
  opacity: 0;
  box-shadow: 0 3px 5px -1px rgba(0, 0, 0, 0.2), 0 6px 10px 0 rgba(0, 0, 0, 0.14), 0 1px 18px 0 rgba(0, 0, 0, 0.12);
  max-width: 600px;
}
.i-bubble.popup .i-bubble-wrap {
  transform: scale(1);
  opacity: 1;
}
@keyframes spin {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}
.i-bubble .icon {
  width: 18px;
  height: 18px;
  flex-shrink: 0;
  margin-right: 12px;
  display: none;
}
.i-bubble .icon.icon-loading {
  animation: spin 700ms linear infinite;
}
.i-bubble .i-bubble-text {
  color: #e4e4e4;
  display: block;
  box-sizing: border-box;
  flex-grow: 1;
  width: 100%;
  word-break: break-all;
}
.i-bubble .i-bubble-button {
  width: 70px;
  height: 28px;
  color: #4caf50;
  background-color: initial;
  border: none;
  padding: 0;
  cursor: pointer;
  transition: color, background-color 200ms;
  border-radius: 4px;
  outline: none;
  max-width: 180px;
  margin-left: 46px;
  flex-shrink: 0;
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow: hidden;
}
.i-bubble .i-bubble-button:hover {
  background-color: rgba(76, 175, 80, 0.14);
}
`,l=n(14),p=n(23),h=function(t,e,n,r){var o,i=arguments.length,a=i<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(t,e,n,r);else for(var s=t.length-1;s>=0;s--)(o=t[s])&&(a=(i<3?o(a):i>3?o(e,n,a):o(e,n))||a);return i>3&&a&&Object.defineProperty(e,n,a),a};const d=Object(p.a)("network-error.png",!1),f=Object(p.a)("error.png",!1),g=Object(p.a)("success.png",!1),v=Object(p.a)("loading.png",!1);class m extends i.a{constructor(){super(...arguments),this.popup=!1,this.showButton=!1}static _timeToHideHandler(t){if(t.showButton){const e=t.shadowRoot.querySelector(".i-bubble .i-bubble-button");e.onclick&&(e.onclick=null)}const e=t.shadowRoot.querySelector(".i-bubble > .i-bubble-wrap");let n=!1;const r=()=>{t.onmouseenter=null,t.onmouseleave=null,document.body.contains(t)&&document.body.removeChild(t),n=!0};e.addEventListener("transitionend",r,{once:!0}),e.addEventListener("transitioncancel",r,{once:!0}),setTimeout(()=>{n||r()},150),t.setPopup(!1)}static _setTimerToHide(t,e){this._clearTimerToHide(t),t.hideTimer=setTimeout(()=>this._timeToHideHandler(t),e)}static _clearTimerToHide(t){t.hideTimer&&(clearTimeout(t.hideTimer),t.hideTimer=null)}static _messageMisc(t,e,n){this.setText(t),document.body.appendChild(this),window.customElements.whenDefined("i-bubble").then(()=>(this.offsetWidth,this.setPopup(!0),new o.a(t=>requestAnimationFrame(t)))).then(()=>{n&&n(this)}),e>0&&m._setTimerToHide(this,e)}static message(t,e){const n=document.createElement("i-bubble");n.setType("message"),e=null!=e?e:this.duration,this._messageMisc.call(n,t,e)}static networkError(t,e){const n=document.createElement("i-bubble");n.setType("network-error"),e=null!=e?e:this.duration,this._messageMisc.call(n,t,e)}static success(t,e){const n=document.createElement("i-bubble");n.setType("success"),e=null!=e?e:this.duration,this._messageMisc.call(n,t,e)}static error(t,e){const n=document.createElement("i-bubble");n.setType("error"),e=null!=e?e:this.duration,this._messageMisc.call(n,t,e)}static popupLogin(t){const e=this.popup(i18n("reqeust_login_message"),{showButton:!0,btnValue:i18n("to_login"),type:"message",onBtnClick:null!=t?t:()=>{a.userStore.openModal()}}),n=Date.now();let r=this.duration2;e.onmouseenter=()=>{r=Date.now()-n,m._clearTimerToHide(e)},e.onmouseleave=()=>{m._setTimerToHide(e,r)}}static popupLoading(t){const e=this.popup(i18n("wallpaper_loading"),{duration:0,showButton:!0,btnValue:i18n("cancel"),type:"loading",onBtnClick:t});return()=>setTimeout(()=>this._timeToHideHandler(e),m.waitForReady)}static loading(t){const e=this.popup(t,{type:"loading",duration:0});return()=>setTimeout(()=>this._timeToHideHandler(e),m.waitForReady)}static popup(t,e){const{duration:n=this.duration2,btnValue:r,onBtnClick:o,type:i,showButton:a}=e,s=document.createElement("i-bubble");return s.setType(i),r&&s.setBtnValue(r),a&&s.setShowButton(a),this._messageMisc.call(s,t,n,()=>{if(s.showButton){s.shadowRoot.querySelector(".i-bubble .i-bubble-button").onclick=t=>{o&&o(t),this._timeToHideHandler(s)}}}),s}firstUpdated(){const t="\n      background-size: cover;\n      background-repeat: no-repeat;\n      background-position: center;\n      display: block;\n    ",e=document.createElement("style");e.appendChild(document.createTextNode(`\n      .i-bubble .icon.icon-network-error{\n        background-image: url(${d});${t}\n      }\n      .i-bubble .icon.icon-success{\n        background-image: url(${g});${t}\n      }\n      .i-bubble .icon.icon-error{\n        background-image: url(${f});${t}\n      }\n      .i-bubble .icon.icon-loading{\n        background-image: url(${v});${t}\n      }\n      `)),this.shadowRoot.appendChild(e)}render(){return s.e`
      <section class="i-bubble ${this.type}${this.popup?" popup":""}">
        <section class="i-bubble-wrap">
          <i class="icon icon-${this.type}"></i>
          <span class="i-bubble-text">${this.text}</span>
          <input
            class="i-bubble-button"
            type="button"
            .value=${this.btnValue}
            style="${this.showButton?"":"display: none;"}"
          />
        </section>
      </section>
      <section class="i-bubble-mask" @click=${l.a.stopBubble}></section>
    `}setType(t){this.type=t}setText(t){this.text=t}setBtnValue(t){this.btnValue=t}setPopup(t){this.popup=t}setShowButton(t){this.showButton=t}}m.duration=3e3,m.duration2=5e3,m.waitForReady=1e3/60,m.styles=u,h([c.g],m.prototype,"type",void 0),h([c.g],m.prototype,"text",void 0),h([c.g],m.prototype,"btnValue",void 0),h([c.g],m.prototype,"popup",void 0),h([c.g],m.prototype,"showButton",void 0),h([c.b],m.prototype,"setType",null),h([c.b],m.prototype,"setText",null),h([c.b],m.prototype,"setBtnValue",null),h([c.b],m.prototype,"setPopup",null),h([c.b],m.prototype,"setShowButton",null),window.customElements.define("i-bubble",m);e.default=m},function(t,e,n){"use strict";n.d(e,"a",(function(){return r})),n.d(e,"b",(function(){return i}));n(13),n(17);class r{constructor(){this._caches={},this._setCaches=t=>(...e)=>{this._caches[t]=e}}}const o=[],i=t=>new Proxy(t,{set:(t,e,n)=>null===n?(t[e]=n,!0):"function"==typeof t[e]?(console.warn("失败：重复注册"),!0):(t[e]=n,o.includes(e)&&delete t._caches[e],t._caches.hasOwnProperty(e)&&(t[e](...t._caches[e]),delete t._caches[e]),!0),get:(t,e)=>"function"==typeof t[e]?t[e]:t._setCaches(e)})},function(t,e,n){"use strict";n.d(e,"a",(function(){return s}));var r=n(7),o=n.n(r),i=(n(10),n(0)),a=n(97);async function s(){if(i.r){if("granted"!==await new o.a(t=>{!function(){try{Notification.requestPermission().then()}catch(t){return!1}return!0}()?Notification.requestPermission(t):Notification.requestPermission().then(t)}))throw new Error}else await a.a.request(["notifications"])}},function(t,e){var n,r;n="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",r={rotl:function(t,e){return t<<e|t>>>32-e},rotr:function(t,e){return t<<32-e|t>>>e},endian:function(t){if(t.constructor==Number)return 16711935&r.rotl(t,8)|4278255360&r.rotl(t,24);for(var e=0;e<t.length;e++)t[e]=r.endian(t[e]);return t},randomBytes:function(t){for(var e=[];t>0;t--)e.push(Math.floor(256*Math.random()));return e},bytesToWords:function(t){for(var e=[],n=0,r=0;n<t.length;n++,r+=8)e[r>>>5]|=t[n]<<24-r%32;return e},wordsToBytes:function(t){for(var e=[],n=0;n<32*t.length;n+=8)e.push(t[n>>>5]>>>24-n%32&255);return e},bytesToHex:function(t){for(var e=[],n=0;n<t.length;n++)e.push((t[n]>>>4).toString(16)),e.push((15&t[n]).toString(16));return e.join("")},hexToBytes:function(t){for(var e=[],n=0;n<t.length;n+=2)e.push(parseInt(t.substr(n,2),16));return e},bytesToBase64:function(t){for(var e=[],r=0;r<t.length;r+=3)for(var o=t[r]<<16|t[r+1]<<8|t[r+2],i=0;i<4;i++)8*r+6*i<=8*t.length?e.push(n.charAt(o>>>6*(3-i)&63)):e.push("=");return e.join("")},base64ToBytes:function(t){t=t.replace(/[^A-Z0-9+\/]/gi,"");for(var e=[],r=0,o=0;r<t.length;o=++r%4)0!=o&&e.push((n.indexOf(t.charAt(r-1))&Math.pow(2,-2*o+8)-1)<<2*o|n.indexOf(t.charAt(r))>>>6-2*o);return e}},t.exports=r},function(t,e){function n(t){return!!t.constructor&&"function"==typeof t.constructor.isBuffer&&t.constructor.isBuffer(t)}
/*!
 * Determine if an object is a Buffer
 *
 * @author   Feross Aboukhadijeh <https://feross.org>
 * @license  MIT
 */
t.exports=function(t){return null!=t&&(n(t)||function(t){return"function"==typeof t.readFloatLE&&"function"==typeof t.slice&&n(t.slice(0,0))}(t)||!!t._isBuffer)}},function(t,e,n){var r=n(364);t.exports=r},function(t,e,n){n(240);var r=n(365),o=n(126),i=Array.prototype,a={DOMTokenList:!0,NodeList:!0};t.exports=function(t){var e=t.keys;return t===i||t instanceof Array&&e===i.keys||a.hasOwnProperty(o(t))?r:e}},function(t,e,n){var r=n(366);t.exports=r},function(t,e,n){n(191);var r=n(177);t.exports=r("Array").keys},function(t,e,n){"use strict";n(13),n(17);var r=n(1),o=function(t,e,n,r){var o,i=arguments.length,a=i<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(t,e,n,r);else for(var s=t.length-1;s>=0;s--)(o=t[s])&&(a=(i<3?o(a):i>3?o(e,n,a):o(e,n))||a);return i>3&&a&&Object.defineProperty(e,n,a),a};let i=class extends r.a{constructor(){super(...arguments),this.src=""}render(){return r.e`
      <div class="svg" style="-webkit-mask-image: url(${this.src})"></div>
    `}};i.styles=r.b`
    :host{
      display: block;
      width: 30px;
      height: 30px;
      --size: 100%;
      -webkit-mask-size: var(--size);
      -webkit-mask-position: center;
      -webkit-mask-repeat: no-repeat;
      color: black;
    }
    .svg{
      width: inherit;
      height: inherit;
      -webkit-mask-size: inherit;
      -webkit-mask-position: inherit;
      color: inherit;
      background-color: currentcolor;
      -webkit-mask-repeat: inherit;
    }
  `,o([Object(r.g)({type:String})],i.prototype,"src",void 0),i=o([Object(r.c)("i-svg")],i)},function(t,e,n){var r=n(456);t.exports=function(t,e){return r(t,5,e="function"==typeof e?e:void 0)}},,function(t,e,n){var r=n(242)(n(193),"Map");t.exports=r},function(t,e,n){var r=n(193).Symbol;t.exports=r},function(t,e,n){var r=n(408),o=n(497),i=n(412);t.exports=function(t){return i(t)?r(t):o(t)}},function(t,e){var n=Array.isArray;t.exports=n},function(t,e){t.exports=function(t){return t.webpackPolyfill||(t.deprecate=function(){},t.paths=[],t.children||(t.children=[]),Object.defineProperty(t,"loaded",{enumerable:!0,get:function(){return t.l}}),Object.defineProperty(t,"id",{enumerable:!0,get:function(){return t.i}}),t.webpackPolyfill=1),t}},function(t,e){t.exports=function(t){return function(e){return t(e)}}},function(t,e,n){(function(t){var r=n(404),o=e&&!e.nodeType&&e,i=o&&"object"==typeof t&&t&&!t.nodeType&&t,a=i&&i.exports===o&&r.process,s=function(){try{var t=i&&i.require&&i.require("util").types;return t||a&&a.binding&&a.binding("util")}catch(t){}}();t.exports=s}).call(this,n(374)(t))},function(t,e){var n=Object.prototype;t.exports=function(t){var e=t&&t.constructor;return t===("function"==typeof e&&e.prototype||n)}},function(t,e,n){var r=n(408),o=n(500),i=n(412);t.exports=function(t){return i(t)?r(t,!0):o(t)}},function(t,e,n){var r=n(505),o=n(413),i=Object.prototype.propertyIsEnumerable,a=Object.getOwnPropertySymbols,s=a?function(t){return null==t?[]:(t=Object(t),r(a(t),(function(e){return i.call(t,e)})))}:o;t.exports=s},function(t,e,n){var r=n(509),o=n(370),i=n(510),a=n(511),s=n(512),c=n(349),u=n(405),l=u(r),p=u(o),h=u(i),d=u(a),f=u(s),g=c;(r&&"[object DataView]"!=g(new r(new ArrayBuffer(1)))||o&&"[object Map]"!=g(new o)||i&&"[object Promise]"!=g(i.resolve())||a&&"[object Set]"!=g(new a)||s&&"[object WeakMap]"!=g(new s))&&(g=function(t){var e=c(t),n="[object Object]"==e?t.constructor:void 0,r=n?u(n):"";if(r)switch(r){case l:return"[object DataView]";case p:return"[object Map]";case h:return"[object Promise]";case d:return"[object Set]";case f:return"[object WeakMap]"}return e}),t.exports=g},function(t,e,n){var r=n(515);t.exports=function(t){var e=new t.constructor(t.byteLength);return new r(e).set(new r(t)),e}},function(t,e,n){"use strict";n.d(e,"a",(function(){return u}));n(13),n(17),n(18),n(44);var r=n(1),o=n(400),i=n.n(o),a=(n(399),n(395),r.b`/*!
 * Cropper.js v1.5.12
 * https://fengyuanchen.github.io/cropperjs
 *
 * Copyright 2015-present Chen Fengyuan
 * Released under the MIT license
 *
 * Date: 2021-06-12T08:00:11.623Z
 */
.cropper-container {
  direction: ltr;
  font-size: 0;
  line-height: 0;
  position: relative;
  -ms-touch-action: none;
  touch-action: none;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}
.cropper-container img {
  display: block;
  height: 100%;
  image-orientation: 0deg;
  max-height: none !important;
  max-width: none !important;
  min-height: 0 !important;
  min-width: 0 !important;
  width: 100%;
}
.cropper-wrap-box,
.cropper-canvas,
.cropper-drag-box,
.cropper-crop-box,
.cropper-modal {
  bottom: 0;
  left: 0;
  position: absolute;
  right: 0;
  top: 0;
}
.cropper-wrap-box,
.cropper-canvas {
  overflow: hidden;
}
.cropper-drag-box {
  background-color: #fff;
  opacity: 0;
}
.cropper-modal {
  background-color: #000;
  opacity: 0.5;
}
.cropper-view-box {
  display: block;
  height: 100%;
  outline: 1px solid #39f;
  outline-color: rgba(51, 153, 255, 0.75);
  overflow: hidden;
  width: 100%;
}
.cropper-dashed {
  border: 0 dashed #eee;
  display: block;
  opacity: 0.5;
  position: absolute;
}
.cropper-dashed.dashed-h {
  border-bottom-width: 1px;
  border-top-width: 1px;
  height: calc(100% / 3);
  left: 0;
  top: calc(100% / 3);
  width: 100%;
}
.cropper-dashed.dashed-v {
  border-left-width: 1px;
  border-right-width: 1px;
  height: 100%;
  left: calc(100% / 3);
  top: 0;
  width: calc(100% / 3);
}
.cropper-center {
  display: block;
  height: 0;
  left: 50%;
  opacity: 0.75;
  position: absolute;
  top: 50%;
  width: 0;
}
.cropper-center::before,
.cropper-center::after {
  background-color: #eee;
  content: ' ';
  display: block;
  position: absolute;
}
.cropper-center::before {
  height: 1px;
  left: -3px;
  top: 0;
  width: 7px;
}
.cropper-center::after {
  height: 7px;
  left: 0;
  top: -3px;
  width: 1px;
}
.cropper-face,
.cropper-line,
.cropper-point {
  display: block;
  height: 100%;
  opacity: 0.1;
  position: absolute;
  width: 100%;
}
.cropper-face {
  background-color: #fff;
  left: 0;
  top: 0;
}
.cropper-line {
  background-color: #39f;
}
.cropper-line.line-e {
  cursor: ew-resize;
  right: -3px;
  top: 0;
  width: 5px;
}
.cropper-line.line-n {
  cursor: ns-resize;
  height: 5px;
  left: 0;
  top: -3px;
}
.cropper-line.line-w {
  cursor: ew-resize;
  left: -3px;
  top: 0;
  width: 5px;
}
.cropper-line.line-s {
  bottom: -3px;
  cursor: ns-resize;
  height: 5px;
  left: 0;
}
.cropper-point {
  background-color: #39f;
  height: 5px;
  opacity: 0.75;
  width: 5px;
}
.cropper-point.point-e {
  cursor: ew-resize;
  margin-top: -3px;
  right: -3px;
  top: 50%;
}
.cropper-point.point-n {
  cursor: ns-resize;
  left: 50%;
  margin-left: -3px;
  top: -3px;
}
.cropper-point.point-w {
  cursor: ew-resize;
  left: -3px;
  margin-top: -3px;
  top: 50%;
}
.cropper-point.point-s {
  bottom: -3px;
  cursor: s-resize;
  left: 50%;
  margin-left: -3px;
}
.cropper-point.point-ne {
  cursor: nesw-resize;
  right: -3px;
  top: -3px;
}
.cropper-point.point-nw {
  cursor: nwse-resize;
  left: -3px;
  top: -3px;
}
.cropper-point.point-sw {
  bottom: -3px;
  cursor: nesw-resize;
  left: -3px;
}
.cropper-point.point-se {
  bottom: -3px;
  cursor: nwse-resize;
  height: 20px;
  opacity: 1;
  right: -3px;
  width: 20px;
}
@media (min-width: 768px) {
  .cropper-point.point-se {
    height: 15px;
    width: 15px;
  }
}
@media (min-width: 992px) {
  .cropper-point.point-se {
    height: 10px;
    width: 10px;
  }
}
@media (min-width: 1200px) {
  .cropper-point.point-se {
    height: 5px;
    opacity: 0.75;
    width: 5px;
  }
}
.cropper-point.point-se::before {
  background-color: #39f;
  bottom: -50%;
  content: ' ';
  display: block;
  height: 200%;
  opacity: 0;
  position: absolute;
  right: -50%;
  width: 200%;
}
.cropper-invisible {
  opacity: 0;
}
.cropper-bg {
  background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQAQMAAAAlPW0iAAAAA3NCSVQICAjb4U/gAAAABlBMVEXMzMz////TjRV2AAAACXBIWXMAAArrAAAK6wGCiw1aAAAAHHRFWHRTb2Z0d2FyZQBBZG9iZSBGaXJld29ya3MgQ1M26LyyjAAAABFJREFUCJlj+M/AgBVhF/0PAH6/D/HkDxOGAAAAAElFTkSuQmCC');
}
.cropper-hide {
  display: block;
  height: 0;
  position: absolute;
  width: 0;
}
.cropper-hidden {
  display: none !important;
}
.cropper-move {
  cursor: move;
}
.cropper-crop {
  cursor: crosshair;
}
.cropper-disabled .cropper-drag-box,
.cropper-disabled .cropper-face,
.cropper-disabled .cropper-line,
.cropper-disabled .cropper-point {
  cursor: not-allowed;
}
`),s=r.b`:host {
  display: block;
  position: relative;
  z-index: 99999999;
}
.img-modal {
  position: fixed;
  z-index: 111;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
}
.img-modal.hide {
  display: none;
}
.img-modal .img-modal-mask {
  position: absolute;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
}
.img-modal .img-modal-content {
  width: 640px;
  padding: 0 20px;
  box-sizing: border-box;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background-color: #fff;
  box-shadow: 0 6px 6px rgba(0, 0, 0, 0.2);
  border-radius: 3px;
}
.img-modal .modal-header .close {
  margin-top: 18px;
  text-align: right;
}
.img-modal .modal-header .close i-usesvg {
  color: #d9d6d7;
  width: 14px;
  height: 14px;
  cursor: pointer;
}
.img-modal .modal-header .title {
  margin-top: 8px;
  margin-bottom: 50px;
  text-align: center;
  font-size: 20px;
  font-weight: 500;
  color: #333333;
  line-height: 28px;
}
.img-modal .modal-body {
  display: flex;
  padding-bottom: 20px;
}
.img-modal .cropper {
  position: relative;
  width: 260px;
  height: 260px;
  margin-right: 24px;
  flex-shrink: 0;
  margin-bottom: 32px;
}
.img-modal .float-option {
  position: absolute;
  bottom: -32px;
  width: 100%;
  box-sizing: border-box;
  display: flex;
  justify-content: space-between;
}
.img-modal .float-option i-usesvg {
  cursor: pointer;
  width: 18px;
  height: 18px;
  color: #333;
  opacity: 0.3;
  transition: opacity 0.2s;
}
.img-modal .float-option i-usesvg:hover {
  opacity: 1;
}
.img-modal .float-option-left > i-usesvg {
  margin-right: 16px;
}
.img-modal .float-option-right > i-usesvg {
  margin-left: 16px;
}
.img-modal .option {
  position: relative;
  flex-grow: 1;
}
.img-modal .option .title {
  display: block;
  margin-bottom: 14px;
  line-height: 1;
  font-weight: 500;
  color: #333333;
}
.img-modal .preview-box .preview {
  border: 1px solid #DADCE0;
  box-sizing: border-box;
  overflow: hidden;
  margin-bottom: 30px;
  width: 80px;
  height: 80px;
  border-radius: 6px;
  -webkit-mask-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAIAAACQd1PeAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAA5JREFUeNpiYGBgAAgwAAAEAAGbA+oJAAAAAElFTkSuQmCC);
          mask-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAIAAACQd1PeAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAA5JREFUeNpiYGBgAAgwAAAEAAGbA+oJAAAAAElFTkSuQmCC);
}
.img-modal .color-box {
  position: relative;
}
.img-modal .color-box i-colorpicker {
  margin-right: 28px;
}
.modal-footer {
  margin-top: 20px;
  margin-bottom: 40px;
}
.modal-footer .btn-box {
  padding: 0 100px;
  display: flex;
  justify-content: space-between;
}
.modal-footer .btn-box infinito-button {
  outline: none;
  border: none;
  width: 120px;
  height: 42px;
  background: #efefef;
  border-radius: 6px;
  font-size: 16px;
  font-weight: 500;
  line-height: 22px;
  color: #333333;
  cursor: pointer;
}
.cropper .cropper-wrap-box {
  background-color: currentColor;
}
.cropper img {
  max-width: 100%;
  max-height: 100%;
}
.cropper .cropper-wrap-box {
  background-color: currentColor;
}
.cropper .cropper-crop-box {
  background-color: currentColor;
}
.cropper .cropper-point.point-se {
  height: 5px;
  width: 5px;
}
`,c=function(t,e,n,r){var o,i=arguments.length,a=i<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(t,e,n,r);else for(var s=t.length-1;s>=0;s--)(o=t[s])&&(a=(i<3?o(a):i>3?o(e,n,a):o(e,n))||a);return i>3&&a&&Object.defineProperty(e,n,a),a};let u=class extends r.a{constructor(){super(...arguments),this.modalStatus=!1,this.rgba="",this.initRgba="",this.title="",this.showImg=!1,this.cropper=null}static create(t){const e=null==t?void 0:t.title,n=document.body,r=document.createElement("i-cropper");return e&&r.setAttribute("title",e),n.appendChild(r),this.instance=r,r}static destroy(){var t,e;null===(e=null===(t=this.instance)||void 0===t?void 0:t.parentNode)||void 0===e||e.removeChild(this.instance),this.instance=null}init(t,e){this.showImg=!1,this.rgba=e||"transparent",this.initRgba=e||"transparent",this.cropper?(this.cropper.replace(t),this.cropper.reset()):(this.$img.src=t,this.cropper=new i.a(this.$img,{aspectRatio:1,zoomOnWheel:!0,autoCropArea:.9999,preview:this.$preview,checkCrossOrigin:!1,dragMode:"move",ready:()=>{this.showImg=!0}}))}close(t=!0){this.modalStatus=!1,this.showImg=!1,t&&(this.rgba="")}show(){this.modalStatus=!0}_rotateCropper(t){this.cropper.rotate(t)}_scaleCropper(t){this.cropper.zoom(t)}_resetCropper(){this.rgba=this.initRgba,this.cropper.reset(),requestAnimationFrame(()=>{this.$colorPicker.resetActiveIndex()})}_onSubmitImg(){this.cropper.getCroppedCanvas({minWidth:512,minHeight:512,maxWidth:600,maxHeight:600}).toBlob(t=>{const e=new CustomEvent("on-change",{detail:{data:t,color:this.rgba}});this.dispatchEvent(e),this.close()},"image/png")}_pickColor(t){const{value:e}=t.detail;this.rgba=e}render(){return r.e` <div class="img-modal ${this.modalStatus?"show":"hide"}">
      <div class="img-modal-mask"></div>
      <div class="img-modal-content">
        <section class="modal-header">
          <div class="close">
            <i-usesvg @click="${this.close}" type="icon-guanbi1" iconfont></i-usesvg>
          </div>
          <div class="title">${this.title||i18n("custom_icon")}</div>
        </section>
        <section class="modal-body">
          <div
            style="${this.rgba?`color:${this.rgba};`:"color:transparent;"}${this.showImg?"opacity:1;":"opacity:0;"}"
            class="cropper"
          >
            <img class="file-img" crossorigin="anonymous" src="" alt="" />
            <div class="float-option">
              <div class="float-option-left">
                <i-usesvg @click="${()=>this._rotateCropper(90)}" type="infinity-pro-pure-icon-redo"></i-usesvg>
                <i-usesvg @click="${()=>this._rotateCropper(-90)}" type="infinity-pro-pure-icon-undo"></i-usesvg>
              </div>
              <div class="float-option-right">
                <i-usesvg @click="${()=>this._scaleCropper(-.1)}" type="infinity-pro-pure-icon-zoom-out"></i-usesvg>
                <i-usesvg @click="${()=>this._scaleCropper(.1)}" type="infinity-pro-pure-icon-zoom-in"></i-usesvg>
              </div>
            </div>
          </div>
          <div class="option">
            <div class="preview-box">
              <span class="title">${i18n("preview")}</span>
              <div
                style="${this.rgba?`background-color:${this.rgba};`:"background-color:transparent;"}"
                class="preview"
              ></div>
            </div>
            <div class="color-box">
              <span class="title">${i18n("bg_color")}</span>
              <i-colorpicker .value="${this.rgba}" @on-change="${this._pickColor}"></i-colorpicker>
            </div>
          </div>
        </section>
        <section class="modal-footer">
          <div class="btn-box">
            <infinito-button @click="${this.close}">${i18n("cancel")}</infinito-button>
            <infinito-button @click="${this._resetCropper}">${i18n("reset")}</infinito-button>
            <infinito-button primary @click="${this._onSubmitImg}">${i18n("confirm")}</infinito-button>
          </div>
        </section>
      </div>
    </div>`}};u.styles=[s,a],u.instance=null,c([Object(r.h)(".file-img")],u.prototype,"$img",void 0),c([Object(r.h)(".preview")],u.prototype,"$preview",void 0),c([Object(r.h)("i-colorpicker")],u.prototype,"$colorPicker",void 0),c([Object(r.g)({type:Boolean})],u.prototype,"modalStatus",void 0),c([Object(r.g)({type:String})],u.prototype,"rgba",void 0),c([Object(r.g)({type:String})],u.prototype,"title",void 0),c([Object(r.f)()],u.prototype,"showImg",void 0),u=c([Object(r.c)("i-cropper")],u)},function(t,e,n){"use strict";n.d(e,"a",(function(){return R}));var r=n(425),o=n.n(r);function i(t,e,n){return e in t?o()(t,e,{value:n,enumerable:!0,configurable:!0,writable:!0}):t[e]=n,t}var a=n(48),s=n.n(a),c=n(7),u=n.n(c),l=(n(18),n(10),n(44),n(52),n(1)),p=n(245),h=l.b`:host {
  width: 100%;
  box-sizing: border-box;
  padding: 24px 20px 60px;
  display: flex;
  flex-direction: column;
  background-color: #fff;
}
textarea,
input {
  font-family: 'PingFang SC', 'Microsoft Yahei', Helvetica, Arial, sans-serif;
}
.error {
  margin-left: 6px;
  font-size: 14px;
  font-weight: 400;
  color: #ea4747;
}
.box-dynamic {
  padding-bottom: 30px;
}
.item-icon {
  height: 70px;
}
.img-item-box:not([hidden]) {
  display: flex;
  align-items: flex-end;
}
.img-item {
  width: 60px;
  background-color: #dddddd;
  background-image: linear-gradient(45deg, #ffffff 25%, transparent 0px, transparent 75%, #ffffff 0px), linear-gradient(45deg, #ffffff 25%, transparent 0px, transparent 75%, #ffffff 0px);
  background-position: 0px 0px, 5px 5px;
  background-size: 10px 10px;
  border-radius: 6px;
}
.item {
  position: relative;
  margin-bottom: 20px;
}
.item .label-box {
  margin-bottom: 8px;
  display: flex;
  align-items: center;
}
.item .label-box .label {
  font-weight: 500;
  color: #333333;
}
.item .label-box .tip-question {
  margin-left: 2px;
  width: 16px;
  height: 16px;
  cursor: pointer;
}
.item #icon-preview {
  border: 4px solid #f6f6f6;
  transform: scale(0.25);
  transform-origin: left top;
  position: relative;
  border-radius: 30px;
  background-color: #ddd;
  background-image: linear-gradient(45deg, #fff 25%, transparent 0, transparent 75%, #fff 0), linear-gradient(45deg, #fff 25%, transparent 0, transparent 75%, #fff 0);
  background-position: 0 0, 20px 20px;
  background-size: 40px 40px;
}
.item .img-dropper {
  position: relative;
  margin-right: 8px;
  display: inline-flex;
  justify-content: center;
  align-items: center;
  vertical-align: bottom;
  width: 60px;
  height: 60px;
  background: #ffffff;
  background-image: url("data:image/svg+xml,%3csvg width='100%25' height='100%25' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='100%25' height='100%25' fill='none' rx='6' ry='6' stroke='%23C3C3C3FF' stroke-width='1' stroke-dasharray='5%2c 6' stroke-dashoffset='12' stroke-linecap='butt'/%3e%3c/svg%3e");
  border-radius: 6px;
  cursor: pointer;
}
.item .img-dropper[hidden] {
  display: none;
}
.item .img-preview {
  background-size: cover;
  border: 1px solid #dadce0;
  box-sizing: border-box;
}
.item .img-preview .editing:hover {
  opacity: 1;
}
.item .img-preview .editing {
  opacity: 0;
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: 6px;
  background: rgba(0, 0, 0, 0.3);
  transition: opacity 0.2s;
}
.item .img-preview .editing-icon {
  width: 28px;
  height: 28px;
}
.item .img-preview i-svg {
  --size: 90%;
  color: #fff;
  opacity: 0.8;
  cursor: pointer;
}
.item .img-preview i-svg:hover {
  opacity: 1;
  color: #fff;
}
.item input::placeholder,
.item .input::placeholder,
.item textarea::placeholder {
  color: #999999;
}
.item input[type='text'],
.item .input {
  outline: none;
  border: none;
  border-bottom: 1px solid #eee;
  line-height: 1;
  height: 30px;
  box-sizing: border-box;
  padding-bottom: 6px;
  width: 100%;
  color: #333333;
}
.item .input {
  height: auto;
  max-height: 50px;
  line-height: 16px;
  max-width: 100%;
  min-width: 100%;
  resize: none;
}
.item input:-moz-read-only {
  cursor: not-allowed;
}
.item input:read-only {
  cursor: not-allowed;
}
.item textarea.target {
  outline: none;
  width: 100%;
  height: 90px;
  box-sizing: border-box;
  padding: 10px;
  background: #ffffff;
  border-radius: 6px;
  border: 1px solid #eeeeee;
  resize: none;
  word-break: break-all;
  color: #333333;
}
.item input[type='file'] {
  width: 100px;
}
.item.btn-box {
  display: flex;
  flex-direction: column;
  align-items: center;
}
.item.btn-box infinito-button {
  width: 220px;
  height: 38px;
  background: #333333;
  border-radius: 6px;
  outline: none;
  border: none;
  cursor: pointer;
  font-weight: 500;
  color: #ffffff;
}
.item.btn-box infinito-button:disabled {
  background: rgba(51, 51, 51, 0.7);
}
.item.btn-box .btn-cancel {
  margin-top: 14px;
  background: #eeeeee;
  border-radius: 6px;
  font-size: 14px;
  color: #333333;
}
.item.btn-box .btn-cancel:hover {
  background: #c8c8c8;
}
.del {
  position: absolute;
  width: 18px;
  height: 18px;
  top: -6px;
  right: -6px;
  cursor: pointer;
  transition: transform 0.2s;
}
.del:hover {
  transform: scale(1.1);
}
.svg-box {
  width: 70px;
  height: 70px;
  border: 1px solid #f6f6f6;
  box-sizing: border-box;
  position: relative;
  border-radius: 6px;
  background-color: #ddd;
  background-image: linear-gradient(45deg, #fff 25%, transparent 0, transparent 75%, #fff 0), linear-gradient(45deg, #fff 25%, transparent 0, transparent 75%, #fff 0);
  background-position: 0 0, 5px 5px;
  background-size: 10px 10px;
  overflow: hidden;
}
`,d=n(382),f=(n(395),n(367),n(399),n(3)),g=n(81),v=n(14),m=function(t,e,n,r){var o,i=arguments.length,a=i<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(t,e,n,r);else for(var s=t.length-1;s>=0;s--)(o=t[s])&&(a=(i<3?o(a):i>3?o(e,n,a):o(e,n))||a);return i>3&&a&&Object.defineProperty(e,n,a),a};class y{async getTargetInfo(t,e){const{data:n,error:r}=await g.b.getUrlInfoWithPermission(t.split("?")[0]);if(null==r?void 0:r.__CANCEL__)return;if(r)return e?{name:"",bgText:""}:null;const o=function(t){const e={lt:"<",gt:">",nbsp:" ",lrm:"",amp:"&",quot:'"'};return t.replace(/&(lt|gt|nbsp|amp|quot|lrm);/gi,(t,n)=>e[n])}(n.name);let i="";return i=o.length>3?o.substr(0,2):o,{name:o,bgText:i}}async uploadIcon(t,e){var n,r;const{data:o,error:i}=await g.f.uploadFile(t,v.a.randomId("icon-")+".png",e);if(i){return{error:(null===(r=null===(n=i.response)||void 0===n?void 0:n.data)||void 0===r?void 0:r.error)?i.response.data.error:i.message,url:""}}return{url:o.url,error:""}}}m([f.b],y.prototype,"getTargetInfo",null),m([f.b],y.prototype,"uploadIcon",null);const b=new y;var w=n(2),x=n(122),_=(n(13),n(17),n(343)),O=function(t,e,n,r){var o,i=arguments.length,a=i<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(t,e,n,r);else for(var s=t.length-1;s>=0;s--)(o=t[s])&&(a=(i<3?o(a):i>3?o(e,n,a):o(e,n))||a);return i>3&&a&&Object.defineProperty(e,n,a),a};let S=class extends l.a{constructor(){super(...arguments),this.show=!1,this.closeModal=()=>{this.show=!1;const t=new CustomEvent("on-close",{});this.dispatchEvent(t)}}render(){return l.e`
      <infinito-modal style="--modal-padding:0;" .open=${this.show} .onCancel="${this.closeModal}">
        <div slot="body">
          <div class="container">
            <h2 class="title">${i18n("tip_question_title")}</h2>
            <span class="gap-line"></span>
            <div class="global-scrollbar" style="height: calc(100% - 81px);">
              <div class="content">
                <div class="card">
                  <div class="label">${i18n("tip_question_1")}</div>
                  <div class="img-box">
                    <img class="item-img" src="${n(526)}" alt="" />
                  </div>
                </div>
                <div class="card">
                  <div class="label">${i18n("tip_question_2")}</div>
                  <div class="img-box img-box-2">
                    <img class="item-img" src="${n(527)}" alt="" />
                    <div class="item-tip">${i18n("copy")}</div>
                  </div>
                </div>
                <div class="card">
                  <div class="label">${i18n("tip_question_3")}</div>
                  <div class="img-box img-box-3">
                    <img class="item-img" src="${n(528)}" alt="" />
                    <div class="item-tip tip3-box">
                      <div class="tip3-item">
                        <div class="tip3-label-box">
                          <span class="tip3-label">${i18n("search_engine")}</span>
                        </div>
                        <span class="input">${i18n("placeholder_name")}</span>
                      </div>
                      <div class="tip3-item">
                        <div class="tip3-label-box">
                          <span class="tip3-label">${i18n("website_search_replace_char")}</span
                          ><img class="tip-question" src="${n(418)}" alt="" />
                        </div>
                        <span class="input">https://www.google.com/search?sxsrf=ALeKk02...</span>
                        <img class="tip3-arrow" src="${n(529)}" alt="" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </infinito-modal>
    `}};S.styles=[_.a,l.b`
      .container {
        width: 800px;
        height: 70vh;
        min-height: 400px;
        max-height: 1000px;
        text-align: center;
        box-sizing: border-box;
        overflow: hidden;
      }
      .title {
        margin: 26px auto;
        height: 28px;
        font-size: 20px;
        font-weight: 500;
        color: #333333;
        line-height: 28px;
      }
      .gap-line {
        margin: auto;
        display: block;
        width: 720px;
        height: 1px;
        background: #ebebeb;
      }
      .content {
        padding: 33px 114px 50px;
        padding-right: 0;
        width: 572px;
        box-sizing: content-box;
        text-align: left;
      }
      .card {
        padding-bottom: 50px;
      }
      .label {
        font-size: 16px;
        font-weight: 400;
        color: #333333;
        line-height: 22px;
      }
      .img-box {
        position: relative;
        margin-top: 20px;
      }
      .img-box .item-img {
        width: 572px;
        height: 235px;
      }
      .item-tip {
        position: absolute;
        font-size: 14px;
        font-weight: 400;
        color: #333333;
        line-height: 20px;
      }
      .img-box-2 .item-tip {
        top: 86px;
        left: 396px;
      }
      .tip3-box {
        top: 64px;
        left: 138px;
      }
      .tip3-item {
        position: relative;
        margin-bottom: 20px;
        width: 320px;
      }
      .tip3-label-box {
        margin-bottom: 12px;
        display: flex;
        align-items: center;
      }
      .tip3-label {
        height: 20px;
        font-size: 14px;
        font-weight: 500;
        color: #333333;
        line-height: 20px;
      }
      .tip3-item .input {
        display: block;
        overflow: hidden;
        text-overflow: clip;
        white-space: nowrap;
        word-break: keep-all;
        border-bottom: 1px solid #eeeeee;
        box-sizing: content-box;
        padding-bottom: 6px;
        width: 100%;
        font-size: 14px;
        font-weight: 400;
        color: #656565;
        opacity: 0.8;
        width: 319px;
        height: 20px;
        line-height: 20px;
      }
      .tip-question {
        margin-left: 2px;
        width: 16px;
        height: 16px;
      }
      .tip3-arrow {
        width: 30px;
        height: 30px;
        position: absolute;
        left: -34px;
        bottom: 10px;
      }
    `],O([Object(l.g)({type:Boolean})],S.prototype,"show",void 0),S=O([Object(l.c)("tip-question")],S);var j=n(397),k=n(238);function A(t,e){var n=Object.keys(t);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(t);e&&(r=r.filter((function(e){return Object.getOwnPropertyDescriptor(t,e).enumerable}))),n.push.apply(n,r)}return n}function T(t){for(var e=1;e<arguments.length;e++){var n=null!=arguments[e]?arguments[e]:{};e%2?A(Object(n),!0).forEach((function(e){i(t,e,n[e])})):Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(n)):A(Object(n)).forEach((function(e){Object.defineProperty(t,e,Object.getOwnPropertyDescriptor(n,e))}))}return t}var E,C=function(t,e,n,r){var o,i=arguments.length,a=i<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(t,e,n,r);else for(var s=t.length-1;s>=0;s--)(o=t[s])&&(a=(i<3?o(a):i>3?o(e,n,a):o(e,n))||a);return i>3&&a&&Object.defineProperty(e,n,a),a};let R=E=class extends p.a{constructor(){super(),this.sideRatio=1,this.isEdit=!1,this.popup=!1,this.iconType="custom-icon",this.readonlyTarget=!1,this.textareaHeight="auto",this.subSpin=!1,this.validate={name:null,image:null,target:null},this.validateMsg={image:""},this.tipQuestion=!1,this.preViewImgUrl="",this.cropper=null,this.manualBgText=!1,this.canvasCtx=null,this.canvasTextHeight=null,this.preViewImgData=null,this.needUploadImage=!1,this.needUploadColor=!1,this.colorTypeDefaultColor="rgba(255,71,52,1)",this.colors=["rgba(255,71,52,1)","rgba(255,122,9,1)","rgba(255,207,12,1)","rgba(42,233,121,1)","rgba(44,214,223,1)","rgba(0,116,255,1)","rgba(109,9,255,1)","rgba(255,36,160,1)"],this.value=Object.assign({},E.defaultValue)}get previewFont(){return 3*this.value.bgFont+"px 'PingFang SC', 'Microsoft Yahei', monospace, sans-serif"}get colorType(){return"color"===this.value.bgType}get imageType(){return"image"===this.value.bgType}firstUpdated(){this.initCanvas(),this.popup||this.initCropper()}disconnectedCallback(){d.a.destroy(),super.disconnectedCallback()}setTextareaHeight(){const t=this.value.bgText.split("\n");if(1===t.length)this.textareaHeight="auto";else{const e=16*t.length;this.textareaHeight=e+2+"px"}}initCropper(){this.cropper=d.a.create(),this.cropper.addEventListener("on-change",async t=>{const{data:e,color:n}=t.detail;this.value.bgColor=n,this.preViewImgData=e;const r=this.preViewImgUrl;this.preViewImgUrl=s.a.createObjectURL(this.preViewImgData),s.a.revokeObjectURL(r),this.needUploadImage=!0,this.value.bgImage&&this.changeValue({bgImage:""}),this._validateImg()})}initCanvas(){this.$preview&&(this.canvasCtx=this.$preview.getContext("2d"),this.canvasCtx.textAlign="center",this.canvasCtx.textBaseline="middle",this.popup?this.rerenderCanvas(!0,!0):this.rerenderCanvas(!0,!1))}rerenderCanvas(t,e=!0){}_chooseImg(t){const e=(t.target.files||t.dataTransfer.files)[0],n=new FileReader;n.readAsDataURL(e),t.currentTarget.value=null,n.onload=()=>{this.cropper.init(n.result,this.value.bgColor),this.cropper.show()}}_changeTarget(t,e=!1){e?this.changeValue({target:t.currentTarget.value.replace(/%25s/g,"%s")}):this.changeValue({target:t.currentTarget.value}),this._validateTarget(),this.isUserInput||this.getTargetInfo()}async getTargetInfo(){let t=this.value.target;if(!t)return;t.includes(":")||(t="http://"+t);if(!/^https?:\/\/(.+\.)+.+/.test(t))return;const e=await b.getTargetInfo(t,this.isAutoName);e&&(this.changeValue({name:e.name,bgText:e.bgText}),this.rerenderCanvas(),this.isAutoName=!0)}_validateTarget(){const t=this.value.target;let e=!0;return t&&("search-engine-custom"!==this.iconType&&"search-engnie-add"!==this.iconType||t.includes("%s"))||(e=!1),this.changeValidate({target:e}),e}_validateImg(t=""){return"image"===this.value.bgType?this.preViewImgUrl||this.value.bgImage?this.changeValidate({image:!0}):this.changeValidate({image:!1},{image:t}):this.changeValidate({image:!0}),this.validate.image}_validateName(t){return t||"custom-icon"===this.iconType?this.changeValidate({name:!0}):this.changeValidate({name:!1}),t}getAllDate(){}_validateAll(){this.changeValue({name:this.$name.value,target:this.$target.value}),this._validateName(this.value.name),this._validateImg(this.validateMsg.image),this._validateTarget();for(const t in this.validate)if(Object.prototype.hasOwnProperty.call(this.validate,t)){if(!1===this.validate[t])return!1}return!0}changeValidate(t,e){this.validate=Object.assign(Object.assign({},this.validate),t),e&&(this.validateMsg=Object.assign(Object.assign({},this.validateMsg),e))}saveImage(){return new u.a((t,e)=>{"color"===this.value.bgType?(this.changeValue({bgColorImage:null}),t(null)):"image"===this.value.bgType&&b.uploadIcon(this.preViewImgData,this.iconType).then(({url:n,error:r})=>r?e(r):(this.changeValue({bgImage:n}),t(n)))})}async _submit(){if(!this._validateAll())return;if(this.needUploadImage&&"image"===this.value.bgType||this.needUploadColor&&"color"===this.value.bgType||""===this.value.bgColorImage&&"color"===this.value.bgType)try{this.subSpin=!0,await this.saveImage(),this.subSpin=!1}catch(t){return this.subSpin=!1,void(t&&t.message?x.message.error(t.message):x.message.error(t||"upload error"))}this.changeValue({bgColorImage:null});const t={value:Object.assign({},this.value)};"color"!==this.value.bgType||this.value.bgColor||(t.value.bgColor=this.colorTypeDefaultColor),t.value.target.includes(":")||(t.value.target="http://"+this.value.target);const e=new CustomEvent("on-submit",{detail:t});this.dispatchEvent(e)}_cancel(){const t=new CustomEvent("on-cancel");this.dispatchEvent(t)}changeValue(t){this.value=Object.assign(Object.assign({},this.value),t)}reset(){this.validate={name:null,image:null,target:null},this.validateMsg={image:""},this.preViewImgUrl&&(s.a.revokeObjectURL(this.preViewImgUrl),this.preViewImgUrl=""),this.preViewImgData=null,this.needUploadImage=!1,this.needUploadColor=!1,this.value=Object.assign({},E.defaultValue),this.canvasCtx.clearRect(0,0,this.$preview.width,this.$preview.height),this.canvasCtx.fillStyle=this.colorTypeDefaultColor,this.canvasCtx.fillRect(0,0,this.$preview.width,this.$preview.height)}_editImg(){this.cropper.init(this.preViewImgUrl||this.value.bgImage,this.value.bgColor),this.cropper.show()}_delImg(t){t.stopPropagation(),this.preViewImgUrl?(this.preViewImgData=null,s.a.revokeObjectURL(this.preViewImgUrl),this.preViewImgUrl=""):this.changeValue({bgImage:""})}openTipQuestion(){this.tipQuestion=!0}_renderBasic(){const{value:t}=this;return"custom-icon"===this.iconType?l.e`<div .hidden="${this.popup}" class="item">
          <div class="label-box">
            <span class="label">${Object(w.i18n)("website_address")}</span
            ><span .hidden="${!1!==this.validate.target}" class="error">*${Object(w.i18n)("please_enter_url")}</span>
          </div>
          <input
            class="target"
            autocomplete="off"
            type="text"
            .value="${t.target||""}"
            .placeholder="${Object(w.i18n)("website_address")}"
            .readOnly="${this.readonlyTarget}"
            @input=${t=>{this._changeTarget(t)}}
          />
        </div>
        <div class="item">
          <div class="label-box">
            <span class="label">${Object(w.i18n)("website_name")}</span
            ><span .hidden="${!1!==this.validate.name}" class="error">*${Object(w.i18n)("name_error")}</span>
          </div>
          <input
            autocomplete="off"
            type="text"
            class="name"
            .value="${t.name||""}"
            .placeholder="${Object(w.i18n)("website_name")}"
            @input=${t=>{this.isAutoName=!1,this.isUserInput=!0;const e=t.currentTarget.value;if(!this.manualBgText){let t="";t=e.length>3?e.substr(0,2):e,this.changeValue({bgText:t}),this.rerenderCanvas()}this._validateName(t.currentTarget.value)}}
          />
        </div>`:l.e` <div class="item">
          <div class="label-box">
            <span class="label">${Object(w.i18n)("search_engine")}</span
            ><span .hidden="${!1!==this.validate.name}" class="error">*${Object(w.i18n)("search_engine_error")}</span>
          </div>
          <input
            autocomplete="off"
            .value="${t.name||""}"
            type="text"
            class="name"
            .placeholder="${Object(w.i18n)("placeholder_name")}"
            @input=${t=>{this.isAutoName=!1,this._validateName(t.currentTarget.value)}}
          />
        </div>
        <div class="item">
          <div class="label-box">
            <span class="label">${Object(w.i18n)("website_search_replace_char")}</span
            ><img
              @click="${this.openTipQuestion}"
              class="tip-question"
              src="${n(418)}"
              alt=""
            /><span .hidden="${!1!==this.validate.target}" class="error">*${Object(w.i18n)("format_error")}</span>
          </div>
          <textarea
            class="target global-scrollbar"
            rows="1"
            @input="${t=>this._changeTarget(t,!0)}"
            autocomplete="off"
            .value="${t.target||""}"
            .placeholder="${Object(w.i18n)("website_address")}"
          ></textarea>
        </div>`}render(){const t=this.sideRatio>.7?0:300*(this.sideRatio-.7),{value:e}=this;return l.e`
      ${this._renderBasic()}
      <div .hidden="${this.popup}" class="item">
        <infinito-radio-group
          @on-change="${t=>{if(this.changeValue({bgType:t.detail.selected}),"color"===t.detail.selected&&(this.rerenderCanvas(!0),!this.value.bgText&&this.value.name)){let t="";t=this.value.name.length>3?this.value.name.substr(0,2):this.value.name,this.changeValue({bgText:t})}}}"
          .selected="${e.bgType}"
        >
          <infinito-radio value="color">${Object(w.i18n)("pure_color")}</infinito-radio>
          <infinito-radio value="image">${Object(w.i18n)("icon")}</infinito-radio>
        </infinito-radio-group>
      </div>
      <div class="box-dynamic">
        <div .hidden="${!this.colorType}" class="item item-icon">
          <div class="svg-box">
            <div class="svg-text" style="">
              ${Object(j.a)(Object(k.a)(T(T({},this.value),{},{bgColor:this.value.bgColor||this.colors[0]})))}
            </div>
          </div>
          <!-- <canvas id="icon-preview" width="280" height="280"></canvas> -->
        </div>
        <div .hidden="${!this.colorType}" class="item">
          <div class="label-box"><span class="label">${Object(w.i18n)("show_name")}</span></div>
          <textarea
            class="input global-scrollbar"
            rows="1"
            style="height:${this.textareaHeight}"
            autocomplete="off"
            @input="${t=>{this.manualBgText=!0,this.changeValue({bgText:t.currentTarget.value.slice(0,80)}),this.setTextareaHeight(),this.rerenderCanvas(),this.isAutoName=!1}}"
            .value="${e.bgText}"
            .placeholder="${Object(w.i18n)("show_name")}"
          ></textarea>
        </div>
        <div .hidden="${!this.colorType}" class="item">
          <div class="label-box"><span class="label">${Object(w.i18n)("font_size")}</span></div>
          <infinito-slider
            @on-change="${t=>{this.changeValue({bgFont:t.detail.value}),this.rerenderCanvas(!0)}}"
            .value=${e.bgFont}
            .min=${14}
            .max=${74}
          ></infinito-slider>
        </div>
        <div .hidden="${!this.colorType}" class="item">
          <div class="label-box"><span class="label">${Object(w.i18n)("color")}</span></div>
          <i-colorpicker
            .side="${!this.popup}"
            .value="${e.bgColor||this.colorTypeDefaultColor}"
            .colors="${this.colors}"
            .offsetRight="${t}"
            @on-change="${t=>{this.changeValue({bgColor:t.detail.value}),this.rerenderCanvas()}}"
          ></i-colorpicker>
        </div>
        <div .hidden="${!this.imageType}" class="item img-item-box">
          <div class="img-item">
            <input
              @drop="${this._chooseImg}"
              accept="image/*"
              @change="${this._chooseImg}"
              type="file"
              id="imgType"
              style="position:absolute;clip:rect(0 0 0 0);"
            />
            <label .hidden="${!!e.bgImage||!!this.preViewImgUrl}" class="img-dropper" for="imgType">
              <i-usesvg style="color:#C3C3C3;width:22px;height:22px" type="icon-xingzhuangjiehe2x" iconfont></i-usesvg>
            </label>
            <div
              .hidden="${!e.bgImage&&!this.preViewImgUrl}"
              class="img-dropper img-preview"
              style="background-color:${this.value.bgColor||"transparent"}; background-image: url('${this.preViewImgUrl||e.bgImage}')"
              @click="${this._editImg}"
            >
              <div class="editing">
                <img class="editing-icon" src="${n(530)}" alt="" />
              </div>
              <img class="del" @click="${this._delImg}" src="${n(531)}" alt="" />
            </div>
          </div>
          <span .hidden="${!1!==this.validate.image}" class="error"
            >* ${this.validateMsg.image||Object(w.i18n)("please_upload_photos")}</span
          >
        </div>
      </div>
      <div class="item btn-box">
        <infinito-button primary .loading="${this.subSpin}" @click="${this._submit}"
          >${Object(w.i18n)("confirm")}</infinito-button
        >
        ${"custom-icon"!==this.iconType||this.isEdit?l.e`<infinito-button class="btn-cancel" @click="${this._cancel}">${Object(w.i18n)("cancel")}</infinito-button>`:""}
      </div>
      <infinito-portal-entrance destination="tip-question">
        <tip-question
          @on-close="${()=>{this.tipQuestion=!1}}"
          .show="${this.tipQuestion}"
        ></tip-question>
      </infinito-portal-entrance>
    `}};R.styles=[_.a,h],R.defaultValue={bgType:"color",bgColor:"",bgFont:30,bgText:"",bgImage:"",target:"",name:"",bgColorImage:""},C([Object(l.g)({type:Number})],R.prototype,"sideRatio",void 0),C([Object(l.g)({type:Boolean})],R.prototype,"isEdit",void 0),C([Object(l.g)({type:Boolean})],R.prototype,"popup",void 0),C([Object(l.g)({type:String})],R.prototype,"iconType",void 0),C([Object(l.g)({type:Boolean})],R.prototype,"readonlyTarget",void 0),C([Object(l.g)({type:Object})],R.prototype,"value",void 0),C([Object(l.f)()],R.prototype,"textareaHeight",void 0),C([Object(l.f)()],R.prototype,"subSpin",void 0),C([Object(l.f)()],R.prototype,"isAutoName",void 0),C([Object(l.f)()],R.prototype,"isUserInput",void 0),C([Object(l.f)()],R.prototype,"validate",void 0),C([Object(l.f)()],R.prototype,"validateMsg",void 0),C([Object(l.f)()],R.prototype,"tipQuestion",void 0),C([Object(l.f)()],R.prototype,"preViewImgUrl",void 0),C([Object(l.h)(".target")],R.prototype,"$target",void 0),C([Object(l.h)(".name")],R.prototype,"$name",void 0),C([Object(l.h)("#icon-preview")],R.prototype,"$preview",void 0),R=E=C([Object(l.c)("i-editicon")],R)},,,,,,,function(t,e,n){"use strict";n.r(e),n.d(e,"userStore",(function(){return _}));n(10),n(52),n(13),n(17),n(18);var r=n(7),o=n.n(r),i=n(251),a=n.n(i),s=n(105),c=n.n(s),u=n(3),l=n(246),p=n(81),h=n(0),d=n(122),f=n(26),g=n.n(f),v=n(188),m=n(178),y=n(392),b=n(391),w=function(t,e,n,r){var o,i=arguments.length,a=i<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(t,e,n,r);else for(var s=t.length-1;s>=0;s--)(o=t[s])&&(a=(i<3?o(a):i>3?o(e,n,a):o(e,n))||a);return i>3&&a&&Object.defineProperty(e,n,a),a};class x extends l.a{constructor(){super(),this.isExpired=!1,this.isLogin=!1,this.token="",this.userInfo={},this.refreshToken="",this.mobileloginExpire=0,this.mobileloginUrl="",this.userProfilePromise=o.a.resolve(),this.wpColorUpdate=0,this.logining=!1,this.modalOpen=!1,this.removeAccountDisableSec=10,this.removeAccountDisableTimer=null,this.showLoginTipModal=!1,this.profileModal=!1,this.syncListModal=!1,this.isModify=!1,this.countdownTimer=null,this.checkMobileUrlTimer=null,this.isShowLogoutConfirm=!1,this.showConfirmOpt="",this.clearAllData=!1,this.loading=!1,this.URL=h.x}setWpColorUpdate(t){this.wpColorUpdate=t}closeModal(){this.modalOpen=!1}openModal(){this.modalOpen=!0}toggleLoginTipModal(){this.showLoginTipModal=!this.showLoginTipModal}closeLoginTipModal(){this.showLoginTipModal=!1}closeProfileModal(){this.profileModal=!1}openProfileModal(){this.profileModal=!0}closeSyncListModal(){this.syncListModal=!1}openSyncListModal(){this.syncListModal=!0}openModify(){this.isModify=!0}async modifyProfile(t){try{const e=await p.g.updateProfile(t);Object(u.i)(()=>{if(e&&0===e.code){const{user:{name:t,gender:n,avatar:r}}=e.data;this.userInfo.name=t,this.userInfo.gender=n,this.userInfo.avatar=r,this.closeModify()}else d.message.error(i18n("update_data_failure"))})}catch(t){d.message.error(t.message)}}async getUserProfile(){const t=await p.g.getUserProfile();Object(u.i)(()=>{if(t)if(0===t.code&&this.isLogin){const{gender:e,name:n,avatar:r}=t.data;this.userInfo.name=n,this.userInfo.gender=e,this.userInfo.avatar=r,this.userInfo["auto-backup"]=t.data["auto-backup"],this.userInfo["wp-color-update"]=t.data["wp-color-update"]}else 3012===t.code&&(d.message.error(t.message),this.exitAccount())})}async updateAvatar(t){try{return await p.g.uploadAvatar(t)}catch(t){d.message.error(i18n("upload_avatar_failure"))}}closeModify(){this.isModify=!1}thirdPartyLogin(t){let e;switch(this.logining=!0,t){case"facebook":e=this.URL+"/login/facebook";break;case"google":e=this.URL+"/login/google";break;case"qq":const t=encodeURIComponent("https://infinity-api.infinitynewtab.com/on-login/qq");e="https://graph.qq.com/oauth2.0/show?which=Login&display=pc&response_type=code&client_id=101410947&redirect_uri="+t;break;case"sina":e=this.URL+"/login/weibo";break;case"wechat":const n=encodeURIComponent("https://infinity-api.infinitynewtab.com/on-login/wechat");e="https://open.weixin.qq.com/connect/qrconnect?state=123&appid=wx5af98300f5d18d16&response_type=code&scope=snsapi_login&redirect_uri="+n}setTimeout(async()=>{const t=Math.floor(window.screenY+200),n=Math.floor(window.screenX+window.innerWidth/3),r=window.open(e,"_blank",`top=${t},left=${n},height=600,width=770,menubar=no,toolbar=yes,location=yes,status=no,resizable=no`);if(this.opener=r,h.n)return;const o=setInterval(()=>{r.postMessage({from:"origin_login"},"*")},300),i=t=>{if(!t.data&&!t.data.key&&"login"!==t.data.key)return;clearInterval(o),window.removeEventListener("message",i,!1);const{message:e}=t.data;this.login3rdSuccess(e)};window.addEventListener("message",i,!1)},300)}async login(t){const e=await p.g.login(t);Object(u.i)(()=>{if(!e||0!==e.code)throw d.message.error(e.message),new Error(e.code);this.loginEmailSuccess(e.data.user),this.setToken(e.data),this.setRefreshToken(e.data.refreshToken)})}async getMobileloginUrl(t=!1){if(t&&(this.mobileloginUrl="",this.mobileloginExpire=0),v.e){const{data:t,error:e}=await p.g.getMobileloginUrl();if(e)return void Object(u.i)(()=>{this.mobileloginExpire=0});Object(u.i)(()=>{this.mobileloginUrl=t.url,this.mobileloginExpire=Math.floor(t.expire/1e3)}),this.checkMobileloginUrl(t.code,t.type),0!==this.mobileloginExpire&&(this.countdownTimer=setInterval(()=>{Object(u.i)(()=>{this.mobileloginExpire-=1}),this.mobileloginExpire<=0&&clearInterval(this.countdownTimer)},1e3))}}async checkMobileloginUrl(t,e,n=5e3){v.e&&this.mobileloginExpire>3&&(clearTimeout(this.checkMobileUrlTimer),this.checkMobileUrlTimer=setTimeout(async()=>{const{data:r}=await p.g.checkMobileloginUrl(t,e);if(r&&r.expired)return clearInterval(this.countdownTimer),void Object(u.i)(()=>{this.mobileloginExpire=0});this.checkMobileloginUrl(t,e,n)},n))}async loginEmailSuccess(t){this.logining=!1,this.closeModal(),this.isLogin=!0,this.userInfo=t,this.isExpired=!1,this.settingLoginSuccess()}setUserData(t){this.logining=!1,this.closeModal(),this.isLogin=t.isLogin,this.userInfo=t,this.isExpired=!1;["token","refreshToken","isLogin"].forEach(t=>delete this.userInfo[t])}async login3rdSuccess(t){if(!t||!Object.keys(t).length)return void this.cancelLogin();const e=t["login-type"];if(["qq","wechat"].includes(e)){const e=await p.g.loginWithUid(t);0===e.code?Object(u.i)(()=>{this.setUserData(t),this.setToken(e.data),this.setRefreshToken(e.data.refreshToken)}):3006===e.code&&d.message.error("获取token失败")}else this.setUserData(t),this.setToken(t),this.setRefreshToken(t.refreshToken);this.settingLoginSuccess()}settingLoginSuccess(){b.b.changeSetting("view","isHideIcp",!0)}cancelLogin(){var t;this.logining=!1,null===(t=this.opener)||void 0===t||t.close()}toggleClear(t){this.clearAllData=t}logout(t){this.isShowLogoutConfirm=!0,this.showConfirmOpt=t,"remove"===t&&(this.removeAccountDisableSec=10,clearInterval(this.removeAccountDisableTimer),this.removeAccountDisableTimer=setInterval(()=>{Object(u.i)(()=>{this.removeAccountDisableSec-=1,0===this.removeAccountDisableSec&&(clearInterval(this.removeAccountDisableTimer),this.removeAccountDisableTimer=null)})},1e3))}async exitAccount(){this.loading=!0,this.isLogin=!1,this.userInfo={},this.clearToken(),await new o.a(t=>{setTimeout(()=>{this.clearAllData?this.clearAllStore().then(t):t(null)},200)}),this.clearAllData?window.location.reload():(Object(u.i)(()=>this.loading=!1),this.closeLogoutConfirm(),this.closeProfileModal(),h.r&&y.pluginStore.hideLast())}async deleteAccount(){this.loading=!0;const t=await p.g.deleteAccount();Object(u.i)(()=>{t&&0===t.code?this.exitAccount():(3012===t.code&&this.exitAccount(),d.message.error(t.message)),this.loading=!1})}preserveStorageKeys(){const t=[];return["store-privacy"].forEach(e=>t.push({key:e,data:localStorage.getItem(e)})),t}restoreKeysToStorage(t){t.forEach(({data:t,key:e})=>localStorage.setItem(e,t))}async clearAllStore(){this.stopAutoBackupReaction(),this.stopToStorageReaction();!h.r&&await new o.a(t=>chrome.storage.local.clear(t)),this._clearLocalStorage(["store-privacy","store-setting->permission","store-search->ignoreSuggest","first-installed"]),await this._deleteIdb(["store-notes","store-todo","store-sync","store-wallpaper","store-wallpaper-cache","infinity-image-base64"]),m.slave.sendMessage("tabs-reload")}async _deleteIdb(t){const e=await new o.a(t=>a()(g.a).call(g.a,(e,n)=>t(n)));await o.a.all(t.map(t=>new o.a(n=>{const r=t.split("->");if(1===r.length)return e.includes(t)?void g.a.removeItem(t,n):void n(null);n(null),e.includes(r[0])&&g.a.getItem(r[0],t=>{c()(r).call(r,(t,e,n)=>(n===r.length-1&&Reflect.deleteProperty(t,e),t[e]),t),g.a.setItem(r[0],n)})})))}_clearLocalStorage(t){const e=new Map;t.filter(Boolean).forEach(t=>{const n=t.split("->");if(1===n.length)return void e.set(t,localStorage.getItem(t));const r=JSON.parse(localStorage.getItem(n[0]));n.slice(1).forEach((t,e)=>{const o=0===e?r:r[n[e]];for(const e in o)t!==e&&Reflect.deleteProperty(o,e)}),e.set(n[0],JSON.stringify(r))}),localStorage.clear();for(const t of a()(e).call(e))localStorage.setItem(t,e.get(t))}closeLogoutConfirm(){this.isShowLogoutConfirm=!1}setToken(t){this.token=t.token}setRefreshToken(t){this.refreshToken=t}clearToken(){this.token="",this.refreshToken=""}setOutdated(){this.isExpired=!0,this.isLogin=!1}toggleReLogin(){this.isExpired=!1}}w([u.g],x.prototype,"isExpired",void 0),w([u.g],x.prototype,"isLogin",void 0),w([u.g],x.prototype,"token",void 0),w([u.g],x.prototype,"userInfo",void 0),w([u.g],x.prototype,"refreshToken",void 0),w([u.g],x.prototype,"mobileloginExpire",void 0),w([u.g],x.prototype,"mobileloginUrl",void 0),w([u.g],x.prototype,"wpColorUpdate",void 0),w([u.b],x.prototype,"setWpColorUpdate",null),w([u.g],x.prototype,"opener",void 0),w([u.g],x.prototype,"logining",void 0),w([u.g],x.prototype,"modalOpen",void 0),w([u.g],x.prototype,"removeAccountDisableSec",void 0),w([u.g],x.prototype,"removeAccountDisableTimer",void 0),w([u.b],x.prototype,"closeModal",null),w([u.b],x.prototype,"openModal",null),w([u.g],x.prototype,"showLoginTipModal",void 0),w([u.b],x.prototype,"toggleLoginTipModal",null),w([u.b],x.prototype,"closeLoginTipModal",null),w([u.g],x.prototype,"profileModal",void 0),w([u.g],x.prototype,"syncListModal",void 0),w([u.b],x.prototype,"closeProfileModal",null),w([u.b],x.prototype,"openProfileModal",null),w([u.b],x.prototype,"closeSyncListModal",null),w([u.b],x.prototype,"openSyncListModal",null),w([u.g],x.prototype,"isModify",void 0),w([u.b],x.prototype,"openModify",null),w([u.b],x.prototype,"modifyProfile",null),w([u.b],x.prototype,"getUserProfile",null),w([u.b],x.prototype,"updateAvatar",null),w([u.b],x.prototype,"closeModify",null),w([u.b],x.prototype,"thirdPartyLogin",null),w([u.b],x.prototype,"login",null),w([u.b],x.prototype,"getMobileloginUrl",null),w([u.b],x.prototype,"checkMobileloginUrl",null),w([u.b],x.prototype,"loginEmailSuccess",null),w([u.b],x.prototype,"setUserData",null),w([u.b],x.prototype,"login3rdSuccess",null),w([u.b],x.prototype,"cancelLogin",null),w([u.g],x.prototype,"isShowLogoutConfirm",void 0),w([u.g],x.prototype,"showConfirmOpt",void 0),w([u.g],x.prototype,"clearAllData",void 0),w([u.b],x.prototype,"toggleClear",null),w([u.b],x.prototype,"logout",null),w([u.g],x.prototype,"loading",void 0),w([u.b],x.prototype,"exitAccount",null),w([u.b],x.prototype,"deleteAccount",null),w([u.b],x.prototype,"clearAllStore",null),w([u.b],x.prototype,"closeLogoutConfirm",null),w([u.b],x.prototype,"setToken",null),w([u.b],x.prototype,"setRefreshToken",null),w([u.b],x.prototype,"clearToken",null),w([u.b],x.prototype,"setOutdated",null),w([u.b],x.prototype,"toggleReLogin",null);const _=new x;Object(u.c)(()=>{_.isLogin&&(_.userProfilePromise=_.getUserProfile())}),_.initSyncStore("store-user",["userInfo","isLogin","token","refreshToken","wpColorUpdate"])},function(t,e,n){"use strict";n.d(e,"b",(function(){return g})),n.d(e,"a",(function(){return m}));n(13),n(17),n(18),n(10),n(52);var r=n(3),o=n(246),i=n(14),a=n(97),s=n(130),c=n(250),u=n(0),l=n(345),p=n(360),h=n(247),d=function(t,e,n,r){var o,i=arguments.length,a=i<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(t,e,n,r);else for(var s=t.length-1;s>=0;s--)(o=t[s])&&(a=(i<3?o(a):i>3?o(e,n,a):o(e,n))||a);return i>3&&a&&Object.defineProperty(e,n,a),a};class f extends o.a{constructor(){super(...arguments),this.localSettings={},this.innerWidth=window.innerWidth,this.innerHeight=window.innerHeight,this.iconSpaceWidth=0,this.iconSpaceHeight=0,this.setting=this.init(),this.updatetime=0,this.permission={topUseful:-1,topBookmark:-1,searchSuggest:-1,gmailNotice:-1,gmailCount:-1,todoNotice:-1},this.logs=new Map,this.permissionMapper={topBookmark:[["bookmarks"],["chrome://favicon/"]],topUseful:[["topSites"],["chrome://favicon/"]],searchSuggest:[[],["https://suggestion.baidu.com/","https://google.com/"]],gmailNotice:[["notifications"],["https://mail.google.com/"]],gmailCount:[[],["https://mail.google.com/"]],todoNotice:[["notifications"],[]]},this.showSettingHomeModal=!1,this.webClickName=""}init(t={}){return{notice:Object.assign({},s.b.notice),link:Object.assign({},s.b.link),view:Object.assign({},s.b.view),layout:Object.assign({},s.b.layout),animation:Object.assign({},s.b.animation),icon:Object.assign({},s.b.icon),search:Object.assign({},s.b.search),font:Object.assign({},s.b.font),_v1Setting:t}}get withPermissionTopUseful(){return this.setting.view.topUseful&&1===this.permission.topUseful}get withPermissionTopBookmark(){return this.setting.view.topBookmark&&1===this.permission.topBookmark}get withPermissionSearchSuggest(){return this.setting.search.searchSuggest&&1===this.permission.searchSuggest}get needPermissionList(){const t=[],{view:e,notice:n,search:r}=this.setting,{topUseful:o,topBookmark:i,searchSuggest:a,gmailNotice:s,gmailCount:c,todoNotice:p}=this.permission;return u.m&&r.searchSuggest&&1!==a&&t.push({key:"searchSuggest",title:i18n("permission_serch_suggest_title"),content:i18n("permission_serch_suggest_content")}),u.m&&n.gmail&&1!==s&&t.push({key:"gmailNotice",title:i18n("permission_gmail_notice_title"),content:i18n("permission_gmail_notice_content")}),u.m&&n.gmailNumber&&1!==c&&t.push({key:"gmailCount",title:i18n("permission_gmail_num_title"),content:i18n("permission_gmail_num_content")}),!u.r&&e.topBookmark&&1!==i&&t.push({key:"topBookmark",title:i18n("permission_top_bookmark_title"),content:i18n("permission_top_bookmark_content")}),!u.r&&e.topUseful&&1!==o&&t.push({key:"topUseful",title:i18n("permission_top_useful_title"),content:i18n("permission_top_useful_content")}),l.a.needNotificationPermission&&1!==p&&(u.r&&"denied"===Notification.permission||t.push({key:"todoNotice",title:i18n("permission_todo_notice_title"),content:i18n("permission_todo_notice_content")})),t}get sideRatio(){return this.setting.view.scaleSide}reset(){this.setting=this.init(this.setting._v1Setting)}diffRemote(t){return!r.d.structural(t.setting||{},this.setting)}sendSettingValue(){Object.keys(this.localSettings).length&&(h.a.sendEvent({settingValue:this.localSettings}),this.localSettings={})}async mergeRemote(t){const e=t.setting;if(!t.setting)return;const n=this.setting;this.setting={notice:Object.assign(Object.assign({},n.notice),e.notice),link:Object.assign(Object.assign({},n.link),e.link),view:Object.assign(Object.assign({},n.view),e.view),layout:Object.assign(Object.assign({},n.layout),e.layout),animation:Object.assign(Object.assign({},n.animation),e.animation),icon:Object.assign(Object.assign({},n.icon),e.icon),search:Object.assign(Object.assign({},n.search),e.search),font:Object.assign(Object.assign({},n.font),e.font),_v1Setting:e._v1Setting};const o=await i.a.getTimestamp();Object(r.i)(()=>{this.updatetime=o})}sendSettingLog(t,e){this.logs.has(t)&&clearTimeout(this.logs.get(t)),this.logs.set(t,setTimeout(()=>{h.a.sendEvent({settingAction:{[t]:e}}),this.logs.delete(t)},2e3))}async changeSetting(t,e,n){if(this.setting[t][e]===n)return;this.setting[t][e]=n;let o=`${t}_${e}`,a=n;"layout"!==t||"col"!==e&&"row"!==e||(o="layout",a=this.setting.layout.row+"*"+this.setting.layout.col),this.sendSettingLog(o,a),this.localSettings[o]=a;const s=await i.a.getTimestamp();Object(r.i)(()=>{this.updatetime=s}),this.changeSettingEffect(t,e,n)}changeSettingEffect(t,e,n){switch(!0){case"topBookmark"===e:n&&this.requestPermission("topBookmark",!0);break;case"topUseful"===e:n&&this.requestPermission("topUseful",!0);break;case"notice"===t&&"gmail"===e:n&&this.requestPermission("gmailNotice",!0);break;case"notice"===t&&"gmailNumber"===e:n&&this.requestPermission("gmailCount",!0);break;case"searchSuggest"===e:n&&this.requestPermission("searchSuggest",!0)}}async checkPermission(t){if(u.r){switch(t){case"todoNotice":"granted"===Notification.permission?this.permission[t]=1:"default"===Notification.permission?this.permission[t]=-1:this.permission[t]=0}return}if(1===this.permission[t])return;const e=this.permissionMapper[t];try{await a.a.has(e[0],e[1])&&Object(r.i)(()=>{this.permission[t]=1})}catch(t){}}async requestPermission(t,e=!1){if(u.r&&["todoNotice"].includes(t))return await Object(p.a)(),void Object(r.i)(()=>{this.permission.todoNotice=1});const n=this.permissionMapper[t];if(e||0!==this.permission[t]&&1!==this.permission[t])try{await a.a.request(n[0],n[1]),Object(r.i)(()=>{this.permission[t]=1}),"gmailNotice"===t&&this.checkPermission("todoNotice")}catch(e){e&&"REJECT"===e.message&&Object(r.i)(()=>{this.permission[t]=0})}}async requestAllPermission(){if(u.r)return await Object(p.a)(),void Object(r.i)(()=>{this.permission.todoNotice=1});const t=[[],[]];this.needPermissionList.forEach(e=>{const n=this.permissionMapper[e.key];t[0].push(...n[0]),n&&t[1].push(...n[1])});try{await a.a.request(t[0],t[1]),Object(r.i)(()=>{this.needPermissionList.forEach(t=>{this.permission[t.key]=1})})}catch(t){Object(r.i)(()=>{this.needPermissionList.forEach(t=>{this.permission[t.key]=0})})}}resetPermission(t){this.permission[t]=-1}setIconSpace(t){this.setting.icon.scale=t.iconScale,this.setting.layout.colGap=t.colGap,this.setting.layout.rowGap=t.rowGap,this.setting.search.scale=t.searchScale}openSearchSuggest(){this.setting.search.searchSuggest?this.requestPermission("searchSuggest",!0):this.setting.search.searchSuggest=!0}get sideScaleRatio(){return this.setting.view.scaleSide}toggleShowSettingHome(t){this.setting.view.isShowHomepageBtn=!t}toggleSettingHomeModal(){this.webClickName="",this.showSettingHomeModal=!this.showSettingHomeModal}closeSettingHomeModal(){this.showSettingHomeModal=!1}setWebClickName(t){this.webClickName=t}}d([r.g],f.prototype,"innerWidth",void 0),d([r.g],f.prototype,"innerHeight",void 0),d([r.g],f.prototype,"iconSpaceWidth",void 0),d([r.g],f.prototype,"iconSpaceHeight",void 0),d([r.g],f.prototype,"setting",void 0),d([r.g],f.prototype,"updatetime",void 0),d([r.g],f.prototype,"permission",void 0),d([r.e],f.prototype,"withPermissionTopUseful",null),d([r.e],f.prototype,"withPermissionTopBookmark",null),d([r.e],f.prototype,"withPermissionSearchSuggest",null),d([r.e],f.prototype,"needPermissionList",null),d([r.e],f.prototype,"sideRatio",null),d([r.b],f.prototype,"reset",null),d([r.b],f.prototype,"mergeRemote",null),d([r.b],f.prototype,"changeSetting",null),d([r.b],f.prototype,"checkPermission",null),d([r.b],f.prototype,"requestPermission",null),d([r.b],f.prototype,"requestAllPermission",null),d([r.b],f.prototype,"resetPermission",null),d([r.b],f.prototype,"setIconSpace",null),d([r.b],f.prototype,"openSearchSuggest",null),d([r.e],f.prototype,"sideScaleRatio",null),d([r.b],f.prototype,"toggleShowSettingHome",null),d([r.g],f.prototype,"showSettingHomeModal",void 0),d([r.b],f.prototype,"toggleSettingHomeModal",null),d([r.b],f.prototype,"closeSettingHomeModal",null),d([r.g],f.prototype,"webClickName",void 0),d([r.b],f.prototype,"setWebClickName",null);const g=new f;g.initSyncStore("store-setting",["setting","permission","updatetime"],s.b),g.initAutoBackup("setting",["setting"]),Object(r.c)(()=>{g.firstSync&&g.setting.view.topBookmark&&g.checkPermission("topBookmark")},{delay:50}),Object(r.c)(()=>{g.firstSync&&g.setting.view.topUseful&&g.checkPermission("topUseful")},{delay:50}),Object(r.c)(()=>{g.firstSync&&g.setting.notice.gmail&&g.checkPermission("gmailNotice")},{delay:50}),Object(r.c)(()=>{l.a.firstSync&&l.a.needNotificationPermission&&g.checkPermission("todoNotice")},{delay:50}),Object(r.c)(()=>{g.firstSync&&g.setting.notice.gmailNumber&&g.checkPermission("gmailCount")},{delay:50}),Object(r.c)(()=>{g.firstSync&&g.setting.search.searchSuggest&&g.checkPermission("searchSuggest")},{delay:50}),Object(r.c)(()=>{g.firstSync&&1===g.permission.gmailNotice&&i.a.send({key:"bg-notice-gmail-permission",data:!0})}),Object(r.c)(()=>{if(g.firstSync){const{gmail:t,gmailVoice:e,gmailNumber:n}=g.setting.notice,{gmailCount:r,gmailNotice:o}=g.permission;i.a.send({key:"bg-notice-gmail-updated",data:{gmail:t&&1===o,gmailVoice:e,gmailNumber:n&&(1===o||1===r)}})}},{delay:100}),Object(r.c)(()=>{if(!0===g.setting.layout.custom){const{customItem:t}=g.setting.layout;Object(r.i)(()=>{g.setting.layout.row=t[0],g.setting.layout.col=t[1]})}}),Object(r.c)(()=>{if(g.firstSync){const t={"--side-ratio":g.sideRatio,"--main-ratio":g.setting.view.scaleMain,"--icon-radius":Math.round(100*g.setting.icon.radius)+"%","--icon-font-color":g.setting.font.color,"--icon-font-size":Math.ceil(Math.max(g.setting.font.size*g.setting.view.scaleMain,12))+"px","--icon-opacity":g.setting.icon.opacity,"--icon-visible":g.setting.icon.isHideIconName?"hidden":"visible","--search-radius":""+g.setting.search.radius,"--search-opacity":g.setting.search.opacity};i.a.setStyle(t)}},{delay:50}),Object(r.c)(()=>{if(g.firstSync){let t=0,e=20;g.withPermissionTopBookmark&&(t+=36),g.withPermissionTopUseful&&(e+=26);const n={"--top-bar-height":t+"px","--settings-icon-top-offset":e+"px"};i.a.setStyle(n)}});const v=t=>{const e={"--search-height":t.searchHeight,"--search-width":t.searchWidth,"--search-margin-top":t.searchMarginTop,"--search-margin-bottom":t.searchMarginBottom,"--search-ratio":t.searchRatio,"--icon-box-width":t.iconBoxWidth,"--icon-box-height":t.iconBoxHeight,"--icon-one-height":t.iconOneHeight,"--icon-width":t.iconWidth,"--mini-icon-padding":t.miniIconPadding,"--icon-ratio":t.iconRatio,"--icon-row":g.setting.layout.row,"--icon-col":g.setting.layout.col,"--main-icons-margin":t.iconsMargin};i.a.setStyle(e)},m=(t=!0)=>{const e={row:g.setting.layout.row,col:g.setting.layout.col,rowGap:g.setting.layout.rowGap,colGap:g.setting.layout.colGap,iconScale:g.setting.icon.scale,searchScale:g.setting.search.scale,innerHeight:innerHeight,innerWidth:innerWidth,miniMode:g.setting.icon.miniMode,fontSize:g.setting.font.size,topUseful:g.withPermissionTopUseful,topBookmark:g.withPermissionTopBookmark,mainRatio:g.setting.view.scaleMain};if(t)requestIdleCallback(()=>{const t=Object(c.a)(e);v(t)});else{const t=Object(c.a)(e);v(t)}};Object(r.c)(()=>{g.firstSync&&m(!1)},{delay:40}),window.addEventListener("resize",i.a.throttle(()=>{m(!1)},56))},function(t,e,n){"use strict";n.r(e),n.d(e,"pluginStore",(function(){return l}));n(13),n(17),n(10);var r=n(3),o=n(97),i=n(359);class a extends i.a{opened(t){}}const s=Object(i.b)(new a);var c=function(t,e,n,r){var o,i=arguments.length,a=i<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(t,e,n,r);else for(var s=t.length-1;s>=0;s--)(o=t[s])&&(a=(i<3?o(a):i>3?o(e,n,a):o(e,n))||a);return i>3&&a&&Object.defineProperty(e,n,a),a};class u{constructor(){this.pluginsMap={"infinity://weather":"side-weather","infinity://todos":"side-todos","infinity://notes":"side-notes","infinity://history":"side-history","infinity://bookmarks":"side-bookmarks","infinity://extension":"side-extension","infinity://chrome-apps":"chrome-apps","infinity://wallpaper":"wallpaper","infinity://settings":"side-profile",search:"side-search",profile:"side-profile",editIcon:"side-editicon","side-tutorial":"side-tutorial"},this.pluginsTags={"side-weather":!1,"side-todos":!1,"side-notes":!1,"side-history":!1,"side-bookmarks":!1,"side-extension":!1,"chrome-apps":!1,"side-profile":!1,"side-search":!1,"side-editicon":!1,"side-tutorial":!1,wallpaper:!1},this.pluginViews=[],this.focusRepair=!1,Object(r.h)(()=>this.pluginViews.map(t=>t),([t])=>{s.opened(t)})}initDom(t){this.pluginsTags[t]=!0}async show(t){if(this.pluginViews.includes(t))return;const e=this.pluginsMap[t];if(!1===this.pluginsTags[e])try{await this.requestPermission(e),Object(r.i)(()=>{this.pluginsTags[e]=!0,this.pluginViews.push(t)})}catch(t){}else this.pluginViews.push(t)}async showRepair(){this.focusRepair=!0,this.show("profile"),localStorage.setItem("user-checkout-old-data","true")}blurRepair(){this.focusRepair=!1}requestPermission(t){switch(t){case"side-bookmarks":return o.a.request(["bookmarks"],["chrome://favicon/"]);case"side-extension":case"chrome-apps":return o.a.request(["management"]);case"side-history":return o.a.request(["history"],["chrome://favicon/"])}}hideLast(){const t=this.pluginViews.pop();return 0===this.pluginViews.length&&document.getElementsByTagName("newtab-main")[0].shadowRoot.querySelector(".swiper-content").style.setProperty("transform","none"),t}}c([r.g],u.prototype,"pluginsTags",void 0),c([r.b],u.prototype,"initDom",null),c([r.g],u.prototype,"pluginViews",void 0),c([r.g],u.prototype,"focusRepair",void 0),c([r.b],u.prototype,"show",null),c([r.b],u.prototype,"showRepair",null),c([r.b],u.prototype,"blurRepair",null),c([r.b],u.prototype,"hideLast",null);const l=new u},function(t,e,n){t.exports=n.p+"images/error.f782e7c.png"},function(t,e,n){t.exports=n.p+"images/remind.896ff6f.png"},function(t,e,n){"use strict";n(13),n(17);var r=n(1),o=function(t,e,n,r){var o,i=arguments.length,a=i<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(t,e,n,r);else for(var s=t.length-1;s>=0;s--)(o=t[s])&&(a=(i<3?o(a):i>3?o(e,n,a):o(e,n))||a);return i>3&&a&&Object.defineProperty(e,n,a),a};let i=class extends r.a{constructor(){super(...arguments),this.type="",this.iconfont=!1}render(){return this.iconfont?r.e`
        <svg part="svg">
          <use href="${n(443)}#${this.type}" style=${this.color?`fill: ${this.color};`:""}></use>
        </svg>
      `:r.e`
        <svg part="svg">
          <use href="${n(444)}#${this.type}"></use>
        </svg>
      `}};i.styles=r.b`
    :host {
      display: inline-flex;
      justify-content: center;
      align-items: center;
      width: 20px;
      height: 20px;
      color: #333;
    }
    svg {
      width: inherit;
      height: inherit;
      color: inherit;
      fill: currentColor;
    }
  `,o([Object(r.g)({type:String})],i.prototype,"type",void 0),o([Object(r.g)({type:Boolean})],i.prototype,"iconfont",void 0),o([Object(r.g)({type:String})],i.prototype,"color",void 0),i=o([Object(r.c)("i-usesvg")],i)},,function(t,e,n){"use strict";n.d(e,"a",(function(){return a}));var r=n(103),o=n(127);
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const i=new WeakMap,a=Object(o.e)(t=>e=>{if(!(e instanceof o.b))throw new Error("unsafeHTML can only be used in text bindings");const n=i.get(e);if(void 0!==n&&Object(r.h)(t)&&t===n.value&&e.value===n.fragment)return;const a=document.createElement("template");a.innerHTML=t;const s=document.importNode(a.content,!0);e.setValue(s),i.set(e,{value:t,fragment:s})})},function(t,e,n){"use strict";var r=(new Date).valueOf();function o(){return r++}var i=function(t){return localStorage.getItem(t)},a=function(t,e){localStorage.setItem(t,e)};function s(t){var e=[];for(var n in t){var r=t[n];null!=r&&!1!==r&&(!0===r&&(r=1),e.push(encodeURIComponent(n)+"="+encodeURIComponent(r)))}return e.join("&")}var c=function(){function t(t,e){for(var n=0;n<e.length;n++){var r=e[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(t,r.key,r)}}return function(e,n,r){return n&&t(e.prototype,n),r&&t(e,r),e}}(),u=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var n=arguments[e];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(t[r]=n[r])}return t},l=function(){function t(e){!function(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}(this,t);var n,r=this.baseInfo={v:1,tid:e.trackingId,uid:e.userId},o=i("ga:clientId");o||(n=Date.now()+performance.now(),o="xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,(function(t){var e=(n+16*Math.random())%16|0;return n=Math.floor(n/16),("x"===t?e:3&e|8).toString(16)})),a("ga:clientId",o)),r.cid=o,this.systemInfo={sr:screen.width+"x"+window.screen.height,sd:screen.colorDepth+"-bits",ul:navigator.language},this.extraInfo={dl:location.href.split("#")[0]}}return c(t,[{key:"getEventUrl",value:function(t){return this.getSendUrl("event",{ec:t.category,ea:t.action,el:t.label,ev:t.value,ni:!0===t.nonInteraction})}},{key:"event",value:function(t){return this.send("event",{ec:t.category,ea:t.action,el:t.label,ev:t.value,ni:!0===t.nonInteraction})}},{key:"getPageviewUrl",value:function(){var t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},e=this;return e.getSendUrl("pageview",{dl:t.location,dh:t.host,dp:t.page,dt:t.title||document.title})}},{key:"pageview",value:function(){var t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},e=this;return e.send("pageview",{dl:t.location,dh:t.host,dp:t.page,dt:t.title||document.title})}},{key:"send",value:function(t,e){var n=u({_t:o(),t:t},this.baseInfo,this.systemInfo,e),r=this.extraInfo;for(var i in r)null==n[i]&&(n[i]=r[i]);var a=new XMLHttpRequest,c="https://www.google-analytics.com/collect?"+s(n);return a.open("GET",c,!0),a.send(null),c}},{key:"getSendUrl",value:function(t,e){var n=u({_t:o(),t:t},this.baseInfo,this.systemInfo,e),r=this.extraInfo;for(var i in r)null==n[i]&&(n[i]=r[i]);return"https://www.google-analytics.com/collect?"+s(n)}}]),t}();l.version="1.0.2",e.a=l},function(t,e,n){"use strict";n(13),n(17),n(10);var r=n(1),o=n(344),i=(n(367),r.b`:host {
  display: block;
  position: relative;
  z-index: 999;
}
.color-pick-list {
  width: 100%;
  box-sizing: border-box;
  padding: 1px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  backface-visibility: hidden;
}
.color-item {
  position: relative;
  width: 18px;
  height: 18px;
  box-sizing: border-box;
  border-radius: 6px;
  cursor: pointer;
  background-color: currentColor;
}
.color-item::before {
  content: "";
  display: none;
  width: 0px;
  height: 0px;
  color: #fff;
  border-width: 0px 0px 2px 2px;
  padding: 3px 3px 3px 6px;
  border-style: solid;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -78%) rotate(-45deg);
}
.color-item.active::before {
  display: block;
}
.color-item.transparent {
  color: #ddd !important;
  background-position: 0 0, 5px 5px;
  background-size: 10px 10px;
  background-image: linear-gradient(45deg, #fff 25%, transparent 0, transparent 75%, #fff 0), linear-gradient(45deg, #fff 25%, transparent 0, transparent 75%, #fff 0);
}
.color-item.transparent i-svg {
  color: #fff !important;
  background: #ddd !important;
}
.color-item.transparent.active {
  background: #ddd;
  background-image: none;
}
.color-picker {
  position: absolute;
  bottom: 30px;
  right: 0;
  transform-origin: bottom right;
}
.side {
  transform: scale(calc(1 / var(--side-ratio)));
}
`),a=n(401),s=n.n(a),c=function(t,e,n,r){var o,i=arguments.length,a=i<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(t,e,n,r);else for(var s=t.length-1;s>=0;s--)(o=t[s])&&(a=(i<3?o(a):i>3?o(e,n,a):o(e,n))||a);return i>3&&a&&Object.defineProperty(e,n,a),a};let u=class extends r.a{constructor(){super(...arguments),this.value="",this.offsetRight=0,this.side=!1,this.name="",this.colors=["rgba(255,71,52,1)","rgba(255,122,9,1)","rgba(255,207,12,1)","rgba(42,233,121,1)","rgba(44,214,223,1)","rgba(0,116,255,1)","rgba(138,49,255,1)","transparent"],this.pickerStatus=!1,this.activeIndex=-1,this._close_picker_lock=!1,this._preClosePicker=()=>{this._close_picker_lock&&(this._close_picker_lock=!1)},this._postClosePicker=()=>{this._close_picker_lock||this._closePicker()},this._closePicker=()=>{this.pickerStatus=!1}}firstUpdated(){this._importColor(),this.resetActiveIndex(),window.addEventListener("mousedown",this._preClosePicker),window.addEventListener("mouseup",this._postClosePicker)}disconnectedCallback(){this._closePicker(),window.removeEventListener("mousedown",this._preClosePicker),window.removeEventListener("mouseup",this._postClosePicker),super.disconnectedCallback()}resetActiveIndex(){this.activeIndex=this.colors.findIndex(t=>t===this.value)}_importColor(){const t=document.querySelector("#script-vue"),e=document.querySelector("#script-color");if(!t){const t=document.createElement("script");t.src="/vendor/vue.min.js",t.id="script-vue",t.onload=()=>{if(!e){const t=document.createElement("script");t.src="/vendor/color-picker.min.js",t.id="script-color",document.body.append(t)}},document.body.append(t)}}_showPicker(t){t.stopPropagation(),this.pickerStatus=!0,"transparent"===this.value&&(this.value="#ff4734",this.activeIndex=-1,this._emitChange())}_pickColor(t){if(t instanceof CustomEvent){const{rgba:e}=t.detail[0],{r:n,g:r,b:o,a:i}=e;this.value=`rgba(${[n,r,o,i].join(",")})`,this.activeIndex=-1,this._emitChange()}}_pickThisColor(t){this.value=this.colors[t],this.activeIndex=t,this._emitChange()}_emitChange(){const t=new CustomEvent("on-change",{detail:{value:this.value}});this.dispatchEvent(t)}async performUpdate(){this.resetActiveIndex(),super.performUpdate()}updated(t){if(t.has("pickerStatus")&&!0===this.pickerStatus)try{this.$colorPicker.scrollIntoView({block:"nearest",behavior:"smooth"})}catch(t){}}render(){return r.e`
      <section class="color-pick-list">
        ${this.colors.map((t,e)=>r.e`<span
            @click="${()=>this._pickThisColor(e)}"
            class="${Object(o.a)({active:e===this.activeIndex,"color-item":!0,transparent:"transparent"===t})}"
            style="color:${t.includes("255,255,255")?"rgb(221,221,221)":t};"
          >
          </span>`)}
        <span
          @click="${this._showPicker}"
          class="color-item color-dropper ${-1===this.activeIndex&&this.value?"active":""}"
          style="background: url(${s.a}) no-repeat center; background-size: contain;"
        >
        </span>
      </section>
      <section
        @click="${t=>{t.stopPropagation()}}"
        class="color-picker ${this.side?"side":""}"
        .hidden=${!this.pickerStatus}
        style="margin-right:${this.offsetRight}px"
      >
        ${this.pickerStatus?r.e` <color-picker
              @mousedown=${t=>{t.stopPropagation(),this._close_picker_lock=!0}}
              value="${this.value}"
              @input="${this._pickColor}"
            ></color-picker>`:null}
      </section>
    `}};u.styles=i,c([Object(r.g)({type:String})],u.prototype,"value",void 0),c([Object(r.g)({type:Number})],u.prototype,"offsetRight",void 0),c([Object(r.g)({type:Boolean})],u.prototype,"side",void 0),c([Object(r.g)({type:String})],u.prototype,"name",void 0),c([Object(r.g)({type:Array})],u.prototype,"colors",void 0),c([Object(r.f)()],u.prototype,"pickerStatus",void 0),c([Object(r.f)()],u.prototype,"activeIndex",void 0),c([Object(r.h)(".color-picker")],u.prototype,"$colorPicker",void 0),u=c([Object(r.c)("i-colorpicker")],u)},function(t,e,n){
/*!
 * Cropper.js v1.5.12
 * https://fengyuanchen.github.io/cropperjs
 *
 * Copyright 2015-present Chen Fengyuan
 * Released under the MIT license
 *
 * Date: 2021-06-12T08:00:17.411Z
 */
t.exports=function(){"use strict";function t(t,e){var n=Object.keys(t);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(t);e&&(r=r.filter((function(e){return Object.getOwnPropertyDescriptor(t,e).enumerable}))),n.push.apply(n,r)}return n}function e(e){for(var n=1;n<arguments.length;n++){var r=null!=arguments[n]?arguments[n]:{};n%2?t(Object(r),!0).forEach((function(t){i(e,t,r[t])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(r)):t(Object(r)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(r,t))}))}return e}function n(t){return(n="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(t){return typeof t}:function(t){return t&&"function"==typeof Symbol&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t})(t)}function r(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}function o(t,e){for(var n=0;n<e.length;n++){var r=e[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(t,r.key,r)}}function i(t,e,n){return e in t?Object.defineProperty(t,e,{value:n,enumerable:!0,configurable:!0,writable:!0}):t[e]=n,t}function a(t){return function(t){if(Array.isArray(t))return s(t)}(t)||function(t){if("undefined"!=typeof Symbol&&null!=t[Symbol.iterator]||null!=t["@@iterator"])return Array.from(t)}(t)||function(t,e){if(t){if("string"==typeof t)return s(t,e);var n=Object.prototype.toString.call(t).slice(8,-1);return"Object"===n&&t.constructor&&(n=t.constructor.name),"Map"===n||"Set"===n?Array.from(t):"Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)?s(t,e):void 0}}(t)||function(){throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()}function s(t,e){(null==e||e>t.length)&&(e=t.length);for(var n=0,r=new Array(e);n<e;n++)r[n]=t[n];return r}var c="undefined"!=typeof window&&void 0!==window.document,u=c?window:{},l=!(!c||!u.document.documentElement)&&"ontouchstart"in u.document.documentElement,p=!!c&&"PointerEvent"in u,h="".concat("cropper","-crop"),d="".concat("cropper","-disabled"),f="".concat("cropper","-hidden"),g="".concat("cropper","-hide"),v="".concat("cropper","-invisible"),m="".concat("cropper","-modal"),y="".concat("cropper","-move"),b="".concat("cropper","Action"),w="".concat("cropper","Preview"),x=l?"touchstart":"mousedown",_=l?"touchmove":"mousemove",O=l?"touchend touchcancel":"mouseup",S=p?"pointerdown":x,j=p?"pointermove":_,k=p?"pointerup pointercancel":O,A=/^e|w|s|n|se|sw|ne|nw|all|crop|move|zoom$/,T=/^data:/,E=/^data:image\/jpeg;base64,/,C=/^img|canvas$/i,R={viewMode:0,dragMode:"crop",initialAspectRatio:NaN,aspectRatio:NaN,data:null,preview:"",responsive:!0,restore:!0,checkCrossOrigin:!0,checkOrientation:!0,modal:!0,guides:!0,center:!0,highlight:!0,background:!0,autoCrop:!0,autoCropArea:.8,movable:!0,rotatable:!0,scalable:!0,zoomable:!0,zoomOnTouch:!0,zoomOnWheel:!0,wheelZoomRatio:.1,cropBoxMovable:!0,cropBoxResizable:!0,toggleDragModeOnDblclick:!0,minCanvasWidth:0,minCanvasHeight:0,minCropBoxWidth:0,minCropBoxHeight:0,minContainerWidth:200,minContainerHeight:100,ready:null,cropstart:null,cropmove:null,cropend:null,crop:null,zoom:null},I=Number.isNaN||u.isNaN;function P(t){return"number"==typeof t&&!I(t)}var M=function(t){return t>0&&t<1/0};function L(t){return void 0===t}function N(t){return"object"===n(t)&&null!==t}var B=Object.prototype.hasOwnProperty;function D(t){if(!N(t))return!1;try{var e=t.constructor,n=e.prototype;return e&&n&&B.call(n,"isPrototypeOf")}catch(t){return!1}}function U(t){return"function"==typeof t}var $=Array.prototype.slice;function z(t){return Array.from?Array.from(t):$.call(t)}function V(t,e){return t&&U(e)&&(Array.isArray(t)||P(t.length)?z(t).forEach((function(n,r){e.call(t,n,r,t)})):N(t)&&Object.keys(t).forEach((function(n){e.call(t,t[n],n,t)}))),t}var q=Object.assign||function(t){for(var e=arguments.length,n=new Array(e>1?e-1:0),r=1;r<e;r++)n[r-1]=arguments[r];return N(t)&&n.length>0&&n.forEach((function(e){N(e)&&Object.keys(e).forEach((function(n){t[n]=e[n]}))})),t},F=/\.\d*(?:0|9){12}\d*$/;function H(t){var e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:1e11;return F.test(t)?Math.round(t*e)/e:t}var W=/^width|height|left|top|marginLeft|marginTop$/;function G(t,e){var n=t.style;V(e,(function(t,e){W.test(e)&&P(t)&&(t="".concat(t,"px")),n[e]=t}))}function X(t,e){if(e)if(P(t.length))V(t,(function(t){X(t,e)}));else if(t.classList)t.classList.add(e);else{var n=t.className.trim();n?n.indexOf(e)<0&&(t.className="".concat(n," ").concat(e)):t.className=e}}function Y(t,e){e&&(P(t.length)?V(t,(function(t){Y(t,e)})):t.classList?t.classList.remove(e):t.className.indexOf(e)>=0&&(t.className=t.className.replace(e,"")))}function K(t,e,n){e&&(P(t.length)?V(t,(function(t){K(t,e,n)})):n?X(t,e):Y(t,e))}var J=/([a-z\d])([A-Z])/g;function Q(t){return t.replace(J,"$1-$2").toLowerCase()}function Z(t,e){return N(t[e])?t[e]:t.dataset?t.dataset[e]:t.getAttribute("data-".concat(Q(e)))}function tt(t,e,n){N(n)?t[e]=n:t.dataset?t.dataset[e]=n:t.setAttribute("data-".concat(Q(e)),n)}var et=/\s\s*/,nt=function(){var t=!1;if(c){var e=!1,n=function(){},r=Object.defineProperty({},"once",{get:function(){return t=!0,e},set:function(t){e=t}});u.addEventListener("test",n,r),u.removeEventListener("test",n,r)}return t}();function rt(t,e,n){var r=arguments.length>3&&void 0!==arguments[3]?arguments[3]:{},o=n;e.trim().split(et).forEach((function(e){if(!nt){var i=t.listeners;i&&i[e]&&i[e][n]&&(o=i[e][n],delete i[e][n],0===Object.keys(i[e]).length&&delete i[e],0===Object.keys(i).length&&delete t.listeners)}t.removeEventListener(e,o,r)}))}function ot(t,e,n){var r=arguments.length>3&&void 0!==arguments[3]?arguments[3]:{},o=n;e.trim().split(et).forEach((function(e){if(r.once&&!nt){var i=t.listeners,a=void 0===i?{}:i;o=function(){delete a[e][n],t.removeEventListener(e,o,r);for(var i=arguments.length,s=new Array(i),c=0;c<i;c++)s[c]=arguments[c];n.apply(t,s)},a[e]||(a[e]={}),a[e][n]&&t.removeEventListener(e,a[e][n],r),a[e][n]=o,t.listeners=a}t.addEventListener(e,o,r)}))}function it(t,e,n){var r;return U(Event)&&U(CustomEvent)?r=new CustomEvent(e,{detail:n,bubbles:!0,cancelable:!0}):(r=document.createEvent("CustomEvent")).initCustomEvent(e,!0,!0,n),t.dispatchEvent(r)}function at(t){var e=t.getBoundingClientRect();return{left:e.left+(window.pageXOffset-document.documentElement.clientLeft),top:e.top+(window.pageYOffset-document.documentElement.clientTop)}}var st=u.location,ct=/^(\w+:)\/\/([^:/?#]*):?(\d*)/i;function ut(t){var e=t.match(ct);return null!==e&&(e[1]!==st.protocol||e[2]!==st.hostname||e[3]!==st.port)}function lt(t){var e="timestamp=".concat((new Date).getTime());return t+(-1===t.indexOf("?")?"?":"&")+e}function pt(t){var e=t.rotate,n=t.scaleX,r=t.scaleY,o=t.translateX,i=t.translateY,a=[];P(o)&&0!==o&&a.push("translateX(".concat(o,"px)")),P(i)&&0!==i&&a.push("translateY(".concat(i,"px)")),P(e)&&0!==e&&a.push("rotate(".concat(e,"deg)")),P(n)&&1!==n&&a.push("scaleX(".concat(n,")")),P(r)&&1!==r&&a.push("scaleY(".concat(r,")"));var s=a.length?a.join(" "):"none";return{WebkitTransform:s,msTransform:s,transform:s}}function ht(t,n){var r=t.pageX,o=t.pageY,i={endX:r,endY:o};return n?i:e({startX:r,startY:o},i)}function dt(t){var e=t.aspectRatio,n=t.height,r=t.width,o=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"contain",i=M(r),a=M(n);if(i&&a){var s=n*e;"contain"===o&&s>r||"cover"===o&&s<r?n=r/e:r=n*e}else i?n=r/e:a&&(r=n*e);return{width:r,height:n}}function ft(t,e,n,r){var o=e.aspectRatio,i=e.naturalWidth,s=e.naturalHeight,c=e.rotate,u=void 0===c?0:c,l=e.scaleX,p=void 0===l?1:l,h=e.scaleY,d=void 0===h?1:h,f=n.aspectRatio,g=n.naturalWidth,v=n.naturalHeight,m=r.fillColor,y=void 0===m?"transparent":m,b=r.imageSmoothingEnabled,w=void 0===b||b,x=r.imageSmoothingQuality,_=void 0===x?"low":x,O=r.maxWidth,S=void 0===O?1/0:O,j=r.maxHeight,k=void 0===j?1/0:j,A=r.minWidth,T=void 0===A?0:A,E=r.minHeight,C=void 0===E?0:E,R=document.createElement("canvas"),I=R.getContext("2d"),P=dt({aspectRatio:f,width:S,height:k}),M=dt({aspectRatio:f,width:T,height:C},"cover"),L=Math.min(P.width,Math.max(M.width,g)),N=Math.min(P.height,Math.max(M.height,v)),B=dt({aspectRatio:o,width:S,height:k}),D=dt({aspectRatio:o,width:T,height:C},"cover"),U=Math.min(B.width,Math.max(D.width,i)),$=Math.min(B.height,Math.max(D.height,s)),z=[-U/2,-$/2,U,$];return R.width=H(L),R.height=H(N),I.fillStyle=y,I.fillRect(0,0,L,N),I.save(),I.translate(L/2,N/2),I.rotate(u*Math.PI/180),I.scale(p,d),I.imageSmoothingEnabled=w,I.imageSmoothingQuality=_,I.drawImage.apply(I,[t].concat(a(z.map((function(t){return Math.floor(H(t))}))))),I.restore(),R}var gt=String.fromCharCode,vt=/^data:.*,/;function mt(t){var e,n=new DataView(t);try{var r,o,i;if(255===n.getUint8(0)&&216===n.getUint8(1))for(var a=n.byteLength,s=2;s+1<a;){if(255===n.getUint8(s)&&225===n.getUint8(s+1)){o=s;break}s+=1}if(o){var c=o+10;if("Exif"===function(t,e,n){var r="";n+=e;for(var o=e;o<n;o+=1)r+=gt(t.getUint8(o));return r}(n,o+4,4)){var u=n.getUint16(c);if(((r=18761===u)||19789===u)&&42===n.getUint16(c+2,r)){var l=n.getUint32(c+4,r);l>=8&&(i=c+l)}}}if(i){var p,h,d=n.getUint16(i,r);for(h=0;h<d;h+=1)if(p=i+12*h+2,274===n.getUint16(p,r)){p+=8,e=n.getUint16(p,r),n.setUint16(p,1,r);break}}}catch(t){e=1}return e}var yt={render:function(){this.initContainer(),this.initCanvas(),this.initCropBox(),this.renderCanvas(),this.cropped&&this.renderCropBox()},initContainer:function(){var t=this.element,e=this.options,n=this.container,r=this.cropper,o=Number(e.minContainerWidth),i=Number(e.minContainerHeight);X(r,f),Y(t,f);var a={width:Math.max(n.offsetWidth,o>=0?o:200),height:Math.max(n.offsetHeight,i>=0?i:100)};this.containerData=a,G(r,{width:a.width,height:a.height}),X(t,f),Y(r,f)},initCanvas:function(){var t=this.containerData,e=this.imageData,n=this.options.viewMode,r=Math.abs(e.rotate)%180==90,o=r?e.naturalHeight:e.naturalWidth,i=r?e.naturalWidth:e.naturalHeight,a=o/i,s=t.width,c=t.height;t.height*a>t.width?3===n?s=t.height*a:c=t.width/a:3===n?c=t.width/a:s=t.height*a;var u={aspectRatio:a,naturalWidth:o,naturalHeight:i,width:s,height:c};this.canvasData=u,this.limited=1===n||2===n,this.limitCanvas(!0,!0),u.width=Math.min(Math.max(u.width,u.minWidth),u.maxWidth),u.height=Math.min(Math.max(u.height,u.minHeight),u.maxHeight),u.left=(t.width-u.width)/2,u.top=(t.height-u.height)/2,u.oldLeft=u.left,u.oldTop=u.top,this.initialCanvasData=q({},u)},limitCanvas:function(t,e){var n=this.options,r=this.containerData,o=this.canvasData,i=this.cropBoxData,a=n.viewMode,s=o.aspectRatio,c=this.cropped&&i;if(t){var u=Number(n.minCanvasWidth)||0,l=Number(n.minCanvasHeight)||0;a>1?(u=Math.max(u,r.width),l=Math.max(l,r.height),3===a&&(l*s>u?u=l*s:l=u/s)):a>0&&(u?u=Math.max(u,c?i.width:0):l?l=Math.max(l,c?i.height:0):c&&(u=i.width,(l=i.height)*s>u?u=l*s:l=u/s));var p=dt({aspectRatio:s,width:u,height:l});u=p.width,l=p.height,o.minWidth=u,o.minHeight=l,o.maxWidth=1/0,o.maxHeight=1/0}if(e)if(a>(c?0:1)){var h=r.width-o.width,d=r.height-o.height;o.minLeft=Math.min(0,h),o.minTop=Math.min(0,d),o.maxLeft=Math.max(0,h),o.maxTop=Math.max(0,d),c&&this.limited&&(o.minLeft=Math.min(i.left,i.left+(i.width-o.width)),o.minTop=Math.min(i.top,i.top+(i.height-o.height)),o.maxLeft=i.left,o.maxTop=i.top,2===a&&(o.width>=r.width&&(o.minLeft=Math.min(0,h),o.maxLeft=Math.max(0,h)),o.height>=r.height&&(o.minTop=Math.min(0,d),o.maxTop=Math.max(0,d))))}else o.minLeft=-o.width,o.minTop=-o.height,o.maxLeft=r.width,o.maxTop=r.height},renderCanvas:function(t,e){var n=this.canvasData,r=this.imageData;if(e){var o=function(t){var e=t.width,n=t.height,r=t.degree;if(90==(r=Math.abs(r)%180))return{width:n,height:e};var o=r%90*Math.PI/180,i=Math.sin(o),a=Math.cos(o),s=e*a+n*i,c=e*i+n*a;return r>90?{width:c,height:s}:{width:s,height:c}}({width:r.naturalWidth*Math.abs(r.scaleX||1),height:r.naturalHeight*Math.abs(r.scaleY||1),degree:r.rotate||0}),i=o.width,a=o.height,s=n.width*(i/n.naturalWidth),c=n.height*(a/n.naturalHeight);n.left-=(s-n.width)/2,n.top-=(c-n.height)/2,n.width=s,n.height=c,n.aspectRatio=i/a,n.naturalWidth=i,n.naturalHeight=a,this.limitCanvas(!0,!1)}(n.width>n.maxWidth||n.width<n.minWidth)&&(n.left=n.oldLeft),(n.height>n.maxHeight||n.height<n.minHeight)&&(n.top=n.oldTop),n.width=Math.min(Math.max(n.width,n.minWidth),n.maxWidth),n.height=Math.min(Math.max(n.height,n.minHeight),n.maxHeight),this.limitCanvas(!1,!0),n.left=Math.min(Math.max(n.left,n.minLeft),n.maxLeft),n.top=Math.min(Math.max(n.top,n.minTop),n.maxTop),n.oldLeft=n.left,n.oldTop=n.top,G(this.canvas,q({width:n.width,height:n.height},pt({translateX:n.left,translateY:n.top}))),this.renderImage(t),this.cropped&&this.limited&&this.limitCropBox(!0,!0)},renderImage:function(t){var e=this.canvasData,n=this.imageData,r=n.naturalWidth*(e.width/e.naturalWidth),o=n.naturalHeight*(e.height/e.naturalHeight);q(n,{width:r,height:o,left:(e.width-r)/2,top:(e.height-o)/2}),G(this.image,q({width:n.width,height:n.height},pt(q({translateX:n.left,translateY:n.top},n)))),t&&this.output()},initCropBox:function(){var t=this.options,e=this.canvasData,n=t.aspectRatio||t.initialAspectRatio,r=Number(t.autoCropArea)||.8,o={width:e.width,height:e.height};n&&(e.height*n>e.width?o.height=o.width/n:o.width=o.height*n),this.cropBoxData=o,this.limitCropBox(!0,!0),o.width=Math.min(Math.max(o.width,o.minWidth),o.maxWidth),o.height=Math.min(Math.max(o.height,o.minHeight),o.maxHeight),o.width=Math.max(o.minWidth,o.width*r),o.height=Math.max(o.minHeight,o.height*r),o.left=e.left+(e.width-o.width)/2,o.top=e.top+(e.height-o.height)/2,o.oldLeft=o.left,o.oldTop=o.top,this.initialCropBoxData=q({},o)},limitCropBox:function(t,e){var n=this.options,r=this.containerData,o=this.canvasData,i=this.cropBoxData,a=this.limited,s=n.aspectRatio;if(t){var c=Number(n.minCropBoxWidth)||0,u=Number(n.minCropBoxHeight)||0,l=a?Math.min(r.width,o.width,o.width+o.left,r.width-o.left):r.width,p=a?Math.min(r.height,o.height,o.height+o.top,r.height-o.top):r.height;c=Math.min(c,r.width),u=Math.min(u,r.height),s&&(c&&u?u*s>c?u=c/s:c=u*s:c?u=c/s:u&&(c=u*s),p*s>l?p=l/s:l=p*s),i.minWidth=Math.min(c,l),i.minHeight=Math.min(u,p),i.maxWidth=l,i.maxHeight=p}e&&(a?(i.minLeft=Math.max(0,o.left),i.minTop=Math.max(0,o.top),i.maxLeft=Math.min(r.width,o.left+o.width)-i.width,i.maxTop=Math.min(r.height,o.top+o.height)-i.height):(i.minLeft=0,i.minTop=0,i.maxLeft=r.width-i.width,i.maxTop=r.height-i.height))},renderCropBox:function(){var t=this.options,e=this.containerData,n=this.cropBoxData;(n.width>n.maxWidth||n.width<n.minWidth)&&(n.left=n.oldLeft),(n.height>n.maxHeight||n.height<n.minHeight)&&(n.top=n.oldTop),n.width=Math.min(Math.max(n.width,n.minWidth),n.maxWidth),n.height=Math.min(Math.max(n.height,n.minHeight),n.maxHeight),this.limitCropBox(!1,!0),n.left=Math.min(Math.max(n.left,n.minLeft),n.maxLeft),n.top=Math.min(Math.max(n.top,n.minTop),n.maxTop),n.oldLeft=n.left,n.oldTop=n.top,t.movable&&t.cropBoxMovable&&tt(this.face,b,n.width>=e.width&&n.height>=e.height?"move":"all"),G(this.cropBox,q({width:n.width,height:n.height},pt({translateX:n.left,translateY:n.top}))),this.cropped&&this.limited&&this.limitCanvas(!0,!0),this.disabled||this.output()},output:function(){this.preview(),it(this.element,"crop",this.getData())}},bt={initPreview:function(){var t=this.element,e=this.crossOrigin,n=this.options.preview,r=e?this.crossOriginUrl:this.url,o=t.alt||"The image to preview",i=document.createElement("img");if(e&&(i.crossOrigin=e),i.src=r,i.alt=o,this.viewBox.appendChild(i),this.viewBoxImage=i,n){var a=n;"string"==typeof n?a=t.ownerDocument.querySelectorAll(n):n.querySelector&&(a=[n]),this.previews=a,V(a,(function(t){var n=document.createElement("img");tt(t,w,{width:t.offsetWidth,height:t.offsetHeight,html:t.innerHTML}),e&&(n.crossOrigin=e),n.src=r,n.alt=o,n.style.cssText='display:block;width:100%;height:auto;min-width:0!important;min-height:0!important;max-width:none!important;max-height:none!important;image-orientation:0deg!important;"',t.innerHTML="",t.appendChild(n)}))}},resetPreview:function(){V(this.previews,(function(t){var e=Z(t,w);G(t,{width:e.width,height:e.height}),t.innerHTML=e.html,function(t,e){if(N(t[e]))try{delete t[e]}catch(n){t[e]=void 0}else if(t.dataset)try{delete t.dataset[e]}catch(n){t.dataset[e]=void 0}else t.removeAttribute("data-".concat(Q(e)))}(t,w)}))},preview:function(){var t=this.imageData,e=this.canvasData,n=this.cropBoxData,r=n.width,o=n.height,i=t.width,a=t.height,s=n.left-e.left-t.left,c=n.top-e.top-t.top;this.cropped&&!this.disabled&&(G(this.viewBoxImage,q({width:i,height:a},pt(q({translateX:-s,translateY:-c},t)))),V(this.previews,(function(e){var n=Z(e,w),u=n.width,l=n.height,p=u,h=l,d=1;r&&(h=o*(d=u/r)),o&&h>l&&(p=r*(d=l/o),h=l),G(e,{width:p,height:h}),G(e.getElementsByTagName("img")[0],q({width:i*d,height:a*d},pt(q({translateX:-s*d,translateY:-c*d},t))))})))}},wt={bind:function(){var t=this.element,e=this.options,n=this.cropper;U(e.cropstart)&&ot(t,"cropstart",e.cropstart),U(e.cropmove)&&ot(t,"cropmove",e.cropmove),U(e.cropend)&&ot(t,"cropend",e.cropend),U(e.crop)&&ot(t,"crop",e.crop),U(e.zoom)&&ot(t,"zoom",e.zoom),ot(n,S,this.onCropStart=this.cropStart.bind(this)),e.zoomable&&e.zoomOnWheel&&ot(n,"wheel",this.onWheel=this.wheel.bind(this),{passive:!1,capture:!0}),e.toggleDragModeOnDblclick&&ot(n,"dblclick",this.onDblclick=this.dblclick.bind(this)),ot(t.ownerDocument,j,this.onCropMove=this.cropMove.bind(this)),ot(t.ownerDocument,k,this.onCropEnd=this.cropEnd.bind(this)),e.responsive&&ot(window,"resize",this.onResize=this.resize.bind(this))},unbind:function(){var t=this.element,e=this.options,n=this.cropper;U(e.cropstart)&&rt(t,"cropstart",e.cropstart),U(e.cropmove)&&rt(t,"cropmove",e.cropmove),U(e.cropend)&&rt(t,"cropend",e.cropend),U(e.crop)&&rt(t,"crop",e.crop),U(e.zoom)&&rt(t,"zoom",e.zoom),rt(n,S,this.onCropStart),e.zoomable&&e.zoomOnWheel&&rt(n,"wheel",this.onWheel,{passive:!1,capture:!0}),e.toggleDragModeOnDblclick&&rt(n,"dblclick",this.onDblclick),rt(t.ownerDocument,j,this.onCropMove),rt(t.ownerDocument,k,this.onCropEnd),e.responsive&&rt(window,"resize",this.onResize)}},xt={resize:function(){if(!this.disabled){var t,e,n=this.options,r=this.container,o=this.containerData,i=r.offsetWidth/o.width,a=r.offsetHeight/o.height,s=Math.abs(i-1)>Math.abs(a-1)?i:a;1!==s&&(n.restore&&(t=this.getCanvasData(),e=this.getCropBoxData()),this.render(),n.restore&&(this.setCanvasData(V(t,(function(e,n){t[n]=e*s}))),this.setCropBoxData(V(e,(function(t,n){e[n]=t*s})))))}},dblclick:function(){var t,e;this.disabled||"none"===this.options.dragMode||this.setDragMode((t=this.dragBox,e=h,(t.classList?t.classList.contains(e):t.className.indexOf(e)>-1)?"move":"crop"))},wheel:function(t){var e=this,n=Number(this.options.wheelZoomRatio)||.1,r=1;this.disabled||(t.preventDefault(),this.wheeling||(this.wheeling=!0,setTimeout((function(){e.wheeling=!1}),50),t.deltaY?r=t.deltaY>0?1:-1:t.wheelDelta?r=-t.wheelDelta/120:t.detail&&(r=t.detail>0?1:-1),this.zoom(-r*n,t)))},cropStart:function(t){var e=t.buttons,n=t.button;if(!(this.disabled||("mousedown"===t.type||"pointerdown"===t.type&&"mouse"===t.pointerType)&&(P(e)&&1!==e||P(n)&&0!==n||t.ctrlKey))){var r,o=this.options,i=this.pointers;t.changedTouches?V(t.changedTouches,(function(t){i[t.identifier]=ht(t)})):i[t.pointerId||0]=ht(t),r=Object.keys(i).length>1&&o.zoomable&&o.zoomOnTouch?"zoom":Z(t.target,b),A.test(r)&&!1!==it(this.element,"cropstart",{originalEvent:t,action:r})&&(t.preventDefault(),this.action=r,this.cropping=!1,"crop"===r&&(this.cropping=!0,X(this.dragBox,m)))}},cropMove:function(t){var e=this.action;if(!this.disabled&&e){var n=this.pointers;t.preventDefault(),!1!==it(this.element,"cropmove",{originalEvent:t,action:e})&&(t.changedTouches?V(t.changedTouches,(function(t){q(n[t.identifier]||{},ht(t,!0))})):q(n[t.pointerId||0]||{},ht(t,!0)),this.change(t))}},cropEnd:function(t){if(!this.disabled){var e=this.action,n=this.pointers;t.changedTouches?V(t.changedTouches,(function(t){delete n[t.identifier]})):delete n[t.pointerId||0],e&&(t.preventDefault(),Object.keys(n).length||(this.action=""),this.cropping&&(this.cropping=!1,K(this.dragBox,m,this.cropped&&this.options.modal)),it(this.element,"cropend",{originalEvent:t,action:e}))}}},_t={change:function(t){var n,r=this.options,o=this.canvasData,i=this.containerData,a=this.cropBoxData,s=this.pointers,c=this.action,u=r.aspectRatio,l=a.left,p=a.top,h=a.width,d=a.height,g=l+h,v=p+d,m=0,y=0,b=i.width,w=i.height,x=!0;!u&&t.shiftKey&&(u=h&&d?h/d:1),this.limited&&(m=a.minLeft,y=a.minTop,b=m+Math.min(i.width,o.width,o.left+o.width),w=y+Math.min(i.height,o.height,o.top+o.height));var _=s[Object.keys(s)[0]],O={x:_.endX-_.startX,y:_.endY-_.startY},S=function(t){switch(t){case"e":g+O.x>b&&(O.x=b-g);break;case"w":l+O.x<m&&(O.x=m-l);break;case"n":p+O.y<y&&(O.y=y-p);break;case"s":v+O.y>w&&(O.y=w-v)}};switch(c){case"all":l+=O.x,p+=O.y;break;case"e":if(O.x>=0&&(g>=b||u&&(p<=y||v>=w))){x=!1;break}S("e"),(h+=O.x)<0&&(c="w",l-=h=-h),u&&(d=h/u,p+=(a.height-d)/2);break;case"n":if(O.y<=0&&(p<=y||u&&(l<=m||g>=b))){x=!1;break}S("n"),d-=O.y,p+=O.y,d<0&&(c="s",p-=d=-d),u&&(h=d*u,l+=(a.width-h)/2);break;case"w":if(O.x<=0&&(l<=m||u&&(p<=y||v>=w))){x=!1;break}S("w"),h-=O.x,l+=O.x,h<0&&(c="e",l-=h=-h),u&&(d=h/u,p+=(a.height-d)/2);break;case"s":if(O.y>=0&&(v>=w||u&&(l<=m||g>=b))){x=!1;break}S("s"),(d+=O.y)<0&&(c="n",p-=d=-d),u&&(h=d*u,l+=(a.width-h)/2);break;case"ne":if(u){if(O.y<=0&&(p<=y||g>=b)){x=!1;break}S("n"),d-=O.y,p+=O.y,h=d*u}else S("n"),S("e"),O.x>=0?g<b?h+=O.x:O.y<=0&&p<=y&&(x=!1):h+=O.x,O.y<=0?p>y&&(d-=O.y,p+=O.y):(d-=O.y,p+=O.y);h<0&&d<0?(c="sw",p-=d=-d,l-=h=-h):h<0?(c="nw",l-=h=-h):d<0&&(c="se",p-=d=-d);break;case"nw":if(u){if(O.y<=0&&(p<=y||l<=m)){x=!1;break}S("n"),d-=O.y,p+=O.y,h=d*u,l+=a.width-h}else S("n"),S("w"),O.x<=0?l>m?(h-=O.x,l+=O.x):O.y<=0&&p<=y&&(x=!1):(h-=O.x,l+=O.x),O.y<=0?p>y&&(d-=O.y,p+=O.y):(d-=O.y,p+=O.y);h<0&&d<0?(c="se",p-=d=-d,l-=h=-h):h<0?(c="ne",l-=h=-h):d<0&&(c="sw",p-=d=-d);break;case"sw":if(u){if(O.x<=0&&(l<=m||v>=w)){x=!1;break}S("w"),h-=O.x,l+=O.x,d=h/u}else S("s"),S("w"),O.x<=0?l>m?(h-=O.x,l+=O.x):O.y>=0&&v>=w&&(x=!1):(h-=O.x,l+=O.x),O.y>=0?v<w&&(d+=O.y):d+=O.y;h<0&&d<0?(c="ne",p-=d=-d,l-=h=-h):h<0?(c="se",l-=h=-h):d<0&&(c="nw",p-=d=-d);break;case"se":if(u){if(O.x>=0&&(g>=b||v>=w)){x=!1;break}S("e"),d=(h+=O.x)/u}else S("s"),S("e"),O.x>=0?g<b?h+=O.x:O.y>=0&&v>=w&&(x=!1):h+=O.x,O.y>=0?v<w&&(d+=O.y):d+=O.y;h<0&&d<0?(c="nw",p-=d=-d,l-=h=-h):h<0?(c="sw",l-=h=-h):d<0&&(c="ne",p-=d=-d);break;case"move":this.move(O.x,O.y),x=!1;break;case"zoom":this.zoom(function(t){var n=e({},t),r=0;return V(t,(function(t,e){delete n[e],V(n,(function(e){var n=Math.abs(t.startX-e.startX),o=Math.abs(t.startY-e.startY),i=Math.abs(t.endX-e.endX),a=Math.abs(t.endY-e.endY),s=Math.sqrt(n*n+o*o),c=(Math.sqrt(i*i+a*a)-s)/s;Math.abs(c)>Math.abs(r)&&(r=c)}))})),r}(s),t),x=!1;break;case"crop":if(!O.x||!O.y){x=!1;break}n=at(this.cropper),l=_.startX-n.left,p=_.startY-n.top,h=a.minWidth,d=a.minHeight,O.x>0?c=O.y>0?"se":"ne":O.x<0&&(l-=h,c=O.y>0?"sw":"nw"),O.y<0&&(p-=d),this.cropped||(Y(this.cropBox,f),this.cropped=!0,this.limited&&this.limitCropBox(!0,!0))}x&&(a.width=h,a.height=d,a.left=l,a.top=p,this.action=c,this.renderCropBox()),V(s,(function(t){t.startX=t.endX,t.startY=t.endY}))}},Ot={crop:function(){return!this.ready||this.cropped||this.disabled||(this.cropped=!0,this.limitCropBox(!0,!0),this.options.modal&&X(this.dragBox,m),Y(this.cropBox,f),this.setCropBoxData(this.initialCropBoxData)),this},reset:function(){return this.ready&&!this.disabled&&(this.imageData=q({},this.initialImageData),this.canvasData=q({},this.initialCanvasData),this.cropBoxData=q({},this.initialCropBoxData),this.renderCanvas(),this.cropped&&this.renderCropBox()),this},clear:function(){return this.cropped&&!this.disabled&&(q(this.cropBoxData,{left:0,top:0,width:0,height:0}),this.cropped=!1,this.renderCropBox(),this.limitCanvas(!0,!0),this.renderCanvas(),Y(this.dragBox,m),X(this.cropBox,f)),this},replace:function(t){var e=arguments.length>1&&void 0!==arguments[1]&&arguments[1];return!this.disabled&&t&&(this.isImg&&(this.element.src=t),e?(this.url=t,this.image.src=t,this.ready&&(this.viewBoxImage.src=t,V(this.previews,(function(e){e.getElementsByTagName("img")[0].src=t})))):(this.isImg&&(this.replaced=!0),this.options.data=null,this.uncreate(),this.load(t))),this},enable:function(){return this.ready&&this.disabled&&(this.disabled=!1,Y(this.cropper,d)),this},disable:function(){return this.ready&&!this.disabled&&(this.disabled=!0,X(this.cropper,d)),this},destroy:function(){var t=this.element;return t.cropper?(t.cropper=void 0,this.isImg&&this.replaced&&(t.src=this.originalUrl),this.uncreate(),this):this},move:function(t){var e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:t,n=this.canvasData,r=n.left,o=n.top;return this.moveTo(L(t)?t:r+Number(t),L(e)?e:o+Number(e))},moveTo:function(t){var e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:t,n=this.canvasData,r=!1;return t=Number(t),e=Number(e),this.ready&&!this.disabled&&this.options.movable&&(P(t)&&(n.left=t,r=!0),P(e)&&(n.top=e,r=!0),r&&this.renderCanvas(!0)),this},zoom:function(t,e){var n=this.canvasData;return t=(t=Number(t))<0?1/(1-t):1+t,this.zoomTo(n.width*t/n.naturalWidth,null,e)},zoomTo:function(t,e,n){var r=this.options,o=this.canvasData,i=o.width,a=o.height,s=o.naturalWidth,c=o.naturalHeight;if((t=Number(t))>=0&&this.ready&&!this.disabled&&r.zoomable){var u=s*t,l=c*t;if(!1===it(this.element,"zoom",{ratio:t,oldRatio:i/s,originalEvent:n}))return this;if(n){var p=this.pointers,h=at(this.cropper),d=p&&Object.keys(p).length?function(t){var e=0,n=0,r=0;return V(t,(function(t){var o=t.startX,i=t.startY;e+=o,n+=i,r+=1})),{pageX:e/=r,pageY:n/=r}}(p):{pageX:n.pageX,pageY:n.pageY};o.left-=(u-i)*((d.pageX-h.left-o.left)/i),o.top-=(l-a)*((d.pageY-h.top-o.top)/a)}else D(e)&&P(e.x)&&P(e.y)?(o.left-=(u-i)*((e.x-o.left)/i),o.top-=(l-a)*((e.y-o.top)/a)):(o.left-=(u-i)/2,o.top-=(l-a)/2);o.width=u,o.height=l,this.renderCanvas(!0)}return this},rotate:function(t){return this.rotateTo((this.imageData.rotate||0)+Number(t))},rotateTo:function(t){return P(t=Number(t))&&this.ready&&!this.disabled&&this.options.rotatable&&(this.imageData.rotate=t%360,this.renderCanvas(!0,!0)),this},scaleX:function(t){var e=this.imageData.scaleY;return this.scale(t,P(e)?e:1)},scaleY:function(t){var e=this.imageData.scaleX;return this.scale(P(e)?e:1,t)},scale:function(t){var e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:t,n=this.imageData,r=!1;return t=Number(t),e=Number(e),this.ready&&!this.disabled&&this.options.scalable&&(P(t)&&(n.scaleX=t,r=!0),P(e)&&(n.scaleY=e,r=!0),r&&this.renderCanvas(!0,!0)),this},getData:function(){var t,e=arguments.length>0&&void 0!==arguments[0]&&arguments[0],n=this.options,r=this.imageData,o=this.canvasData,i=this.cropBoxData;if(this.ready&&this.cropped){t={x:i.left-o.left,y:i.top-o.top,width:i.width,height:i.height};var a=r.width/r.naturalWidth;if(V(t,(function(e,n){t[n]=e/a})),e){var s=Math.round(t.y+t.height),c=Math.round(t.x+t.width);t.x=Math.round(t.x),t.y=Math.round(t.y),t.width=c-t.x,t.height=s-t.y}}else t={x:0,y:0,width:0,height:0};return n.rotatable&&(t.rotate=r.rotate||0),n.scalable&&(t.scaleX=r.scaleX||1,t.scaleY=r.scaleY||1),t},setData:function(t){var e=this.options,n=this.imageData,r=this.canvasData,o={};if(this.ready&&!this.disabled&&D(t)){var i=!1;e.rotatable&&P(t.rotate)&&t.rotate!==n.rotate&&(n.rotate=t.rotate,i=!0),e.scalable&&(P(t.scaleX)&&t.scaleX!==n.scaleX&&(n.scaleX=t.scaleX,i=!0),P(t.scaleY)&&t.scaleY!==n.scaleY&&(n.scaleY=t.scaleY,i=!0)),i&&this.renderCanvas(!0,!0);var a=n.width/n.naturalWidth;P(t.x)&&(o.left=t.x*a+r.left),P(t.y)&&(o.top=t.y*a+r.top),P(t.width)&&(o.width=t.width*a),P(t.height)&&(o.height=t.height*a),this.setCropBoxData(o)}return this},getContainerData:function(){return this.ready?q({},this.containerData):{}},getImageData:function(){return this.sized?q({},this.imageData):{}},getCanvasData:function(){var t=this.canvasData,e={};return this.ready&&V(["left","top","width","height","naturalWidth","naturalHeight"],(function(n){e[n]=t[n]})),e},setCanvasData:function(t){var e=this.canvasData,n=e.aspectRatio;return this.ready&&!this.disabled&&D(t)&&(P(t.left)&&(e.left=t.left),P(t.top)&&(e.top=t.top),P(t.width)?(e.width=t.width,e.height=t.width/n):P(t.height)&&(e.height=t.height,e.width=t.height*n),this.renderCanvas(!0)),this},getCropBoxData:function(){var t,e=this.cropBoxData;return this.ready&&this.cropped&&(t={left:e.left,top:e.top,width:e.width,height:e.height}),t||{}},setCropBoxData:function(t){var e,n,r=this.cropBoxData,o=this.options.aspectRatio;return this.ready&&this.cropped&&!this.disabled&&D(t)&&(P(t.left)&&(r.left=t.left),P(t.top)&&(r.top=t.top),P(t.width)&&t.width!==r.width&&(e=!0,r.width=t.width),P(t.height)&&t.height!==r.height&&(n=!0,r.height=t.height),o&&(e?r.height=r.width/o:n&&(r.width=r.height*o)),this.renderCropBox()),this},getCroppedCanvas:function(){var t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};if(!this.ready||!window.HTMLCanvasElement)return null;var e=this.canvasData,n=ft(this.image,this.imageData,e,t);if(!this.cropped)return n;var r=this.getData(),o=r.x,i=r.y,s=r.width,c=r.height,u=n.width/Math.floor(e.naturalWidth);1!==u&&(o*=u,i*=u,s*=u,c*=u);var l=s/c,p=dt({aspectRatio:l,width:t.maxWidth||1/0,height:t.maxHeight||1/0}),h=dt({aspectRatio:l,width:t.minWidth||0,height:t.minHeight||0},"cover"),d=dt({aspectRatio:l,width:t.width||(1!==u?n.width:s),height:t.height||(1!==u?n.height:c)}),f=d.width,g=d.height;f=Math.min(p.width,Math.max(h.width,f)),g=Math.min(p.height,Math.max(h.height,g));var v=document.createElement("canvas"),m=v.getContext("2d");v.width=H(f),v.height=H(g),m.fillStyle=t.fillColor||"transparent",m.fillRect(0,0,f,g);var y=t.imageSmoothingEnabled,b=void 0===y||y,w=t.imageSmoothingQuality;m.imageSmoothingEnabled=b,w&&(m.imageSmoothingQuality=w);var x,_,O,S,j,k,A=n.width,T=n.height,E=o,C=i;E<=-s||E>A?(E=0,x=0,O=0,j=0):E<=0?(O=-E,E=0,j=x=Math.min(A,s+E)):E<=A&&(O=0,j=x=Math.min(s,A-E)),x<=0||C<=-c||C>T?(C=0,_=0,S=0,k=0):C<=0?(S=-C,C=0,k=_=Math.min(T,c+C)):C<=T&&(S=0,k=_=Math.min(c,T-C));var R=[E,C,x,_];if(j>0&&k>0){var I=f/s;R.push(O*I,S*I,j*I,k*I)}return m.drawImage.apply(m,[n].concat(a(R.map((function(t){return Math.floor(H(t))}))))),v},setAspectRatio:function(t){var e=this.options;return this.disabled||L(t)||(e.aspectRatio=Math.max(0,t)||NaN,this.ready&&(this.initCropBox(),this.cropped&&this.renderCropBox())),this},setDragMode:function(t){var e=this.options,n=this.dragBox,r=this.face;if(this.ready&&!this.disabled){var o="crop"===t,i=e.movable&&"move"===t;t=o||i?t:"none",e.dragMode=t,tt(n,b,t),K(n,h,o),K(n,y,i),e.cropBoxMovable||(tt(r,b,t),K(r,h,o),K(r,y,i))}return this}},St=u.Cropper,jt=function(){function t(e){var n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{};if(r(this,t),!e||!C.test(e.tagName))throw new Error("The first argument is required and must be an <img> or <canvas> element.");this.element=e,this.options=q({},R,D(n)&&n),this.cropped=!1,this.disabled=!1,this.pointers={},this.ready=!1,this.reloading=!1,this.replaced=!1,this.sized=!1,this.sizing=!1,this.init()}var e,n,i;return e=t,i=[{key:"noConflict",value:function(){return window.Cropper=St,t}},{key:"setDefaults",value:function(t){q(R,D(t)&&t)}}],(n=[{key:"init",value:function(){var t,e=this.element,n=e.tagName.toLowerCase();if(!e.cropper){if(e.cropper=this,"img"===n){if(this.isImg=!0,t=e.getAttribute("src")||"",this.originalUrl=t,!t)return;t=e.src}else"canvas"===n&&window.HTMLCanvasElement&&(t=e.toDataURL());this.load(t)}}},{key:"load",value:function(t){var e=this;if(t){this.url=t,this.imageData={};var n=this.element,r=this.options;if(r.rotatable||r.scalable||(r.checkOrientation=!1),r.checkOrientation&&window.ArrayBuffer)if(T.test(t))E.test(t)?this.read((o=t.replace(vt,""),i=atob(o),a=new ArrayBuffer(i.length),V(s=new Uint8Array(a),(function(t,e){s[e]=i.charCodeAt(e)})),a)):this.clone();else{var o,i,a,s,c=new XMLHttpRequest,u=this.clone.bind(this);this.reloading=!0,this.xhr=c,c.onabort=u,c.onerror=u,c.ontimeout=u,c.onprogress=function(){"image/jpeg"!==c.getResponseHeader("content-type")&&c.abort()},c.onload=function(){e.read(c.response)},c.onloadend=function(){e.reloading=!1,e.xhr=null},r.checkCrossOrigin&&ut(t)&&n.crossOrigin&&(t=lt(t)),c.open("GET",t,!0),c.responseType="arraybuffer",c.withCredentials="use-credentials"===n.crossOrigin,c.send()}else this.clone()}}},{key:"read",value:function(t){var e=this.options,n=this.imageData,r=mt(t),o=0,i=1,a=1;if(r>1){this.url=function(t,e){for(var n=[],r=new Uint8Array(t);r.length>0;)n.push(gt.apply(null,z(r.subarray(0,8192)))),r=r.subarray(8192);return"data:".concat(e,";base64,").concat(btoa(n.join("")))}(t,"image/jpeg");var s=function(t){var e=0,n=1,r=1;switch(t){case 2:n=-1;break;case 3:e=-180;break;case 4:r=-1;break;case 5:e=90,r=-1;break;case 6:e=90;break;case 7:e=90,n=-1;break;case 8:e=-90}return{rotate:e,scaleX:n,scaleY:r}}(r);o=s.rotate,i=s.scaleX,a=s.scaleY}e.rotatable&&(n.rotate=o),e.scalable&&(n.scaleX=i,n.scaleY=a),this.clone()}},{key:"clone",value:function(){var t=this.element,e=this.url,n=t.crossOrigin,r=e;this.options.checkCrossOrigin&&ut(e)&&(n||(n="anonymous"),r=lt(e)),this.crossOrigin=n,this.crossOriginUrl=r;var o=document.createElement("img");n&&(o.crossOrigin=n),o.src=r||e,o.alt=t.alt||"The image to crop",this.image=o,o.onload=this.start.bind(this),o.onerror=this.stop.bind(this),X(o,g),t.parentNode.insertBefore(o,t.nextSibling)}},{key:"start",value:function(){var t=this,e=this.image;e.onload=null,e.onerror=null,this.sizing=!0;var n=u.navigator&&/(?:iPad|iPhone|iPod).*?AppleWebKit/i.test(u.navigator.userAgent),r=function(e,n){q(t.imageData,{naturalWidth:e,naturalHeight:n,aspectRatio:e/n}),t.initialImageData=q({},t.imageData),t.sizing=!1,t.sized=!0,t.build()};if(!e.naturalWidth||n){var o=document.createElement("img"),i=document.body||document.documentElement;this.sizingImage=o,o.onload=function(){r(o.width,o.height),n||i.removeChild(o)},o.src=e.src,n||(o.style.cssText="left:0;max-height:none!important;max-width:none!important;min-height:0!important;min-width:0!important;opacity:0;position:absolute;top:0;z-index:-1;",i.appendChild(o))}else r(e.naturalWidth,e.naturalHeight)}},{key:"stop",value:function(){var t=this.image;t.onload=null,t.onerror=null,t.parentNode.removeChild(t),this.image=null}},{key:"build",value:function(){if(this.sized&&!this.ready){var t=this.element,e=this.options,n=this.image,r=t.parentNode,o=document.createElement("div");o.innerHTML='<div class="cropper-container" touch-action="none"><div class="cropper-wrap-box"><div class="cropper-canvas"></div></div><div class="cropper-drag-box"></div><div class="cropper-crop-box"><span class="cropper-view-box"></span><span class="cropper-dashed dashed-h"></span><span class="cropper-dashed dashed-v"></span><span class="cropper-center"></span><span class="cropper-face"></span><span class="cropper-line line-e" data-cropper-action="e"></span><span class="cropper-line line-n" data-cropper-action="n"></span><span class="cropper-line line-w" data-cropper-action="w"></span><span class="cropper-line line-s" data-cropper-action="s"></span><span class="cropper-point point-e" data-cropper-action="e"></span><span class="cropper-point point-n" data-cropper-action="n"></span><span class="cropper-point point-w" data-cropper-action="w"></span><span class="cropper-point point-s" data-cropper-action="s"></span><span class="cropper-point point-ne" data-cropper-action="ne"></span><span class="cropper-point point-nw" data-cropper-action="nw"></span><span class="cropper-point point-sw" data-cropper-action="sw"></span><span class="cropper-point point-se" data-cropper-action="se"></span></div></div>';var i=o.querySelector(".".concat("cropper","-container")),a=i.querySelector(".".concat("cropper","-canvas")),s=i.querySelector(".".concat("cropper","-drag-box")),c=i.querySelector(".".concat("cropper","-crop-box")),u=c.querySelector(".".concat("cropper","-face"));this.container=r,this.cropper=i,this.canvas=a,this.dragBox=s,this.cropBox=c,this.viewBox=i.querySelector(".".concat("cropper","-view-box")),this.face=u,a.appendChild(n),X(t,f),r.insertBefore(i,t.nextSibling),this.isImg||Y(n,g),this.initPreview(),this.bind(),e.initialAspectRatio=Math.max(0,e.initialAspectRatio)||NaN,e.aspectRatio=Math.max(0,e.aspectRatio)||NaN,e.viewMode=Math.max(0,Math.min(3,Math.round(e.viewMode)))||0,X(c,f),e.guides||X(c.getElementsByClassName("".concat("cropper","-dashed")),f),e.center||X(c.getElementsByClassName("".concat("cropper","-center")),f),e.background&&X(i,"".concat("cropper","-bg")),e.highlight||X(u,v),e.cropBoxMovable&&(X(u,y),tt(u,b,"all")),e.cropBoxResizable||(X(c.getElementsByClassName("".concat("cropper","-line")),f),X(c.getElementsByClassName("".concat("cropper","-point")),f)),this.render(),this.ready=!0,this.setDragMode(e.dragMode),e.autoCrop&&this.crop(),this.setData(e.data),U(e.ready)&&ot(t,"ready",e.ready,{once:!0}),it(t,"ready")}}},{key:"unbuild",value:function(){this.ready&&(this.ready=!1,this.unbind(),this.resetPreview(),this.cropper.parentNode.removeChild(this.cropper),Y(this.element,f))}},{key:"uncreate",value:function(){this.ready?(this.unbuild(),this.ready=!1,this.cropped=!1):this.sizing?(this.sizingImage.onload=null,this.sizing=!1,this.sized=!1):this.reloading?(this.xhr.onabort=null,this.xhr.abort()):this.image&&this.stop()}}])&&o(e.prototype,n),i&&o(e,i),t}();return q(jt.prototype,yt,bt,wt,xt,_t,Ot),jt}()},function(t,e,n){t.exports=n.p+"images/color.321ebce.jpg"},function(t,e){t.exports=function(t,e){return t===e||t!=t&&e!=e}},function(t,e,n){var r=n(349),o=n(341);t.exports=function(t){if(!o(t))return!1;var e=r(t);return"[object Function]"==e||"[object GeneratorFunction]"==e||"[object AsyncFunction]"==e||"[object Proxy]"==e}},function(t,e,n){(function(e){var n="object"==typeof e&&e&&e.Object===Object&&e;t.exports=n}).call(this,n(51))},function(t,e){var n=Function.prototype.toString;t.exports=function(t){if(null!=t){try{return n.call(t)}catch(t){}try{return t+""}catch(t){}}return""}},function(t,e,n){var r=n(407),o=n(402),i=Object.prototype.hasOwnProperty;t.exports=function(t,e,n){var a=t[e];i.call(t,e)&&o(a,n)&&(void 0!==n||e in t)||r(t,e,n)}},function(t,e,n){var r=n(488);t.exports=function(t,e,n){"__proto__"==e&&r?r(t,e,{configurable:!0,enumerable:!0,value:n,writable:!0}):t[e]=n}},function(t,e,n){var r=n(490),o=n(491),i=n(373),a=n(409),s=n(494),c=n(495),u=Object.prototype.hasOwnProperty;t.exports=function(t,e){var n=i(t),l=!n&&o(t),p=!n&&!l&&a(t),h=!n&&!l&&!p&&c(t),d=n||l||p||h,f=d?r(t.length,String):[],g=f.length;for(var v in t)!e&&!u.call(t,v)||d&&("length"==v||p&&("offset"==v||"parent"==v)||h&&("buffer"==v||"byteLength"==v||"byteOffset"==v)||s(v,g))||f.push(v);return f}},function(t,e,n){(function(t){var r=n(193),o=n(493),i=e&&!e.nodeType&&e,a=i&&"object"==typeof t&&t&&!t.nodeType&&t,s=a&&a.exports===i?r.Buffer:void 0,c=(s?s.isBuffer:void 0)||o;t.exports=c}).call(this,n(374)(t))},function(t,e){t.exports=function(t){return"number"==typeof t&&t>-1&&t%1==0&&t<=9007199254740991}},function(t,e){t.exports=function(t,e){return function(n){return t(e(n))}}},function(t,e,n){var r=n(403),o=n(410);t.exports=function(t){return null!=t&&o(t.length)&&!r(t)}},function(t,e){t.exports=function(){return[]}},function(t,e,n){var r=n(415),o=n(416),i=n(379),a=n(413),s=Object.getOwnPropertySymbols?function(t){for(var e=[];t;)r(e,i(t)),t=o(t);return e}:a;t.exports=s},function(t,e){t.exports=function(t,e){for(var n=-1,r=e.length,o=t.length;++n<r;)t[o+n]=e[n];return t}},function(t,e,n){var r=n(411)(Object.getPrototypeOf,Object);t.exports=r},function(t,e,n){var r=n(415),o=n(373);t.exports=function(t,e,n){var i=e(t);return o(t)?i:r(i,n(t))}},function(t,e,n){t.exports=n.p+"images/question.b0f36f5.svg"},,function(t,e,n){t.exports=n(449)},function(t,e,n){t.exports=n.p+"images/spinner.86352cb.svg"},function(t,e,n){t.exports=n.p+"images/spinner.c9f85c6.gif"},function(t,e,n){t.exports=n.p+"images/pwd-show.df8adfc.svg"},function(t,e,n){t.exports=n.p+"images/pwd-hide.a8bf451.svg"},function(t,e,n){t.exports=n(453)},,,,,,,,,,,,,,,,,function(t,e,n){"use strict";var r=n(1),o=r.b`:host{--button-padding: 0 10px;--border-color: transparent;--border-raduis: 6px;--font-color: #333;--font-size: 14px;--hover-color: #333;--hover-font-color: #fff;display:block}:host ::-moz-focus-inner{border:0}:host([primary]){--font-color: #fff}:host([primary]) button{background:#5b5b5b}:host([primary]) button:hover{background:#333}:host([white]){--border-color: #ebebeb}:host([white]) button{background:#fff}:host([white]:not([disabled])) button:hover{background:#efefef}:host([white][disabled]){--font-color: #999;cursor:not-allowed}:host([white][disabled]) button{cursor:not-allowed}:host([disabled]:not([white])) button{opacity:.5;cursor:not-allowed}:host([loading]) button{opacity:.5;cursor:not-allowed;display:flex;align-items:center}:host([loading]) .loading{width:36px;vertical-align:middle;margin-left:3px}:host([loading]) button>span{flex:1;width:0}button{display:inline-block;width:100%;height:100%;min-height:28px;border:1px solid var(--border-color);outline:none;border-radius:var(--border-raduis);color:var(--font-color);padding:var(--button-padding);background:#efefef;font-size:var(--font-size);transition:all .3s;cursor:pointer;overflow:hidden;position:relative}button>span{text-overflow:ellipsis;white-space:nowrap;overflow:hidden;font-size:14px;width:100%;display:block}button:hover{background:#dfdfdf}`,i=n(421),a=n.n(i),s=function(t,e,n,r){var o,i=arguments.length,a=i<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(t,e,n,r);else for(var s=t.length-1;s>=0;s--)(o=t[s])&&(a=(i<3?o(a):i>3?o(e,n,a):o(e,n))||a);return i>3&&a&&Object.defineProperty(e,n,a),a},c=function(t,e){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(t,e)};let u=class extends r.a{constructor(){super(...arguments),this.disabled=!1,this.scaleRatio=1,this.loading=!1}firstUpdated(){this.addEventListener("mousedown",t=>{const{left:e,top:n,width:r}=this.getBoundingClientRect(),o=r/this.offsetWidth;this.style.setProperty("--x",(t.clientX-e)/o+"px"),this.style.setProperty("--y",(t.clientY-n)/o+"px")}),this.addEventListener("click",t=>{this.loading&&t.stopPropagation()},!0)}render(){return r.e`
      <button ?disabled="${this.disabled}">
        <span><slot></slot></span>
        ${this.renderSpin()}
      </button>
    `}renderSpin(){return this.loading?r.e` <img class="loading" src=${a.a} /> `:r.e``}};u.styles=o,s([Object(r.g)({type:Boolean,reflect:!0}),c("design:type",Object)],u.prototype,"disabled",void 0),s([Object(r.g)({type:Number}),c("design:type",Object)],u.prototype,"scaleRatio",void 0),s([Object(r.g)({type:Boolean,reflect:!0}),c("design:type",Object)],u.prototype,"loading",void 0),u=s([Object(r.c)("infinito-button")],u);function l(t,e,n,r=!0,o=!0){const i=new CustomEvent(e,{detail:n,bubbles:r,composed:o});t.dispatchEvent(i)}const p=(t,e)=>{let n=!1;const r=e+5,o=()=>{n=!0,t.removeEventListener("transitionend",o)};t.addEventListener("transitionend",o),setTimeout(()=>{n||(t=>{t.dispatchEvent(new Event("transitionend"))})(t)},r)};var h=function(t,e,n,r){var o,i=arguments.length,a=i<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(t,e,n,r);else for(var s=t.length-1;s>=0;s--)(o=t[s])&&(a=(i<3?o(a):i>3?o(e,n,a):o(e,n))||a);return i>3&&a&&Object.defineProperty(e,n,a),a},d=function(t,e){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(t,e)};let f=class extends r.a{constructor(){super(...arguments),this.checked=!1,this.disabled=!1}_changeHandler(){this.checked=this.formElement.checked,l(this,"change",{checked:this.checked})}render(){return r.e`
      <div class="switch-wrapper">
        <input
          hidden
          id="switch"
          type="checkbox"
          role="switch"
          .disabled="${this.disabled}"
          .checked=${this.checked}
          @change="${this._changeHandler}"
        >
        <label class="switch" for="switch"></label>
      </div>
    `}};f.styles=r.b`
    :host {
      --switch-color: #333;
    }
    .switch {
      box-sizing: border-box;
      display: inline-block;
      position: relative;
      width: 24px;
      height: 16px;
      border-radius: 20px;
      border: 2px solid var(--switch-color);
      transition: background 0.28s cubic-bezier(0.4, 0, 0.2, 1);
      vertical-align: middle;
      cursor: pointer;
      opacity: .2;
    }
    .switch::before {
      content: '';
      position: absolute;
      top: 1px;
      left: 1px;
      width: 10px;
      height: 10px;
      background: var(--switch-color);
      border-radius: 50%;
      transition: left 0.28s cubic-bezier(0.4, 0, 0.2, 1),
        background 0.28s cubic-bezier(0.4, 0, 0.2, 1),
        box-shadow 0.28s cubic-bezier(0.4, 0, 0.2, 1);
    }
    /* .switch:active::before {
      box-shadow: 0 2px 8px rgba(0,0,0,0.28), 0 0 0 20px rgba(128,128,128,0.1);
    } */
    input:checked + .switch {
      border: 2px solid var(--switch-color);
      opacity: 1;
    }
    input:checked + .switch::before {
      left: 9px;
      background: var(--switch-color);
    }
    /* input:checked + .switch:active::before {
      box-shadow: 0 2px 8px rgba(0,0,0,0.28), 0 0 0 20px rgba(128,128,128,0.1);
    } */
    :host([disabled]) .switch {
      cursor: not-allowed;
    }
    input:disabled + .switch {
      cursor: not-allowed
    }
  `,h([Object(r.g)({type:Boolean}),d("design:type",Object)],f.prototype,"checked",void 0),h([Object(r.g)({type:Boolean}),d("design:type",Object)],f.prototype,"disabled",void 0),h([Object(r.h)("input"),d("design:type",HTMLInputElement)],f.prototype,"formElement",void 0),f=h([Object(r.c)("infinito-switch")],f);var g=function(t,e,n,r){var o,i=arguments.length,a=i<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(t,e,n,r);else for(var s=t.length-1;s>=0;s--)(o=t[s])&&(a=(i<3?o(a):i>3?o(e,n,a):o(e,n))||a);return i>3&&a&&Object.defineProperty(e,n,a),a},v=function(t,e){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(t,e)};let m=class extends r.a{constructor(){super(...arguments),this.value=0,this.text="",this.min=0,this.max=10,this.step=1,this.readonly=!1}stepChangeValue(t){var e;let n=this.value;"up"===t?this.value+this.step<this.max?n+=this.step:n=this.max:"down"===t&&(this.value-this.step>this.min?n-=this.step:n=this.min);const r=null===(e=this.step.toString().split(".")[1])||void 0===e?void 0:e.length;n=Number(n.toFixed(r)),this.value=n,l(this,"on-change",{value:this.value})}render(){return r.e`
      <div class="i-input-number">
        <div class="input-wrap">
          ${this.readonly?r.e`<span class="input">${this.text}</span>`:r.e`<input class="input" value=${this.value} />`}
        </div>
        <div class="input-handler-wrap">
          <span @click="${()=>this.stepChangeValue("up")}" class="input-handler input-handler-up">
            <svg
              width="7px"
              height="5px"
              viewBox="0 0 7 5"
              version="1.1"
              xmlns="http://www.w3.org/2000/svg"
              xmlns:xlink="http://www.w3.org/1999/xlink"
            >
              <title>加@2x</title>
              <g id="页面-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                <g id="设置" transform="translate(-368.000000, -892.000000)" fill="#999999">
                  <g id="编组-12" transform="translate(319.000000, 887.000000)">
                    <polygon
                      id="加"
                      transform="translate(52.500000, 7.500000) scale(1, -1) translate(-52.500000, -7.500000) "
                      points="49 5 56 5 52.5 10"
                    ></polygon>
                  </g>
                </g>
              </g>
            </svg>
          </span>
          <span
            @click="${()=>this.stepChangeValue("down")}"
            class="input-handler input-handler-down"
          >
            <svg
              width="7px"
              height="5px"
              viewBox="0 0 7 5"
              version="1.1"
              xmlns="http://www.w3.org/2000/svg"
              xmlns:xlink="http://www.w3.org/1999/xlink"
            >
              <title>减@2x</title>
              <g id="页面-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                <g id="设置" transform="translate(-368.000000, -906.000000)" fill="#999999">
                  <g id="编组-12" transform="translate(319.000000, 887.000000)">
                    <polygon id="减" points="49 19 56 19 52.5 24"></polygon>
                  </g>
                </g>
              </g>
            </svg>
          </span>
        </div>
      </div>
    `}};m.styles=r.b`
    :host {
      --border-color: #fff;
      --bg-input-color:#fff
    }
    .i-input-number {
      height: 28px;
      min-width: 60px;
      box-sizing: border-box;
      display: flex;
      justify-content: flex-end;
      align-items: center;
      background: var(--bg-input-color, #fff);
      border-radius: 6px;
      border: 1px solid var(--border-color, #fff);
      transition: border-color 0.3s;
      overflow: hidden;
    }
    .i-input-number:hover {
      border-color: rgba(220, 220, 220, 1);
    }
    .i-input-number:hover .input-handler-wrap {
      opacity: 1;
    }
    .input-wrap {
      flex-grow: 1;
    }
    .input-wrap > .input {
      display: block;
      width: 100%;
      height: 100%;
      padding: 4px;
      box-sizing: border-box;
      outline: 0;
      border: 0;
    }
    .input-handler-wrap {
      opacity: 0;
      flex-grow: 0;
      flex-shrink: 0;
      width: 15px;
      box-sizing: border-box;
      border-left: 1px solid #dcdcdc;
      height: 100%;
      display: flex;
      flex-direction: column;
      transition: opacity 0.3s;
    }
    .input-handler {
      flex-grow: 0;
      flex-shrink: 0;
      height: 50%;
      display: flex;
      justify-content: center;
      align-items: center;
      background-color: #fff;
      transition: background-color 0.3s;
    }
    .input-handler-down{
      border-top: 1px solid #dcdcdc;
    }
    .input-handler:hover {
      background-color: #EFEFEF;
    }
  `,g([Object(r.g)({type:Number}),v("design:type",Object)],m.prototype,"value",void 0),g([Object(r.g)({type:String}),v("design:type",Object)],m.prototype,"text",void 0),g([Object(r.g)({type:Number}),v("design:type",Object)],m.prototype,"min",void 0),g([Object(r.g)({type:Number}),v("design:type",Object)],m.prototype,"max",void 0),g([Object(r.g)({type:Number}),v("design:type",Object)],m.prototype,"step",void 0),g([Object(r.g)({type:Boolean}),v("design:type",Object)],m.prototype,"readonly",void 0),m=g([Object(r.c)("infinito-inputnumber")],m);var y=function(t,e,n,r){var o,i=arguments.length,a=i<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(t,e,n,r);else for(var s=t.length-1;s>=0;s--)(o=t[s])&&(a=(i<3?o(a):i>3?o(e,n,a):o(e,n))||a);return i>3&&a&&Object.defineProperty(e,n,a),a},b=function(t,e){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(t,e)};let w=class extends r.a{constructor(){super(...arguments),this.name="",this.value=0,this.min=0,this.max=10,this.step=1,this.suffix="",this.sliderX=0,this.sliderWidth=0,this._touchDown=!1,this._mouseMove=t=>{let{clientX:e}=t;window.TouchEvent&&t instanceof TouchEvent&&(e=t.touches[0].clientX),this.moveBall(e)},this._mouseUp=t=>{this._touchDown=!1,t.target.removeEventListener("touchmove",this._mouseMove),t.target.removeEventListener("touchend",this._mouseUp),document.body.removeEventListener("mousemove",this._mouseMove),window.removeEventListener("mouseup",this._mouseUp),l(this,"on-end",{value:this.value})},this.emitChange=((t,e=16)=>{let n;return(...r)=>{n||(n=setTimeout(()=>{t(...r),n=null},e))}})(()=>{l(this,"on-change",{value:this.value})},20)}firstUpdated(){this.addEventListener("click",t=>{const{clientX:e}=t,{left:n,width:r}=this.$slider.getBoundingClientRect();this.sliderX=n,this.sliderWidth=r,this.moveBall(e)})}moveBall(t){var e;const{sliderX:n,sliderWidth:r}=this;let o=(r-(n+r-t))/r;o>1?o=1:o<0&&(o=0);const i=(this.max-this.min)*o+this.min,a=(null===(e=this.step.toString().split(".")[1])||void 0===e?void 0:e.length)||0,s=Number(i.toFixed(a));this.value!==s&&(this.value=s,this.emitChange())}pickBall(t){if(!0!==this._touchDown)if(this._touchDown=!0,window.TouchEvent&&t instanceof TouchEvent){const{left:e,width:n}=this.$slider.getBoundingClientRect();this.sliderX=e,this.sliderWidth=n,t.target.addEventListener("touchmove",this._mouseMove),t.target.addEventListener("touchend",this._mouseUp),l(this,"on-start",{value:this.value})}else{const{button:e}=t;if(0!==e)return;const{left:n,width:r}=this.$slider.getBoundingClientRect();this.sliderX=n,this.sliderWidth=r,document.body.addEventListener("mousemove",this._mouseMove),window.addEventListener("mouseup",this._mouseUp),l(this,"on-start",{value:this.value})}}render(){let t=0;return this.value!==this.min&&(t=(this.value-this.min)/(this.max-this.min)),r.e`
      <div class="i-slider">
        <div class="i-slider-picked" style="width:${Math.round(100*t)}%">
          <div
            @click="${t=>t.stopPropagation()}"
            @mousedown="${this.pickBall}"
            @touchstart="${this.pickBall}"
            class="ball"
          ></div>
        </div>
      </div>
      <div
        @click="${t=>{t.stopPropagation()}}"
        class="i-picker-tips"
      >
        <infinito-inputnumber
          readonly
          .step=${this.step}
          .min=${this.min}
          .max=${this.max}
          .text="${this.translator?r.e`${this.translator(this.value)+this.suffix}`:r.e`${this.value+this.suffix}`}"
          .value="${this.value}"
          @on-change="${t=>{this.value=t.detail.value}}"
        ></infinito-inputnumber>
      </div>
    `}};w.styles=r.b`
    :host {
      display: flex;
      align-items: center;
      padding: 0;
      width: 100%;
      cursor: pointer;
      --bg-color:#fff;
    }
    .i-slider {
      flex-grow: 1;
      display: flex;
      height: 2px;
      background-color: #eeeeee;
      margin-right: 10px;
    }
    .i-slider-picked {
      position: relative;
      height: 2px;
      background-color: #333;
    }
    .ball {
      position: absolute;
      right: 0;
      transform: translate(50%, -50%);
      width: 14px;
      height: 14px;
      background: rgba(255, 255, 255, 1);
      border-radius: 50%;
      border: 2px solid rgba(51, 51, 51, 1);
      transition-timing-function: ease;
      transition-duration: 0.3s;
      transition-property: box-shadow;
    }
    .ball:active {
      box-shadow: 0 0 0 4px rgba(0, 0, 0, 0.1);
    }
    .i-picker-tips {
      padding: 4px 0;
      width: 60px;
      text-align: right;
      font-weight: 500;
      color: rgba(51, 51, 51, 1);
    }
    infinito-inputnumber{
      --border-color:var(--bg-color);
      --bg-input-color:var(--bg-color);
    }
  `,y([Object(r.h)(".i-slider"),b("design:type",HTMLDivElement)],w.prototype,"$slider",void 0),y([Object(r.g)({type:String}),b("design:type",Object)],w.prototype,"name",void 0),y([Object(r.g)({type:Number}),b("design:type",Object)],w.prototype,"value",void 0),y([Object(r.g)({type:Number}),b("design:type",Object)],w.prototype,"min",void 0),y([Object(r.g)({type:Number}),b("design:type",Object)],w.prototype,"max",void 0),y([Object(r.g)({type:Number}),b("design:type",Object)],w.prototype,"step",void 0),y([Object(r.g)({type:String}),b("design:type",Object)],w.prototype,"suffix",void 0),y([Object(r.g)({attribute:!1}),b("design:type",Function)],w.prototype,"translator",void 0),w=y([Object(r.c)("infinito-slider")],w);var x=function(t,e,n,r){var o,i=arguments.length,a=i<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(t,e,n,r);else for(var s=t.length-1;s>=0;s--)(o=t[s])&&(a=(i<3?o(a):i>3?o(e,n,a):o(e,n))||a);return i>3&&a&&Object.defineProperty(e,n,a),a},_=function(t,e){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(t,e)};let O=class extends r.a{constructor(){super(...arguments),this.cTitle="",this.close=!1,this.isTransition=!1}handleChange(){this.close?this.show():this.hide()}show(){if(this.isTransition||!this.close)return;this.$cardBody.style.height="0px",this.$cardBody.classList.add("transition"),this.isTransition=!0,this.close=!1;this.$cardBody.addEventListener("transitionend",()=>{this.$cardBody.style.height="",this.$cardBody.classList.remove("transition"),this.isTransition=!1},{once:!0}),p(this.$cardBody,300),this.$cardBody.style.height=this.$cardBody.scrollHeight+"px"}hide(){if(this.isTransition||this.close)return;this.$cardBody.style.height=this.$cardBody.getBoundingClientRect().height+"px",this.$cardBody.classList.add("transition"),this.$cardBody.offsetHeight,this.isTransition=!0,this.close=!0;this.$cardBody.addEventListener("transitionend",()=>{this.$cardBody.style.height="",this.$cardBody.classList.remove("transition"),this.isTransition=!1},{once:!0}),p(this.$cardBody,300),this.$cardBody.style.height="0px"}render(){let t=r.e``;return this.cTitle&&(t=this.renderHeading()),r.e`
      <div class="infinito-card-wrapper ${this.close?"close":"open"}">
        ${t}
        <div class="card-body">
          <div class="card-body-wrapper">
            <slot></slot>
          </div>
        </div>
      </div>
    `}renderHeading(){const t=this.close?r.e`${r.e`
    <svg width="12px" height="13px" viewBox="0 0 12 13">
      <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <g transform="translate(-358.000000, -214.000000)" stroke="#CCCCCC" stroke-width="2">
          <g transform="translate(30.000000, 188.000000)">
            <g transform="translate(20.000000, 20.000000)">
              <g transform="translate(308.000000, 6.000000)">
                <line x1="0" y1="6.5" x2="12" y2="6.5"></line>
                <line x1="6" y1="0.5" x2="6" y2="12.5"></line>
              </g>
            </g>
          </g>
        </g>
      </g>
    </svg>
  `}`:r.e`${r.e`
    <svg width="12px" height="13px" viewBox="0 0 12 13">
      <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <g transform="translate(-358.000000, -147.000000)" stroke="#CCCCCC" stroke-width="2">
          <g transform="translate(50.000000, 141.000000)">
            <g transform="translate(308.000000, 6.000000)">
              <line x1="0" y1="6.5" x2="12" y2="6.5"></line>
            </g>
          </g>
        </g>
      </g>
    </svg>
  `}`;return r.e`
      <div class="card-head" @click=${this.handleChange}>
        <div class="card-head-wrapper">
          <div class="card-head-title">${this.cTitle}</div>
            <div class="card-extra">
              ${t}
            </div>
          </div>
        </div>
      </div>
    `}};O.styles=r.b`
    :host {
      display: block;
      --padding-bottom: 30px;
      --card-color: #fff;
      --border-radius: 0px;
      --margin-left: 20px;
      --margin-right: 20px;
    }
    .infinito-card-wrapper {
      margin-bottom: 30px;
      padding-top: 20px;
      padding-bottom: var(--padding-bottom);
      background: var(--card-color);
      border-radius: var(--border-radius);
      border-bottom: 1px solid transparent;
      transition: margin-bottom 0.3s ease-in-out, padding-bottom 0.3s ease-in-out;
    }
    .infinito-card-wrapper.close {
      margin-bottom: 0;
      border-bottom-color: #f5f5f5;
      padding-bottom: 20px;
    }
    .close .card-body {
      height: 0;
    }
    .card-body {
      transition: height 0.3s ease-in-out;
    }
    .close .card-body,
    .transition.card-body {
      overflow: hidden;
    }
    .card-head {
      margin-left: 20px;
      margin-right: 20px;
    }
    .card-body-wrapper {
      margin-left: var(--margin-left);
      margin-right: var(--margin-right);
    }

    .card-head-wrapper {
      position: relative;
      display: flex;
      align-items: center;
      justify-content: space-between;
      cursor: pointer;
    }

    .card-head-wrapper:after {
      content: '';
      position: absolute;
      inset: -20px;
      bottom: -10px;
    }

    .infinito-card-wrapper.close .card-head-wrapper:after {
      bottom: -20px;
    }

    .card-extra {
      transition: opacity 0.3s;
      cursor: pointer;
    }
    .card-extra:hover {
      opacity: 0.5;
    }
    .card-head-title {
      font-size: 18px;
      color: #333;
      font-weight: 700;
    }
  `,x([Object(r.g)({type:String}),_("design:type",Object)],O.prototype,"cTitle",void 0),x([Object(r.g)({type:Boolean,reflect:!0}),_("design:type",Object)],O.prototype,"close",void 0),x([Object(r.g)({type:Boolean}),_("design:type",Object)],O.prototype,"isTransition",void 0),x([Object(r.h)(".card-body"),_("design:type",HTMLDivElement)],O.prototype,"$cardBody",void 0),O=x([Object(r.c)("infinito-card")],O);var S=function(t,e,n,r){var o,i=arguments.length,a=i<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(t,e,n,r);else for(var s=t.length-1;s>=0;s--)(o=t[s])&&(a=(i<3?o(a):i>3?o(e,n,a):o(e,n))||a);return i>3&&a&&Object.defineProperty(e,n,a),a},j=function(t,e){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(t,e)};let k=class extends r.a{constructor(){super(...arguments),this.checked=!1,this.disabled=!1,this.value=""}render(){return r.e`
      <label class="radio-wrapper">
        <span class="radio">
          <input
            class="radio-input"
            type="radio"
            .value="${this.value}"
            .checked="${this.checked}"
            ?disabled="${this.disabled}"
            @change="${this._changeHandle}"
          />
          <span class="radio-inner"></span>
        </span>
        <span class="radio-content">
          <slot></slot>
        </span>
      </label>
    `}_changeHandle(){this.checked=this.input.checked,l(this,"change",{checked:this.checked})}};k.styles=r.b`
    :host {
      --border-color: #333;
      display: inline-flex;
    }
    :host([disabled]) {
      opacity: .6;
    }
    .radio-wrapper {
      display: inline-flex;
      align-items: center;
      margin: 0;
      margin-right: 10px;
      padding: 0;
      color: #333;
      font-size: 14px;
      cursor: pointer;
    }
    :host([disabled]) .radio-wrapper {
      cursor: not-allowed;
    }
    .radio {
      position: relative;
      display: inline-block;
      margin-right: 8px;
    }
    .radio-input {
      position: absolute;
      top: 0;
      right: 0;
      bottom: 0;
      left: 0;
      margin: 0;
      padding: 0;
      z-index: 1;
      opacity: 0;
      cursor: pointer;
    }
    :host([disabled]) .radio-input {
      cursor: not-allowed;
    }
    .radio-inner {
      box-sizing: border-box;
      position: relative;
      display: block;
      width: 14px;
      height: 14px;
      border: 2px solid var(--border-color);
      border-radius: 50%;
      transition: all .3s;
    }
    .radio-inner::after {
      content: " ";
      position: absolute;
      top: 2px;
      left: 2px;
      width: 6px;
      height: 6px;
      border-radius: 50%;
      opacity: 0;
      transition: all .3s;
    }
    .radio-input:checked + .radio-inner {
      background: var(--border-color);
    }
    .radio-input:checked + .radio-inner::after {
      background: #fff;
      opacity: 1;
    }
  `,S([Object(r.h)("input"),j("design:type",HTMLInputElement)],k.prototype,"input",void 0),S([Object(r.g)({type:Boolean}),j("design:type",Object)],k.prototype,"checked",void 0),S([Object(r.g)({type:Boolean,reflect:!0}),j("design:type",Object)],k.prototype,"disabled",void 0),S([Object(r.g)({type:String}),j("design:type",Object)],k.prototype,"value",void 0),k=S([Object(r.c)("infinito-radio")],k);var A=function(t,e,n,r){var o,i=arguments.length,a=i<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(t,e,n,r);else for(var s=t.length-1;s>=0;s--)(o=t[s])&&(a=(i<3?o(a):i>3?o(e,n,a):o(e,n))||a);return i>3&&a&&Object.defineProperty(e,n,a),a},T=function(t,e){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(t,e)};let E=class extends r.a{constructor(){super(...arguments),this.radioNodes=[]}render(){return r.e`
      <div class="radio-group-wrapper">
        <slot id="slot" @slotchange="${this.slotChange}"></slot>
      </div>
    `}connectedCallback(){super.connectedCallback(),this.addEventListener("change",this.handleChecked)}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener("change",this.handleChecked)}handleChecked(t){const e=t.target,n=t.detail.checked,r=e.value||"";n?this.selected=n&&r||"":e.checked=!0,this.radioNodes.forEach(t=>t.checked=t===e),l(this,"on-change",{selected:this.selected})}slotChange(){this.requestUpdate()}updated(){const t=this.radioSlot.assignedNodes();if(t&&t.length)for(let e=0;e<t.length;e++){const n=t[e];if("INFINITO-RADIO"===n.tagName){this.radioNodes.push(n);const t=n.value||"";this.selected&&t===this.selected?n.checked=!0:n.checked=!1}}}};A([Object(r.h)("#slot"),T("design:type",HTMLElement)],E.prototype,"radioSlot",void 0),A([Object(r.g)({type:String}),T("design:type",String)],E.prototype,"selected",void 0),E=A([Object(r.c)("infinito-radio-group")],E);var C=function(t,e,n,r){var o,i=arguments.length,a=i<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(t,e,n,r);else for(var s=t.length-1;s>=0;s--)(o=t[s])&&(a=(i<3?o(a):i>3?o(e,n,a):o(e,n))||a);return i>3&&a&&Object.defineProperty(e,n,a),a},R=function(t,e){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(t,e)};let I=class extends r.a{constructor(){super(...arguments),this.closeable=!0,this.open=!1,this.duration=200,this.durationBg=200,this.bezierFn="ease-in",this.bezierBgFn="ease-in"}firstUpdated(){this.$modalMask.onwheel=()=>!1}updated(t){t.has("open")&&!0===this.open&&(this.$modal.animate([{opacity:"0"},{opacity:"1"}],{duration:this.durationBg,easing:this.bezierBgFn}),this.$modalContainer.animate([{opacity:"0",transform:"scale(0.8)"},{opacity:"1",transform:"none"}],{duration:this.duration,easing:this.bezierFn}))}render(){return r.e`
      <div class="modal ${this.open?"modal-open":""}">
        <div class="modal-mask" @click=${this.handleMaskClick}></div>
        <div class="model-holder-top"></div>
        <div class="modal-container">
          <span class="modal-close" @click="${this.close}">
            ${this.closeable?r.e`
    <svg width="14px" height="14px" viewBox="0 0 14 14">
      <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" opacity="1">
        <g transform="translate(-1086.000000, -226.000000)" fill="#333333" fill-rule="nonzero">
          <g transform="translate(320.000000, 206.000000)">
            <g>
              <g transform="translate(766.000000, 20.000000)">
                <g>
                  <path d="M13.2303076,0.802251953 C12.8052342,0.377204963 12.1160812,0.377207829 11.6910113,0.802258354 L7.05672461,5.43633398 L7.05672461,5.43633398 L2.38977766,0.769621758 C1.96470002,0.344565503 1.27553537,0.344566517 0.850458984,0.769624023 C0.425408624,1.19465551 0.425393322,1.883783 0.850424806,2.30883336 C0.850436954,2.30884551 0.850449102,2.30885766 0.85046125,2.3088698 L5.5174082,6.97558203 L5.5174082,6.97558203 L0.866831437,11.6259476 C0.441760949,12.0509988 0.441745304,12.7401586 0.866796493,13.1652291 C0.866798899,13.1652315 0.866801305,13.1652339 0.866803711,13.1652363 C1.29186357,13.5903075 1.98103035,13.5903186 2.40610392,13.1652611 L7.05671094,8.51483008 L7.05671094,8.51483008 L11.6909746,13.1489765 C12.1160521,13.5740432 12.8052287,13.5740389 13.2303008,13.1489668 C13.6553632,12.7239044 13.6553632,12.034742 13.2303008,11.6096796 C13.2302959,11.6096747 13.230291,11.6096699 13.2302862,11.609665 L8.59602734,6.97558203 L8.59602734,6.97558203 L13.2303169,2.34146831 C13.6553572,1.91644415 13.6553703,1.22733077 13.2303461,0.802290481 C13.2303333,0.802277638 13.2303205,0.802264795 13.2303076,0.802251953 Z"></path>
                </g>
              </g>
            </g>
          </g>
        </g>
      </g>
    </svg>
  `:null}
          </span>
          <div class="modal-body">
            <slot name="body"></slot>
          </div>
          <div class="modal-foot">
            <slot name="foot"></slot>
          </div>
        </div>
        <div class="model-holder-bottom"></div>
      </div>
    `}close(){this.open=!1,this.onCancel&&this.onCancel()}handleMaskClick(){this.closeable&&(this.open=!1,this.onCancel&&this.onCancel())}};I.styles=r.b`
    :host {
      --top: 0;
      --right: 0;
      --bottom: 0;
      --left: 0;
      --modal-padding: 20px;
      --border-radius: 6px;
      --margin-top:0;
    }
    .modal {
      position: fixed;
      top: var(--top);
      right: var(--right);
      bottom: var(--bottom);
      left: var(--left);
      flex-direction: column;
      align-items: center;
      z-index: 100000;
      display: none;
      margin-top:var(--margin-top)
    }
    .modal.modal-open {
      display: flex;
    }
    .modal-mask {
      position: fixed;
      top: var(--top);
      right: var(--right);
      bottom: var(--bottom);
      left: var(--left);
      background: rgba(0, 0, 0, 0.4);
      z-index: -1;
    }
    .modal-close {
      position: absolute;
      right: 20px;
      top: 20px;
      cursor: pointer;
      transition: opacity 0.3s;
      opacity: 0.2;
    }
    .modal-close:hover {
      opacity: 0.4;
    }
    .model-holder-top,
    .model-holder-bottom {
      flex-grow: 1;
    }
    .model-holder-bottom {
      height: var(--modal-top, 15vh);
    }
    .modal-container {
      box-sizing: border-box;
      position: relative;
      padding: var(--modal-padding);
      background: #fff;
      box-shadow: 0px 2px 14px 0px rgba(0, 0, 0, 0.14);
      border-radius: var(--border-radius);
      pointer-events: auto;
    }
  `,C([Object(r.g)({type:Boolean,reflect:!0}),R("design:type",Object)],I.prototype,"closeable",void 0),C([Object(r.g)({type:Boolean,reflect:!0}),R("design:type",Object)],I.prototype,"open",void 0),C([Object(r.g)(),R("design:type",Object)],I.prototype,"onCancel",void 0),C([Object(r.g)({type:Number}),R("design:type",Object)],I.prototype,"duration",void 0),C([Object(r.g)({type:Number}),R("design:type",Object)],I.prototype,"durationBg",void 0),C([Object(r.g)({type:String}),R("design:type",Object)],I.prototype,"bezierFn",void 0),C([Object(r.g)({type:String}),R("design:type",Object)],I.prototype,"bezierBgFn",void 0),C([Object(r.h)(".modal"),R("design:type",HTMLDivElement)],I.prototype,"$modal",void 0),C([Object(r.h)(".modal-container"),R("design:type",HTMLDivElement)],I.prototype,"$modalContainer",void 0),C([Object(r.h)(".modal-mask"),R("design:type",HTMLDivElement)],I.prototype,"$modalMask",void 0),I=C([Object(r.c)("infinito-modal")],I);var P=n(422),M=n.n(P),L=function(t,e,n,r){var o,i=arguments.length,a=i<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(t,e,n,r);else for(var s=t.length-1;s>=0;s--)(o=t[s])&&(a=(i<3?o(a):i>3?o(e,n,a):o(e,n))||a);return i>3&&a&&Object.defineProperty(e,n,a),a},N=function(t,e){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(t,e)};let B=class extends r.a{constructor(){super(...arguments),this.spinning=!1,this.tip="",this.delay=0,this.isSvg=!1}render(){let t=r.e``;return this.tip&&(t=this.renderTip()),r.e`
      <div class="spin-wrapper">
        ${this.spinning?r.e`
            <div class="spin-spinning">
              ${this.isSvg?r.e`
                    <svg style="margin: auto; display: block;" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid">
                      <path fill="none" stroke-width="9" stroke-dasharray="215.53469970703125 41.054228515625" d="M24.3 30C11.4 30 5 43.3 5 50s6.4 20 19.3 20c19.3 0 32.1-40 51.4-40 C88.6 30 95 43.3 95 50s-6.4 20-19.3 20C56.4 70 43.6 30 24.3 30z" stroke-linecap="round">
                        <animate attributeName="stroke-dashoffset" repeatCount="indefinite" dur="1.5384615384615383s" keyTimes="0;1" values="0;256.58892822265625"></animate>
                      </path>
                    </svg>
                  `:r.e`<img src=${M.a} />`}
              ${t}
            </div>
          `:null}
        <div class="spin-content spin-blur">
          <slot></slot>
        </div>
      </div>
    `}renderTip(){return r.e`
      <div class="spin-text">${this.tip}</div>
    `}};B.styles=r.b`
    :host {
      --spin-color: #e7e7e7;
      --tip-color: var(--spin-color);
      display: block;
      width: 110px;
      height: 55px;
    } 
    .spin-wrapper {
      position: relative;
      width: 100%;
      height: 100%;
      overflow: hidden;
    }
    .spin-spinning {
      position: absolute;
      top: 0;
      right: 0;
      bottom: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 1;
    }
    img,
    svg {
      width: 100%;
      height: 100%;
    }
    svg path {
      stroke: var(--spin-color);
      transform: scale(2);
      transform-origin: center;
    }
    .spin-text {
      position: absolute;
      top: 50%;
      width: 100%;
      padding-top: 20px;
      font-size: 14px;
      text-align: center;
      color: var(--tip-color);
      text-shadow: 0 1px 2px #fff;
    }
    .spin-content {
      width: 100%;
      height: 100%;
      transition: opacity .3s;
    }
    .spin-blur {
      opacity: .3;
      user-select: none;
      pointer-events: none;
    }
  `,L([Object(r.g)({type:Boolean,reflect:!0}),N("design:type",Object)],B.prototype,"spinning",void 0),L([Object(r.g)({type:String}),N("design:type",Object)],B.prototype,"tip",void 0),L([Object(r.g)({type:Number}),N("design:type",Object)],B.prototype,"delay",void 0),L([Object(r.g)({type:Boolean}),N("design:type",Object)],B.prototype,"isSvg",void 0),B=L([Object(r.c)("infinito-spin")],B);var D=n(423),U=n.n(D),$=n(424),z=n.n($),V=function(t,e,n,r){var o,i=arguments.length,a=i<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(t,e,n,r);else for(var s=t.length-1;s>=0;s--)(o=t[s])&&(a=(i<3?o(a):i>3?o(e,n,a):o(e,n))||a);return i>3&&a&&Object.defineProperty(e,n,a),a},q=function(t,e){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(t,e)};let F=class extends r.a{constructor(){super(...arguments),this.type="text",this.placeholder="",this.value="",this.name="",this.readonly=!1,this.disabled=!1,this.error="",this._show=!1,this.isShowEye=!0}firstUpdated(){"password"===this.type&&requestAnimationFrame(()=>{this.controlIcon&&this.controlIcon.addEventListener("click",()=>{this._show=!this._show})})}render(){let t=r.e``;return this.error&&(t=this.renderError()),r.e`
      <div
        class="input-control ${this.error?"input-error":""}  ${"password"===this.type&&this.isShowEye?"eye":""}"
      >
        <input
          autocomplete="off"
          .type="${this._show?"text":this.type}"
          .name="${this.name}"
          .value="${this.value}"
          .placeholder="${this.placeholder}"
          ?readonly=${this.readonly}
          ?disabled=${this.disabled}
          @input="${this.handleInputChange}"
          @blur="${this.handleBlur}"
          @focus=${this.handleFocus}
        />
        ${"password"===this.type&&this.isShowEye?r.e`
                <i
                  class="input-pwd-eye"
                  style="background: url(${this._show?U.a:z.a}) no-repeat"
                ></i>
              `:null}
        ${t}
      </div>
    `}renderError(){return r.e`
      <div class="error">
        <span>${this.error}</span>
      </div>
    `}handleInputChange(){this.value=this.inputEle.value,l(this,"onchange",{value:this.value})}handleBlur(){this.inputEle.blur(),l(this,"onblur",{value:this.value})}handleFocus(){l(this,"onfocus",{value:this.value})}};F.styles=r.b`
    :host {
      --border-width: 1px;
      --border-style: solid;
      --border-color: #999;
      --border-hover-color: #333;
      --border-radius: 6px;
      --padding-all: 15px 20px 14px;
      --error-color: #ea4747;
      display: block;
      width: 330px;
      /* height: 52px; */
    }
    ::placeholder {
      color: #999;
      opacity: 1;
    }
    :-ms-input-placeholder {
      color: #999;
    }
    ::-ms-input-placeholder {
      color: #999;
    }
    :host([readonly]) {
      opacity: 0.5;
    }
    :host([disabled]) {
      opacity: 0.5;
      cursor: not-allowed;
    }
    .input-control {
      box-sizing: border-box;
      position: relative;
      /* display: flex; */
      /* align-items: center; */
      width: 100%;
      height: 100%;
      /* border: var(--border-width) var(--border-style) var(--border-color); */
      /* border-radius: var(--border-radius); */
      transition: all 0.3s;
      /* padding-right: 20px; */
    }
    .input-control:focus-within,
    .input-control:hover {
      border-color: var(--border-hover-color);
    }

    .input-control:focus-within .input-pwd-eye,
    .input-control:hover .input-pwd-eye {
      opacity: 1;
    }

    .input-control .input-pwd-eye {
      position: absolute;
      right: 20px;
      top: 17px;
      width: 18px;
      height: 18px;
      cursor: pointer;
      transition: opacity 200ms;
      opacity: 0;
    }

    :host([readonly]) .input-control:hover,
    :host([disabled]) .input-control:hover {
      border-width: var(--border-width);
    }
    input {
      position: relative;
      box-sizing: border-box;
      width: 100%;
      height: 52px;
      /* flex: 1; */
      /* height: 100%; */
      padding: var(--padding-all);
      background: none;
      border: none;
      outline: none;
      color: #333;
      border: var(--border-width) var(--border-style) var(--border-color);
      border-radius: var(--border-radius);
      font-family: PingFangSC-Regular, "PingFang SC";
    }
    .input-control.input-error input {
      border-color: var(--error-color);
      animation: shake 0.2s ease-in-out 0s 2;
    }
    .input-control.eye input {
      padding-right: 58px;
    }
    :host([disabled]) input {
      cursor: not-allowed;
    }
    .error {
      color: var(--error-color);
      font-size: 12px;
      font-weight: 500;
      word-break: break-all;
      text-align: right;
    }
    @keyframes shake {
      0% {
        margin-left: 0rem;
      }
      25% {
        margin-left: 0.5rem;
      }
      75% {
        margin-left: -0.5rem;
      }
      100% {
        margin-left: 0rem;
      }
    }
  `,V([Object(r.h)("input"),q("design:type",HTMLInputElement)],F.prototype,"inputEle",void 0),V([Object(r.h)(".input-pwd-eye"),q("design:type",HTMLElement)],F.prototype,"controlIcon",void 0),V([Object(r.g)({type:String}),q("design:type",String)],F.prototype,"type",void 0),V([Object(r.g)({type:String}),q("design:type",Object)],F.prototype,"placeholder",void 0),V([Object(r.g)({type:String,reflect:!0}),q("design:type",Object)],F.prototype,"value",void 0),V([Object(r.g)({type:String}),q("design:type",Object)],F.prototype,"name",void 0),V([Object(r.g)({type:Boolean}),q("design:type",Object)],F.prototype,"readonly",void 0),V([Object(r.g)({type:Boolean}),q("design:type",Object)],F.prototype,"disabled",void 0),V([Object(r.g)({type:String}),q("design:type",Object)],F.prototype,"error",void 0),V([Object(r.g)({type:Boolean}),q("design:type",Object)],F.prototype,"_show",void 0),V([Object(r.g)({type:Boolean,reflect:!0}),q("design:type",Object)],F.prototype,"isShowEye",void 0),V([Object(r.d)({passive:!0}),q("design:type",Function),q("design:paramtypes",[]),q("design:returntype",void 0)],F.prototype,"handleInputChange",null),F=V([Object(r.c)("infinito-input")],F);var H=function(t,e,n,r){var o,i=arguments.length,a=i<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(t,e,n,r);else for(var s=t.length-1;s>=0;s--)(o=t[s])&&(a=(i<3?o(a):i>3?o(e,n,a):o(e,n))||a);return i>3&&a&&Object.defineProperty(e,n,a),a},W=function(t,e){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(t,e)};function G(t,e){return new CustomEvent(t,{composed:!0,detail:e})}class X extends r.a{constructor(){super(...arguments),this.destination=""}render(){return r.e`
      <slot @slotchange="${this.slotChange}"></slot>
    `}disconnectedCallback(){document.dispatchEvent(G("portal-close",{destination:this.destination}))}slotChange(){this.requestUpdate()}updated(){const t=this.projectSlot.assignedNodes();t.length&&document.dispatchEvent(G("portal-open",{destination:this.destination,content:t}))}}X.styles=r.b`
    :host {
      display: none;
    }
  `,H([Object(r.h)("slot"),W("design:type",HTMLElement)],X.prototype,"projectSlot",void 0),H([Object(r.g)({type:String}),W("design:type",Object)],X.prototype,"destination",void 0);var Y=function(t,e,n,r){var o,i=arguments.length,a=i<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(t,e,n,r);else for(var s=t.length-1;s>=0;s--)(o=t[s])&&(a=(i<3?o(a):i>3?o(e,n,a):o(e,n))||a);return i>3&&a&&Object.defineProperty(e,n,a),a},K=function(t,e){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(t,e)};class J extends r.a{constructor(){super(...arguments),this.name="",this.projected=[],this.updatePortalContent=t=>{this.confirmDestination(t)&&t.detail.content&&(this.projected=t.detail.content)}}render(){return r.e`${this.projected}`}createRenderRoot(){return this}connectedCallback(){super.connectedCallback(),document.addEventListener("portal-open",this.updatePortalContent,!0),document.addEventListener("portal-close",this.updatePortalContent,!0)}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener("portal-open",this.updatePortalContent,!0),document.removeEventListener("portal-close",this.updatePortalContent,!0)}confirmDestination(t){return this.name||console.warn("This destination has not been named."),t.detail.destination===this.name&&(t.stopPropagation(),!0)}}Y([Object(r.g)({type:String}),K("design:type",Object)],J.prototype,"name",void 0),Y([Object(r.g)({type:Array}),K("design:type",Object)],J.prototype,"projected",void 0);var Q=function(t,e,n,r){var o,i=arguments.length,a=i<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(t,e,n,r);else for(var s=t.length-1;s>=0;s--)(o=t[s])&&(a=(i<3?o(a):i>3?o(e,n,a):o(e,n))||a);return i>3&&a&&Object.defineProperty(e,n,a),a};let Z=class extends X{};Z=Q([Object(r.c)("infinito-portal-entrance")],Z);let tt=class extends J{};tt=Q([Object(r.c)("infinito-portal-destination")],tt);var et=function(t,e,n,r){var o,i=arguments.length,a=i<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(t,e,n,r);else for(var s=t.length-1;s>=0;s--)(o=t[s])&&(a=(i<3?o(a):i>3?o(e,n,a):o(e,n))||a);return i>3&&a&&Object.defineProperty(e,n,a),a},nt=function(t,e){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(t,e)};let rt=class extends r.a{constructor(){super(...arguments),this.src=""}render(){return r.e` <div class="svg" style="-webkit-mask-image: url(${this.src})"></div> `}};rt.styles=r.b`
    :host {
      display: block;
      width: 30px;
      height: 30px;
      --size: 100%;
      -webkit-mask-size: var(--size);
      -webkit-mask-position: center;
      -webkit-mask-repeat: no-repeat;
      color: black;
    }
    .svg {
      width: inherit;
      height: inherit;
      -webkit-mask-size: inherit;
      -webkit-mask-position: inherit;
      color: inherit;
      background-color: currentcolor;
      -webkit-mask-repeat: inherit;
    }
  `,et([Object(r.g)({type:String}),nt("design:type",Object)],rt.prototype,"src",void 0),rt=et([Object(r.c)("infinito-svg")],rt);var ot=r.b`:host{display:block;height:100%;--point-height: 2px}.tabs{position:relative;width:100%;height:100%;display:flex}.tabs.vertically{align-items:center}.tabs.horizontally{flex-direction:column}.tabs[style]::after{content:''}.tabs.vertically::after{--width: 28;position:absolute;width:calc(var(--width) * 1px);left:calc((var(--target-left) + (var(--target-width) - var(--width)) / 2) * 1px);border-bottom:var(--point-height) solid #333;bottom:0;transition:left 0.2s, width 0.2s}.tabs.horizontally::after{position:absolute;width:100%;height:calc(var(--target-height, 0) * 1px);top:calc(var(--target-top, -500) * 1px);border-right:var(--point-height) solid #333;right:0;transition:top 0.2s, height 0.2s}
`,it=function(t,e,n,r){var o,i=arguments.length,a=i<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(t,e,n,r);else for(var s=t.length-1;s>=0;s--)(o=t[s])&&(a=(i<3?o(a):i>3?o(e,n,a):o(e,n))||a);return i>3&&a&&Object.defineProperty(e,n,a),a},at=function(t,e){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(t,e)};let st=class extends r.a{constructor(){super(...arguments),this.type="vertically",this.active=0}setActiveStyle(){const t=this.$slot.assignedElements();if(t&&t.length>0){const e=t[this.active],n=this.$tabsbox.style,{offsetTop:r,offsetLeft:o,offsetWidth:i,offsetHeight:a}=e;n.setProperty("--target-width",i+""),n.setProperty("--target-height",a+""),n.setProperty("--target-left",o+""),n.setProperty("--target-top",r+"")}}updated(t){t.has("active")&&this.setActiveStyle()}render(){return r.e`
      <div class="tabs ${this.type}">
        <slot></slot>
      </div>
    `}};st.styles=ot,it([Object(r.g)({type:String}),at("design:type",String)],st.prototype,"type",void 0),it([Object(r.g)({type:Number}),at("design:type",Object)],st.prototype,"active",void 0),it([Object(r.h)(".tabs"),at("design:type",HTMLDivElement)],st.prototype,"$tabsbox",void 0),it([Object(r.h)("slot"),at("design:type",HTMLSlotElement)],st.prototype,"$slot",void 0),st=it([Object(r.c)("infinito-tabs")],st)},function(t,e,n){t.exports=n.p+"images/iconfont.919d651.svg"},function(t,e,n){t.exports=n.p+"images/icon.196b87f.svg"},,,,,function(t,e,n){var r=n(450);t.exports=r},function(t,e,n){var r=n(451),o=Array.prototype;t.exports=function(t){var e=t.reduceRight;return t===o||t instanceof Array&&e===o.reduceRight?r:e}},function(t,e,n){n(452);var r=n(177);t.exports=r("Array").reduceRight},function(t,e,n){"use strict";var r=n(27),o=n(252).right,i=n(248),a=n(176),s=n(129);r({target:"Array",proto:!0,forced:!i("reduceRight")||!s&&a>79&&a<83},{reduceRight:function(t){return o(this,t,arguments.length,arguments.length>1?arguments[1]:void 0)}})},function(t,e,n){var r=n(454);t.exports=r},function(t,e,n){n(455);var r=n(70).Object,o=t.exports=function(t,e,n){return r.defineProperty(t,e,n)};r.defineProperty.sham&&(o.sham=!0)},function(t,e,n){var r=n(27),o=n(25);r({target:"Object",stat:!0,forced:!o,sham:!o},{defineProperty:n(71).f})},function(t,e,n){var r=n(457),o=n(487),i=n(406),a=n(489),s=n(499),c=n(502),u=n(503),l=n(504),p=n(506),h=n(507),d=n(508),f=n(380),g=n(513),v=n(514),m=n(520),y=n(373),b=n(409),w=n(522),x=n(341),_=n(524),O=n(372),S=n(378),j={};j["[object Arguments]"]=j["[object Array]"]=j["[object ArrayBuffer]"]=j["[object DataView]"]=j["[object Boolean]"]=j["[object Date]"]=j["[object Float32Array]"]=j["[object Float64Array]"]=j["[object Int8Array]"]=j["[object Int16Array]"]=j["[object Int32Array]"]=j["[object Map]"]=j["[object Number]"]=j["[object Object]"]=j["[object RegExp]"]=j["[object Set]"]=j["[object String]"]=j["[object Symbol]"]=j["[object Uint8Array]"]=j["[object Uint8ClampedArray]"]=j["[object Uint16Array]"]=j["[object Uint32Array]"]=!0,j["[object Error]"]=j["[object Function]"]=j["[object WeakMap]"]=!1,t.exports=function t(e,n,k,A,T,E){var C,R=1&n,I=2&n,P=4&n;if(k&&(C=T?k(e,A,T,E):k(e)),void 0!==C)return C;if(!x(e))return e;var M=y(e);if(M){if(C=g(e),!R)return u(e,C)}else{var L=f(e),N="[object Function]"==L||"[object GeneratorFunction]"==L;if(b(e))return c(e,R);if("[object Object]"==L||"[object Arguments]"==L||N&&!T){if(C=I||N?{}:m(e),!R)return I?p(e,s(C,e)):l(e,a(C,e))}else{if(!j[L])return T?e:{};C=v(e,L,R)}}E||(E=new r);var B=E.get(e);if(B)return B;E.set(e,C),_(e)?e.forEach((function(r){C.add(t(r,n,k,r,e,E))})):w(e)&&e.forEach((function(r,o){C.set(o,t(r,n,k,o,e,E))}));var D=M?void 0:(P?I?d:h:I?S:O)(e);return o(D||e,(function(r,o){D&&(r=e[o=r]),i(C,o,t(r,n,k,o,e,E))})),C}},function(t,e,n){var r=n(347),o=n(463),i=n(464),a=n(465),s=n(466),c=n(467);function u(t){var e=this.__data__=new r(t);this.size=e.size}u.prototype.clear=o,u.prototype.delete=i,u.prototype.get=a,u.prototype.has=s,u.prototype.set=c,t.exports=u},function(t,e){t.exports=function(){this.__data__=[],this.size=0}},function(t,e,n){var r=n(348),o=Array.prototype.splice;t.exports=function(t){var e=this.__data__,n=r(e,t);return!(n<0)&&(n==e.length-1?e.pop():o.call(e,n,1),--this.size,!0)}},function(t,e,n){var r=n(348);t.exports=function(t){var e=this.__data__,n=r(e,t);return n<0?void 0:e[n][1]}},function(t,e,n){var r=n(348);t.exports=function(t){return r(this.__data__,t)>-1}},function(t,e,n){var r=n(348);t.exports=function(t,e){var n=this.__data__,o=r(n,t);return o<0?(++this.size,n.push([t,e])):n[o][1]=e,this}},function(t,e,n){var r=n(347);t.exports=function(){this.__data__=new r,this.size=0}},function(t,e){t.exports=function(t){var e=this.__data__,n=e.delete(t);return this.size=e.size,n}},function(t,e){t.exports=function(t){return this.__data__.get(t)}},function(t,e){t.exports=function(t){return this.__data__.has(t)}},function(t,e,n){var r=n(347),o=n(370),i=n(474);t.exports=function(t,e){var n=this.__data__;if(n instanceof r){var a=n.__data__;if(!o||a.length<199)return a.push([t,e]),this.size=++n.size,this;n=this.__data__=new i(a)}return n.set(t,e),this.size=n.size,this}},function(t,e,n){var r=n(403),o=n(471),i=n(341),a=n(405),s=/^\[object .+?Constructor\]$/,c=Function.prototype,u=Object.prototype,l=c.toString,p=u.hasOwnProperty,h=RegExp("^"+l.call(p).replace(/[\\^$.*+?()[\]{}|]/g,"\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g,"$1.*?")+"$");t.exports=function(t){return!(!i(t)||o(t))&&(r(t)?h:s).test(a(t))}},function(t,e,n){var r=n(371),o=Object.prototype,i=o.hasOwnProperty,a=o.toString,s=r?r.toStringTag:void 0;t.exports=function(t){var e=i.call(t,s),n=t[s];try{t[s]=void 0;var r=!0}catch(t){}var o=a.call(t);return r&&(e?t[s]=n:delete t[s]),o}},function(t,e){var n=Object.prototype.toString;t.exports=function(t){return n.call(t)}},function(t,e,n){var r,o=n(472),i=(r=/[^.]+$/.exec(o&&o.keys&&o.keys.IE_PROTO||""))?"Symbol(src)_1."+r:"";t.exports=function(t){return!!i&&i in t}},function(t,e,n){var r=n(193)["__core-js_shared__"];t.exports=r},function(t,e){t.exports=function(t,e){return null==t?void 0:t[e]}},function(t,e,n){var r=n(475),o=n(482),i=n(484),a=n(485),s=n(486);function c(t){var e=-1,n=null==t?0:t.length;for(this.clear();++e<n;){var r=t[e];this.set(r[0],r[1])}}c.prototype.clear=r,c.prototype.delete=o,c.prototype.get=i,c.prototype.has=a,c.prototype.set=s,t.exports=c},function(t,e,n){var r=n(476),o=n(347),i=n(370);t.exports=function(){this.size=0,this.__data__={hash:new r,map:new(i||o),string:new r}}},function(t,e,n){var r=n(477),o=n(478),i=n(479),a=n(480),s=n(481);function c(t){var e=-1,n=null==t?0:t.length;for(this.clear();++e<n;){var r=t[e];this.set(r[0],r[1])}}c.prototype.clear=r,c.prototype.delete=o,c.prototype.get=i,c.prototype.has=a,c.prototype.set=s,t.exports=c},function(t,e,n){var r=n(350);t.exports=function(){this.__data__=r?r(null):{},this.size=0}},function(t,e){t.exports=function(t){var e=this.has(t)&&delete this.__data__[t];return this.size-=e?1:0,e}},function(t,e,n){var r=n(350),o=Object.prototype.hasOwnProperty;t.exports=function(t){var e=this.__data__;if(r){var n=e[t];return"__lodash_hash_undefined__"===n?void 0:n}return o.call(e,t)?e[t]:void 0}},function(t,e,n){var r=n(350),o=Object.prototype.hasOwnProperty;t.exports=function(t){var e=this.__data__;return r?void 0!==e[t]:o.call(e,t)}},function(t,e,n){var r=n(350);t.exports=function(t,e){var n=this.__data__;return this.size+=this.has(t)?0:1,n[t]=r&&void 0===e?"__lodash_hash_undefined__":e,this}},function(t,e,n){var r=n(351);t.exports=function(t){var e=r(this,t).delete(t);return this.size-=e?1:0,e}},function(t,e){t.exports=function(t){var e=typeof t;return"string"==e||"number"==e||"symbol"==e||"boolean"==e?"__proto__"!==t:null===t}},function(t,e,n){var r=n(351);t.exports=function(t){return r(this,t).get(t)}},function(t,e,n){var r=n(351);t.exports=function(t){return r(this,t).has(t)}},function(t,e,n){var r=n(351);t.exports=function(t,e){var n=r(this,t),o=n.size;return n.set(t,e),this.size+=n.size==o?0:1,this}},function(t,e){t.exports=function(t,e){for(var n=-1,r=null==t?0:t.length;++n<r&&!1!==e(t[n],n,t););return t}},function(t,e,n){var r=n(242),o=function(){try{var t=r(Object,"defineProperty");return t({},"",{}),t}catch(t){}}();t.exports=o},function(t,e,n){var r=n(352),o=n(372);t.exports=function(t,e){return t&&r(e,o(e),t)}},function(t,e){t.exports=function(t,e){for(var n=-1,r=Array(t);++n<t;)r[n]=e(n);return r}},function(t,e,n){var r=n(492),o=n(342),i=Object.prototype,a=i.hasOwnProperty,s=i.propertyIsEnumerable,c=r(function(){return arguments}())?r:function(t){return o(t)&&a.call(t,"callee")&&!s.call(t,"callee")};t.exports=c},function(t,e,n){var r=n(349),o=n(342);t.exports=function(t){return o(t)&&"[object Arguments]"==r(t)}},function(t,e){t.exports=function(){return!1}},function(t,e){var n=/^(?:0|[1-9]\d*)$/;t.exports=function(t,e){var r=typeof t;return!!(e=null==e?9007199254740991:e)&&("number"==r||"symbol"!=r&&n.test(t))&&t>-1&&t%1==0&&t<e}},function(t,e,n){var r=n(496),o=n(375),i=n(376),a=i&&i.isTypedArray,s=a?o(a):r;t.exports=s},function(t,e,n){var r=n(349),o=n(410),i=n(342),a={};a["[object Float32Array]"]=a["[object Float64Array]"]=a["[object Int8Array]"]=a["[object Int16Array]"]=a["[object Int32Array]"]=a["[object Uint8Array]"]=a["[object Uint8ClampedArray]"]=a["[object Uint16Array]"]=a["[object Uint32Array]"]=!0,a["[object Arguments]"]=a["[object Array]"]=a["[object ArrayBuffer]"]=a["[object Boolean]"]=a["[object DataView]"]=a["[object Date]"]=a["[object Error]"]=a["[object Function]"]=a["[object Map]"]=a["[object Number]"]=a["[object Object]"]=a["[object RegExp]"]=a["[object Set]"]=a["[object String]"]=a["[object WeakMap]"]=!1,t.exports=function(t){return i(t)&&o(t.length)&&!!a[r(t)]}},function(t,e,n){var r=n(377),o=n(498),i=Object.prototype.hasOwnProperty;t.exports=function(t){if(!r(t))return o(t);var e=[];for(var n in Object(t))i.call(t,n)&&"constructor"!=n&&e.push(n);return e}},function(t,e,n){var r=n(411)(Object.keys,Object);t.exports=r},function(t,e,n){var r=n(352),o=n(378);t.exports=function(t,e){return t&&r(e,o(e),t)}},function(t,e,n){var r=n(341),o=n(377),i=n(501),a=Object.prototype.hasOwnProperty;t.exports=function(t){if(!r(t))return i(t);var e=o(t),n=[];for(var s in t)("constructor"!=s||!e&&a.call(t,s))&&n.push(s);return n}},function(t,e){t.exports=function(t){var e=[];if(null!=t)for(var n in Object(t))e.push(n);return e}},function(t,e,n){(function(t){var r=n(193),o=e&&!e.nodeType&&e,i=o&&"object"==typeof t&&t&&!t.nodeType&&t,a=i&&i.exports===o?r.Buffer:void 0,s=a?a.allocUnsafe:void 0;t.exports=function(t,e){if(e)return t.slice();var n=t.length,r=s?s(n):new t.constructor(n);return t.copy(r),r}}).call(this,n(374)(t))},function(t,e){t.exports=function(t,e){var n=-1,r=t.length;for(e||(e=Array(r));++n<r;)e[n]=t[n];return e}},function(t,e,n){var r=n(352),o=n(379);t.exports=function(t,e){return r(t,o(t),e)}},function(t,e){t.exports=function(t,e){for(var n=-1,r=null==t?0:t.length,o=0,i=[];++n<r;){var a=t[n];e(a,n,t)&&(i[o++]=a)}return i}},function(t,e,n){var r=n(352),o=n(414);t.exports=function(t,e){return r(t,o(t),e)}},function(t,e,n){var r=n(417),o=n(379),i=n(372);t.exports=function(t){return r(t,i,o)}},function(t,e,n){var r=n(417),o=n(414),i=n(378);t.exports=function(t){return r(t,i,o)}},function(t,e,n){var r=n(242)(n(193),"DataView");t.exports=r},function(t,e,n){var r=n(242)(n(193),"Promise");t.exports=r},function(t,e,n){var r=n(242)(n(193),"Set");t.exports=r},function(t,e,n){var r=n(242)(n(193),"WeakMap");t.exports=r},function(t,e){var n=Object.prototype.hasOwnProperty;t.exports=function(t){var e=t.length,r=new t.constructor(e);return e&&"string"==typeof t[0]&&n.call(t,"index")&&(r.index=t.index,r.input=t.input),r}},function(t,e,n){var r=n(381),o=n(516),i=n(517),a=n(518),s=n(519);t.exports=function(t,e,n){var c=t.constructor;switch(e){case"[object ArrayBuffer]":return r(t);case"[object Boolean]":case"[object Date]":return new c(+t);case"[object DataView]":return o(t,n);case"[object Float32Array]":case"[object Float64Array]":case"[object Int8Array]":case"[object Int16Array]":case"[object Int32Array]":case"[object Uint8Array]":case"[object Uint8ClampedArray]":case"[object Uint16Array]":case"[object Uint32Array]":return s(t,n);case"[object Map]":return new c;case"[object Number]":case"[object String]":return new c(t);case"[object RegExp]":return i(t);case"[object Set]":return new c;case"[object Symbol]":return a(t)}}},function(t,e,n){var r=n(193).Uint8Array;t.exports=r},function(t,e,n){var r=n(381);t.exports=function(t,e){var n=e?r(t.buffer):t.buffer;return new t.constructor(n,t.byteOffset,t.byteLength)}},function(t,e){var n=/\w*$/;t.exports=function(t){var e=new t.constructor(t.source,n.exec(t));return e.lastIndex=t.lastIndex,e}},function(t,e,n){var r=n(371),o=r?r.prototype:void 0,i=o?o.valueOf:void 0;t.exports=function(t){return i?Object(i.call(t)):{}}},function(t,e,n){var r=n(381);t.exports=function(t,e){var n=e?r(t.buffer):t.buffer;return new t.constructor(n,t.byteOffset,t.length)}},function(t,e,n){var r=n(521),o=n(416),i=n(377);t.exports=function(t){return"function"!=typeof t.constructor||i(t)?{}:r(o(t))}},function(t,e,n){var r=n(341),o=Object.create,i=function(){function t(){}return function(e){if(!r(e))return{};if(o)return o(e);t.prototype=e;var n=new t;return t.prototype=void 0,n}}();t.exports=i},function(t,e,n){var r=n(523),o=n(375),i=n(376),a=i&&i.isMap,s=a?o(a):r;t.exports=s},function(t,e,n){var r=n(380),o=n(342);t.exports=function(t){return o(t)&&"[object Map]"==r(t)}},function(t,e,n){var r=n(525),o=n(375),i=n(376),a=i&&i.isSet,s=a?o(a):r;t.exports=s},function(t,e,n){var r=n(380),o=n(342);t.exports=function(t){return o(t)&&"[object Set]"==r(t)}},function(t,e,n){t.exports=n.p+"images/item_1.8b1e737.png"},function(t,e,n){t.exports=n.p+"images/item_2.f6e1bf0.png"},function(t,e,n){t.exports=n.p+"images/item_3.d04a54a.png"},function(t,e,n){t.exports=n.p+"images/arrow.1799f5d.png"},function(t,e,n){t.exports=n.p+"images/edit.064f8e9.svg"},function(t,e,n){t.exports=n.p+"images/del.20d8e3b.svg"},,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,function(t,e,n){t.exports=n.p+"images/success.00a4a1f.svg"},,,,,,function(t,e,n){"use strict";n.r(e);n(2),n(442),n(367),n(13),n(17),n(10);var r=n(1),o=n(245),i=n(7),a=n.n(i),s=n(3),c=n(14),u=n(22),l=n(178),p=function(t,e,n,r){var o,i=arguments.length,a=i<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(t,e,n,r);else for(var s=t.length-1;s>=0;s--)(o=t[s])&&(a=(i<3?o(a):i>3?o(e,n,a):o(e,n))||a);return i>3&&a&&Object.defineProperty(e,n,a),a};class h{getTabInfo(){return new a.a(t=>{chrome.tabs.query({currentWindow:!0,active:!0},([e])=>{const n={};n.target=e.url,n.name=e.title,e.title.length>3?n.bgText=e.title.substr(0,2):n.bgText=e.title,t(n)})})}async submit(t){const e=Object.assign(Object.assign({},t),{uuid:c.a.randomId("site-"),id:c.a.randomId("siteId-"),type:"web",updatetime:Date.now()}),{sites:n}=await Object(u.b)("store-site"),{setting:r}=await Object(u.b)("store-setting"),o=n.length-1;0===n.length?n.push([e]):n[o].length<r.layout.row*r.layout.col?n[o].push(e):n.push([e]),await Object(u.f)("store-site",{sites:n}),await Object(u.g)("site",{sites:n}),l.slave.sendMessage("tabs-sync","store-site")}}p([s.b],h.prototype,"getTabInfo",null),p([s.b],h.prototype,"submit",null);const d=new h;var f=n(383),g=n(247),v=function(t,e,n,r){var o,i=arguments.length,a=i<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(t,e,n,r);else for(var s=t.length-1;s>=0;s--)(o=t[s])&&(a=(i<3?o(a):i>3?o(e,n,a):o(e,n))||a);return i>3&&a&&Object.defineProperty(e,n,a),a};let m=class extends o.a{constructor(){super(...arguments),this.initValue=Object.assign({},f.a.defaultValue),this.step=0}firstUpdated(){g.a.sendPageView({page:"popup"})}async performUpdate(){const t=await d.getTabInfo();this.initValue=Object.assign(Object.assign(Object.assign({},f.a.defaultValue),t),{iconType:"color"}),super.performUpdate()}createRenderRoot(){return this}async _submit(t){var e;await d.submit(t.detail.value),this.step=1,g.a.sendEvent({action:{addPopupIcon:c.a.getTargetLogDomain(null===(e=t.detail.value)||void 0===e?void 0:e.target)}}),setTimeout(()=>{window.close()},3e3)}render(){return 0===this.step?r.e`
        <i-editicon
          style="padding: 24px 20px 20px;"
          .value="${this.initValue}"
          @on-submit="${this._submit}"
          iconType="custom-icon"
          .popup="${!0}"
        ></i-editicon>
      `:1===this.step?r.e` <popup-add-success></popup-add-success> `:void 0}};v([Object(r.f)()],m.prototype,"initValue",void 0),v([Object(r.f)()],m.prototype,"step",void 0),m=v([Object(r.c)("popup-add-icon")],m);var y=function(t,e,n,r){var o,i=arguments.length,a=i<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(t,e,n,r);else for(var s=t.length-1;s>=0;s--)(o=t[s])&&(a=(i<3?o(a):i>3?o(e,n,a):o(e,n))||a);return i>3&&a&&Object.defineProperty(e,n,a),a};let b=class extends r.a{render(){return r.e`
      <div class="add-success">
        <img class="img" src="${n(567)}" alt="" />
        <div class="text">${i18n("add_icon_success")}</div>
      </div>
    `}};b.styles=r.b`
    .add-success {
      height: 530px;
      background-color: #fff;
      display: flex;
      flex-direction: column;
      align-items: center;
    }
    .img {
      margin-top: 184px;
      width: 60px;
      height: 60px;
    }
    .text {
      margin-top: 20px;
      height: 24px;
      font-size: 14px;
      font-weight: 300;
      color: #999999;
      line-height: 24px;
    }
  `,b=y([Object(r.c)("popup-add-success")],b)}]);